import axios from 'axios';
import store from '@/store';

//witelist
const whiteAPIList = ['/api/login', '/api/reguser', '/api/admin-login'];

// 定义请求拦截器
axios.interceptors.request.use(config => {
  // 为请求头挂载Authorization字段
  if (!whiteAPIList.includes(config.url)) {
    config.headers.Authorization = store.state.token;
  }
  return config;
}, error => {
  return Promise.reject(error);
});

// 定义响应拦截器
axios.interceptors.response.use(response => {
  return response;
}, error => {
  // 如果响应状态码为401，跳转到登录页面
  if (error.response.status === 401) {
    store.commit('UpdateToken', '');
    window.location.href = '/login';
  }
  return Promise.reject(error);
});

export default axios
