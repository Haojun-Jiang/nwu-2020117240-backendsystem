<template>
  <div class = 'base'>
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'app'
}
</script>

<style lang="less" scoped>
.base {
  height: 789px;
}
</style>
