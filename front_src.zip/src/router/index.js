/* eslint-disable */
import Vue from 'vue'
import VueRouter from 'vue-router'
import Layout from '@/views/layout/myLayout.vue'
import Login from '@/views/Login/myLogin.vue'
import store from '@/store/index'

const Reg = () => import('@/views/reg/regUser.vue')

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    component: Layout,
    redirect: '/home',
    children: [
      {
        path: 'home',
        component: () => import('@/views/home/myHome.vue')
      },
      {
        path: '/my/edit',
        component: () => import('@/views/shopUser/userInfo.vue')
      },
      {
        path: '/my/password',
        component: () => import('@/views/shopUser/userPwd.vue')
      },
      {
        path: '/product/list',
        component: () => import('@/views/product/proList.vue')
      },
      {
        path: '/product/add',
        component: () => import('@/views/product/newPro.vue')
      },
      {
        path: '/product/edit',
        component: () => import('@/views/product/editPro.vue')
      },
      {
        path: '/vip',
        component : () => import('@/views/vip/buyVip.vue')
      },
      {
        path: '/spce',
        component : () => import('@/views/product/proSpec.vue')
      }
    ]
  }, {
    path: '/login',
    name: 'login',
    component: Login
  }, {
    path: '/reguser',
    name: 'reg',
    component: Reg 
  }, {
    path: '/home',
    name: 'home',
    component: () => import('@/views/home/myHome.vue')
  }, {
    path: '/admin-login',
    name: 'admin-login',
    component: () => import('@/views/Login/admLogin.vue')
  }, {
    path: '/admin-home',
    name: 'admin-home',
    component: () => import('@/views/admin/admLay.vue'),
    children: [
      {
        path: '/admin/updatepwd',
        component: () => import('@/views/admin/admPwd.vue')
      },
      {
        path: '/manage/products',
        component: () => import('@/views/admin/admPro.vue')
      },
      {
        path: '/manage/shops',
        component: () => import('@/views/admin/admShop.vue')
      },
      {
        path: '/edit/shops',
        component: () => import('@/views/manage/mageShop.vue')
      }
    ]
  },{
    path: '/client',
    name: 'client',
    component: () => import('@/views/client/proList.vue')
  },{
    path: '/client/border',
    name: 'client-border',
    component: () => import('@/views/client/proBorder.vue')
  },
  {
    path: '/client/spec',
    name: 'client-spec',
    component: () => import('@/views/client/proSpec.vue')
  }
]

const router = new VueRouter({
  routes
})

const whiteList = ['/login', '/reguser', '/admin-login', '/client','/client/border'] // 不重定向白名单

router.beforeEach((to, from, next) =>{
  const token = store.state.token
  const admin = store.state.admin
  if(token){
    if(!store.state.userInfo.UserName){
      store.dispatch('initUserInfo')
    }
    next()
  } else {
    if(whiteList.includes(to.path)) {
      next()
    } else {
      next('/login')
    }
  }
  next()
})

export default router
