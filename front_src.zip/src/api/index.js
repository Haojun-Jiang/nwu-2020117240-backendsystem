/* eslint-disable */
import axios from 'axios'
import qs from 'qs'
import store from '@/store'

// 注册接口
export const registerAPI = ({ ShopName, UserName, MobilePhone, Password, salt }) => {
  return axios.post('http://127.0.0.1:3007/api/reguser', qs.stringify({
    ShopName,
    UserName,
    MobilePhone,
    Password,
    salt
  }))
}

// 登录接口
export const shopLogin = ({ UserName, Password }) => {
  return axios.post('http://127.0.0.1:3007/api/login', qs.stringify({
    UserName,
    Password
  }))
}

// 获取用户信息接口
export const getUserinfo = () => {
  return axios.get('http://127.0.0.1:3007/my/shopuser-info', {
    headers: {
      Authorization: store.state.token
    }
  })
}

// 更新用户信息接口
export const updateUserinfo = ({ ShopName, UserName, MobilePhone }) => {
  return axios.post('http://127.0.0.1:3007/my/shopuser-info', qs.stringify({
    ShopName,
    UserName,
    MobilePhone
  }), {
    headers: {
      Authorization: store.state.token
    }
  })
}

// 更新用户密码接口
export const updateUserPwd = ({ Password, newPassword, Rep_Password }) => {
  return axios.post('http://127.0.0.1:3007/my/update-pwd', qs.stringify({
    Password,
    newPassword,
    Rep_Password
  }),{
    headers: {
      Authorization: store.state.token
    }
  })
}

// 添加商品接口
export const newProduct = ({ ProductName, ProductPic, IsWithdraw, Width, Hight, Taobao }) => {
  return axios.post('http://127.0.0.1:3007/my/newproduct', qs.stringify({
    ProductName,
    ProductPic,
    IsWithdraw,
    Width,
    Hight,
    Taobao
  }),{
    headers: {
      Authorization: store.state.token
    }
  })
}

// 获取商品列表接口
export const getProductList = () => {
  return axios.get('http://127.0.0.1:3007/my/productinfo', {
    headers: {
      Authorization: store.state.token
    }
  })
}

// 删除商品接口
export const deleteProduct = ({ ProductID }) => {
  console.log(ProductID)
  return axios.post('http://127.0.0.1:3007/my/deleteproduct', qs.stringify({
    ProductID
  }),{
    headers: {
      Authorization: store.state.token
    }
  })
}

// 更新商品接口
export const updateProduct = ({ ProductID, ProductName, ProductPic, IsWithdraw, Width, Hight, Taobao }) => {
  return axios.post('http://127.0.0.1:3007/my/productinfo', qs.stringify({
    ProductID,
    ProductName,
    ProductPic,
    IsWithdraw,
    Width,
    Hight,
    Taobao
  }),{
    headers: {
      Authorization: store.state.token
    }
  })
}

// 管理员登录
export const admLogin = ({ UserName, Password }) => {
  return axios.post('http://127.0.0.1:3007/api/admin-login', qs.stringify({
    UserName,
    Password
  }))
}

// 更改管理员密码
export const updateAdminPwd = ({ Password, newPassword, Rep_Password }) => {
  return axios.post('http://127.0.0.1:3007/admin/updatepwd', qs.stringify({
    Password,
    newPassword,
    Rep_Password
  }),{
    headers: {
      Authorization: store.state.token
    }
  })
}

// 管理员获取用户信息
export const admgetShops = () => {
  return axios.get('http://127.0.0.1:3007/admin/show-shops', {
    headers: {
      Authorization: store.state.token
    }
  })
}

// 管理员获取商品信息
export const admgetProducts = () => {
  return axios.get('http://127.0.0.1:3007/admin/show-products', {
    headers: {
      Authorization: store.state.token
    }
  })
}

// 管理员修改用户信息
export const admUpdateShop = ({ isFreezing, isStoped, FreeTryExpried, VIPExpried, UserID }) => {
  return axios.post('http://127.0.0.1:3007/admin/change-shops', qs.stringify({
    isFreezing,
    isStoped,
    FreeTryExpried,
    VIPExpried,
    UserID
  })
  ,{
    headers: {
      Authorization: store.state.token
    }
  })
}

// 管理员修改商品信息
export const admUpdateProduct = ({ IsWithdraw, ProductID }) => {
  return axios.post('http://127.0.0.1:3007/admin/change-products', qs.stringify({
    IsWithdraw,
    ProductID
  }),
  {
    headers: {
      Authorization: store.state.token
    }
  })
}

// 管理员搜索商品
export const admSearchProduct = ({ Keywords }) => {
  return axios.post('http://127.0.0.1:3007/admin/search-products', qs.stringify({
    Keywords
  }),
  {
    headers: {
      Authorization: store.state.token
    }
  })
}

// 管理员搜索用户
export const admSearchShop = ({ Keywords }) => {
  return axios.post('http://127.0.0.1:3007/admin/search-shops', qs.stringify({
    Keywords
  }),
  {
    headers: {
      Authorization: store.state.token
    }
  })
}

//普通用户商品列表
export const clientProlist = () => {
  return axios.get('http://127.0.0.1:3007/api/productlist')
}

//普通用户搜索商品
export const clientSearchProduct = ({ Keywords }) => {
  return axios.post('http://127.0.0.1:3007/api/searchpro', qs.stringify({
    Keywords
  }))
}

//转跳到dapei
export const clientDapei = ({ ProductID }) => {
  return axios.post('http://127.0.0.1:3007/api/addpro', qs.stringify({
    ProductID
  }))
}

//购买vip
export const buyvip = ({ PaymentAmount }) => {
  return axios.post('http://127.0.0.1:3007/my/buyvip', qs.stringify({
    PaymentAmount
  }), {
    headers: {
      Authorization: store.state.token
    }
  })
}

//加入边框设计
export const addborder = ({ ProductPic }) => {
  return axios.post('http://127.0.0.1:3007/api/addborder', qs.stringify({
    ProductPic
  }))
}

//获取产品规格列表
export const getProductSpecList = ({ ProductID }) => {
  return axios.post('http://127.0.0.1:3007/my/getprospeclist', qs.stringify({
    ProductID
  })
  ,{
    headers: {
      Authorization: store.state.token
    }
  })
}

//添加商品规格
export const addProductSpec = ({ ProductID, Width,  Hight }) => {
  return axios.post('http://127.0.0.1:3007/my/addproductspec', qs.stringify({
    ProductID,
    Width,
    Hight
  })
  ,{
    headers: {
      Authorization: store.state.token
    }
  })
}

//删除商品规格
export const deleteProductSpec = ({ SpecifiID }) => {
  return axios.post('http://127.0.0.1:3007/my/deleteproductspec', qs.stringify({
    SpecifiID
  }),
  {
    headers: {
      Authorization: store.state.token
    }
  })
}

//用户获取商品规格列表
export const getProductSpecList2 = ({ ProductID }) => {
  return axios.post('http://127.0.0.1:3007/api/getspec', qs.stringify({
    ProductID
  }))
}