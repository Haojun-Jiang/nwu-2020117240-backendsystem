/* eslint-disable */
import Vue from 'vue'
import Vuex from 'vuex'
import cache from './module/cache.js'
import createPersistedState from 'vuex-persistedstate'
import { getUserinfo } from '@/api'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    token: '',
    admin: false,
    userInfo: {}
  },
  getters: {
    UserName: state => state.userInfo.UserName,
    ShopName: state => state.userInfo.ShopName,
    isStoped: state => state.userInfo.isStoped,
    FreeTryExpried: state => state.userInfo.FreeTryExpried,
    VIPExpried: state => state.userInfo.VIPExpried
  },
  mutations: {
    updateToken (state, newToken) {
      state.token = newToken
    },
    updateUserInfo (state, info) {
      state.userInfo = info
    },
    admToken (state, newToken) {
      state.admin = true
      state.token = newToken
    }
  },
  actions: {
    async initUserInfo (store) {
        const { data: res } = await getUserinfo()
          if (res.status === 0) {
            store.commit('updateUserInfo', res.data)
          }
     
    }
  },
  modules: {
    cache
  },
  plugins: [createPersistedState()]
})
