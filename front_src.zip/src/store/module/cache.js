/* eslint-disable */
export default {
    namespaced: true,
    state: {
        rowData: {}, // 当前行数据
    },
    mutations: {
        changeRowData(state, payload) {
            state.rowData = payload;
            console.log(state.rowData)
        }
    }
}
