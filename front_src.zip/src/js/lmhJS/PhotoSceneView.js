this.MyFurnitureAssistant = this.MyFurnitureAssistant || {};
// 定义别名(快捷名)：
if (typeof this.MyFA === "undefined") {
  this.MyFA = this.MyFurnitureAssistant;
}
//照片场景View
(function () {
  function PhotoSceneView(stage) {
    this.stage = stage;
    //是否处于地板铺设状态 初始设置为false
    this.isEditFloor = false;
    //this.isEditFurniture = true;
    //地板铺设模式 默认设为0（填充模式）
    this.floorMode = "0";
    //铺设地板时是否保留光影 默认设为true
    this.isSaveShadow = true;
    //设置未选中任何家具
    this.SelectFurnitureContainer = null;
    this.imgDataHengPing = undefined;
    this.imgDataShuPing = undefined;

    this.zIndexFloor = 0; //用以设置地面型商品的z轴顺序。初始值为0，每添加一个地面型商品+1
    this.zIndexWall = -300000; //用以设置壁挂商品的z轴顺序。初始值为-300000
    this.zIndexLight = 200000; //用以设置灯具的z轴顺序。初始值为200000，每添加一个家装饰品+1
    this.zIndexOrnament = 300000; //用以设置家装饰品的z轴顺序。初始值为300000，每添加一个家装饰品+1

    //场景View下的放大镜View
    this.MagnifierView;
    //场景View下的墙线View
    this.WallLineView;
    //场景View下的标尺View
    this.RulerView;
  }
  var p = PhotoSceneView.prototype;

  p.updateCanvas = function (photoSceneModel) {
    var canvas = this.stage.canvas,
      ctx = canvas.getContext("2d");

    //��������򵼵�һ�����ߵذ�����״̬����ÿ��updateʱ���������»��Ƴ���
    if (
      MyFA.stepIndex == 0 ||
      (MyFA.stepIndex == 3 && this.isEditFloor == true)
    ) {
      //txt.textContent = "\n111";
      this.putFloorResultToCanvas(photoSceneModel);
    }
    //��������£����Ѿ������canvas��������ȥ����
    else {
      //���ֺ�����
      if (window.orientation == 90 || window.orientation == -90) {
        if (this.imgDataHengPing == undefined) {
          //txt.textContent = "\n222";
          this.putFloorResultToCanvas(photoSceneModel);
        } else {
          //txt.textContent = "\n333";
          //��������canvas�ߴ�
          canvas.width = Math.floor(
            photoSceneModel.Original.col * photoSceneModel.scale
          );
          canvas.height = Math.floor(
            photoSceneModel.Original.row * photoSceneModel.scale
          );
          ctx.putImageData(this.imgDataHengPing, 0, 0);
        }
      }
      if (window.orientation == 180 || window.orientation == 0) {
        if (this.imgDataShuPing == undefined) {
          //txt.textContent = "\n555";
          this.putFloorResultToCanvas(photoSceneModel);
        } else {
          //txt.textContent = "\n666";
          canvas.width = Math.floor(
            photoSceneModel.Original.col * photoSceneModel.scale
          );
          canvas.height = Math.floor(
            photoSceneModel.Original.row * photoSceneModel.scale
          );
          ctx.putImageData(this.imgDataShuPing, 0, 0);
        }
      }
    }
  };

  //清除画布上的内容
  p.ClearCanvas = function () {
    var canvas = this.stage;
    canvas.width = 0;
    canvas.height = 0;
  };

  //绘制墙线
  //wallLineModel:墙点model
  //scale:场景缩放比例
  //isEnableMove：是否允许墙线移动
  p.DrawWallLine = function (wallLineModel, scale, isEnableMove) {
    this.WallLineView = new MyFA.WallLineView(
      this.stage,
      wallLineModel,
      scale,
      isEnableMove
    );
  };

  //移除墙线
  //stage:目标舞台
  //isUpdate:是否需要更新舞台
  p.RemoveWallLineContainer = function (isUpdate) {
    var lineContainer = this.stage.getChildByName("line");
    if (typeof lineContainer != "undefined" && lineContainer != null) {
      this.stage.removeChild(lineContainer);
    }
    if (isUpdate) {
      this.stage.update();
    }
  };

  //绘制标尺
  p.DrawWallRuler = function (walls, width, scale) {
    this.RulerView = new MyFA.Ruler(this.stage, walls, width, scale);
  };

  //移除标尺
  //stage:目标舞台
  //isUpdate:是否需要更新舞台
  p.RemoveWallRulerContainer = function (isUpdate) {
    var ruleContainer = this.stage.getChildByName("ruler");
    if (typeof ruleContainer != "undefined" && ruleContainer != null) {
      this.stage.removeChild(ruleContainer);
    }
    if (isUpdate) {
      this.stage.update();
    }
  };

  //将地板铺设结果绘制到canvas上
  //original:一个图像矩阵
  p.putFloorResultToCanvas = function (photoSceneModel) {
    var original = photoSceneModel.Original;

    //先将缩放了一半的场景照片贴在canvas上
    var contourCanvas1 = this.stage.canvas;
    var ctx3 = contourCanvas1.getContext("2d");

    //如果场景比例大于1，则进行放大
    if (photoSceneModel.scale >= 1) {
      contourCanvas1.width = Math.floor(original.col * photoSceneModel.scale);
      contourCanvas1.height = Math.floor(original.row * photoSceneModel.scale);
      ctx3.putImageData(
        cv.RGBA2ImageData(original),
        0,
        0,
        0,
        0,
        Math.floor(original.col * photoSceneModel.scale),
        Math.floor(original.row * photoSceneModel.scale)
      );
      //按照场景比例将照片进行缩放，贴在canvas上
      ctx3.drawImage(
        contourCanvas1,
        0,
        0,
        Math.floor(original.col),
        Math.floor(original.row),
        0,
        0,
        Math.floor(original.col * photoSceneModel.scale),
        Math.floor(original.row * photoSceneModel.scale)
      );
    }
    //如果场景比例小于1，则进行缩小
    else {
      contourCanvas1.width = Math.floor(original.col);
      contourCanvas1.height = Math.floor(original.row);
      ctx3.putImageData(cv.RGBA2ImageData(original), 0, 0);

      //按照场景比例将照片进行缩放，贴在canvas上
      ctx3.drawImage(
        contourCanvas1,
        0,
        0,
        Math.floor(original.col),
        Math.floor(original.row),
        0,
        0,
        Math.floor(original.col * photoSceneModel.scale),
        Math.floor(original.row * photoSceneModel.scale)
      );
      var imgData = ctx3.getImageData(
        0,
        0,
        Math.floor(original.col * photoSceneModel.scale),
        Math.floor(original.row * photoSceneModel.scale)
      );
      contourCanvas1.width = Math.floor(original.col * photoSceneModel.scale);
      contourCanvas1.height = Math.floor(original.row * photoSceneModel.scale);
      ctx3.putImageData(imgData, 0, 0);
    }
    var imgData1 = ctx3.getImageData(
      0,
      0,
      Math.floor(original.col * photoSceneModel.scale),
      Math.floor(original.row * photoSceneModel.scale)
    );

    //如果是横屏，保存横屏时的场景图像
    if (window.orientation == 90 || window.orientation == -90) {
      this.imgDataHengPing = imgData1;
      if (MyFA.stepIndex == 3 && this.isEditFloor == true)
        this.imgDataShuPing = undefined;
    }
    //如果是竖屏，保存竖屏时的场景图像
    if (window.orientation == 180 || window.orientation == 0) {
      this.imgDataShuPing = imgData1;
      if (MyFA.stepIndex == 3 && this.isEditFloor == true)
        this.imgDataHengPing = undefined;
    }
  };

  //家具超出限制区域时，闪出一条红色警示线(非壁挂类商品专用)
  //P1,P2分别为警示线的两端点
  p.drawAlertLineForFloorFurniture = function (P1, P2, photoSceneModel) {
    var stage = this.stage;
    //画线
    var alertLine = new createjs.Shape();
    alertLine.name = "alertLine";
    alertLine.sy = 0;
    alertLine.graphics.setStrokeStyle(5).beginStroke("rgba(255,0,0,1)");
    alertLine.graphics.moveTo(
      P1.Px * photoSceneModel.scale,
      P1.Py * photoSceneModel.scale
    );
    alertLine.graphics.lineTo(
      P2.Px * photoSceneModel.scale,
      P2.Py * photoSceneModel.scale
    );
    stage.addChild(alertLine);
    stage.update();
    //设置定时器（删除警示线），模拟闪烁效果
    var timeOut = setTimeout(this.removeAlertLine, 10);
  };

  //删除舞台上的警示线
  p.removeAlertLine = function () {
    var stage = MyFA.MainController.resultPic;
    for (var i = 0; i < stage.numChildren; i++) {
      var container = stage.getChildAt(i);
      //找到放置家具的container
      if (container.name == "alertLine") {
        stage.removeChild(container);
      }
    }
    stage.update();
  };

  //家具超出限制区域时，闪出一条红色警示线（壁挂类商品专用，采用h5的方法绘制，提升家具移动时的效率 ）
  //P1,P2分别为警示线的两端点
  p.drawAlertLineForWallFurniture = function (P1, P2, photoSceneModel) {
    var stage = this.stage;
    var context = stage.canvas.getContext("2d");
    context.fillStyle = "red"; //填充颜色：红色，半透明
    context.strokeStyle = "red"; //线条颜色：绿色
    context.lineWidth = 5; //设置线宽
    context.beginPath();
    context.moveTo(
      P1.Px * photoSceneModel.scale,
      P1.Py * photoSceneModel.scale
    );
    context.lineTo(
      P2.Px * photoSceneModel.scale,
      P2.Py * photoSceneModel.scale
    );
    context.closePath(); //可以把这句注释掉再运行比较下不同
    context.stroke(); //画线框
    context.fill(); //填充颜色
  };

  //渲染canvas
  p.drawCanvas = function () {
    this.stage.removeAllChildren();
    this.stage.update();
  };

  //选中家具
  //fc:选中的家具container
  //furnitureId:选中的家具id
  p.selectFurniture = function (fc, furnitureId) {
    this.SelectFurnitureContainer = fc;
    this.SelectFurnitureID = furnitureId;
  };

  MyFA.PhotoSceneView = PhotoSceneView;
})();
