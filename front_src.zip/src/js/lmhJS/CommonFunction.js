this.MyFurnitureAssistant = this.MyFurnitureAssistant || {};
// 定义别名(快捷名)：
if (typeof this.MyFA === "undefined") {
  this.MyFA = this.MyFurnitureAssistant;
}

//公共算法类
(function () {
  function CommonFunction() {}
  //计算点P到直线L的距离
  //x0,y0分别为点P的X坐标，Y坐标
  //linePoint1,linePoint2分别为直线L的两个点，
  CommonFunction.getDistanceOfPointToLine = function (
    x0,
    y0,
    linePoint1,
    linePoint2
  ) {
    var equation = CommonFunction.calLinearEquationByPoints(
      linePoint1,
      linePoint2
    );
    //直线方程为ax+by+c=0的三个参数
    var a = equation.a;
    var b = equation.b;
    var c = equation.c;

    //距离
    var d = Math.abs((a * x0 + b * y0 + c) / Math.pow(a * a + b * b, 0.5));
    return d;
  }; ////只有此处有

  //计算两点之间的距离
  //x1,y1，x2,y2分别为两点的坐标
  CommonFunction.getDistanceOfPointToPoint = function (x1, y1, x2, y2) {
    return Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
  };

  //根据两点解直线方程（ax+by+c=0），求a,b,c,
  //linePoint1,linePoint2分别为直线的两个点
  CommonFunction.calLinearEquationByPoints = function (linePoint1, linePoint2) {
    var a, b, c; //直线方程为ax+by+c=0的三个参数
    //通过求a, b, c,解方程
    if (linePoint1.Px - linePoint2.Px == 0) {
      a = 1;
      b = 0;
      c = linePoint1.Px * -1;
    } else if (linePoint1.Py - linePoint2.Py == 0) {
      a = 0;
      b = 1;
      c = linePoint1.Py * -1;
    } else {
      a = (linePoint1.Py - linePoint2.Py) / (linePoint1.Px - linePoint2.Px);
      b = -1;
      c =
        linePoint1.Py -
        ((linePoint1.Py - linePoint2.Py) * linePoint1.Px) /
          (linePoint1.Px - linePoint2.Px);
    }
    return { a: a, b: b, c: c };
  };

  ///求两条线交点坐标 已知线段1(a,b) 和线段2(c,d) ,其中a b c d为端点, 求线段交点p
  ///(平行或共线视作不相交)
  CommonFunction.segmentsIntr = function (a, b, c, d) {
    /** 1 解线性方程组, 求线段交点. **/
    // 如果分母为0 则平行或共线, 不相交
    var denominator =
      (b.Py - a.Py) * (d.Px - c.Px) - (a.Px - b.Px) * (c.Py - d.Py);
    if (denominator == 0) {
      return false;
    }

    // 线段所在直线的交点坐标 (Px , Py)
    var x =
      ((b.Px - a.Px) * (d.Px - c.Px) * (c.Py - a.Py) +
        (b.Py - a.Py) * (d.Px - c.Px) * a.Px -
        (d.Py - c.Py) * (b.Px - a.Px) * c.Px) /
      denominator;
    var y =
      -(
        (b.Py - a.Py) * (d.Py - c.Py) * (c.Px - a.Px) +
        (b.Px - a.Px) * (d.Py - c.Py) * a.Py -
        (d.Px - c.Px) * (b.Py - a.Py) * c.Py
      ) / denominator;
    return {
      Px: x,
      Py: y,
    };
  };

  //数组的复制方法
  CommonFunction.clone = function (obj) {
    var o, i, j, k;
    if (typeof obj != "object" || obj === null) return obj;
    if (obj instanceof Array) {
      o = [];
      i = 0;
      j = obj.length;
      for (; i < j; i++) {
        if (typeof obj[i] == "object" && obj[i] != null) {
          o[i] = arguments.callee(obj[i]);
        } else {
          o[i] = obj[i];
        }
      }
    } else {
      o = {};
      for (i in obj) {
        if (typeof obj[i] == "object" && obj[i] != null) {
          o[i] = arguments.callee(obj[i]);
        } else {
          o[i] = obj[i];
        }
      }
    }
    return o;
  };

  //求两个向量的夹角
  //（逆时针方向为负，顺时针方向为正）
  CommonFunction.calAngleOfTwoVectors = function (x1, y1, x2, y2) {
    var sin =
      (x1 * y2 - y1 * x2) /
      [Math.sqrt(x1 * x1 + y1 * y1) * Math.sqrt(x2 * x2 + y2 * y2)];
    var cos =
      (x1 * x2 + y1 * y2) /
      [Math.sqrt(x1 * x1 + y1 * y1) * Math.sqrt(x2 * x2 + y2 * y2)];

    if (sin >= 0 && cos >= 0)
      //第一象限
      return Math.acos(cos) / ((Math.PI * 2) / 360);
    if (sin >= 0 && cos < 0)
      //第二象限
      return Math.acos(cos) / ((Math.PI * 2) / 360);
    if (sin < 0 && cos < 0)
      //第三象限
      return -Math.acos(cos) / ((Math.PI * 2) / 360);
    if (sin < 0 && cos >= 0)
      //第四象限
      return -Math.acos(cos) / ((Math.PI * 2) / 360);
  };

  //获取某个线段两点间所有整数点（Bresenham算法）
  //（x1,y1）,（x2,y2）为线段的两个端点
  //seeds为存储这些点的一个数组
  CommonFunction.getAllPointsOfLine = function (x1, y1, x2, y2, seeds) {
    var dx = x2 - x1;
    var dy = y2 - y1;
    var ux = ((dx > 0) << 1) - 1; //x的增量方向，取或-1
    var uy = ((dy > 0) << 1) - 1;

    var x = x1,
      y = y1,
      eps; //eps为累加误差

    eps = 0;
    dx = Math.abs(dx);
    dy = Math.abs(dy);
    if (dx > dy) {
      for (x = x1; x != x2; x += ux) {
        seeds.push(new cvv.mypix(Math.floor(x), Math.floor(y)));

        for (var y5 = 1; y5 < 15; y5++) {
          seeds.push(new cvv.mypix(Math.floor(x), Math.floor(y - y5)));
          seeds.push(new cvv.mypix(Math.floor(x), Math.floor(y + y5)));
        }

        eps += dy;
        if (eps << 1 >= dx) {
          y += uy;
          eps -= dx;
        }
      }
    } else {
      for (y = y1; y != y2; y += uy) {
        seeds.push(new cvv.mypix(Math.floor(x), Math.floor(y)));
        for (var y5 = 1; y5 < 15; y5++) {
          seeds.push(new cvv.mypix(Math.floor(x - y5), Math.floor(y)));
          seeds.push(new cvv.mypix(Math.floor(x + y5), Math.floor(y)));
        }

        eps += dx;
        if (eps << 1 >= dy) {
          x += ux;
          eps -= dy;
        }
      }
    }
  };

  //对象的深拷贝
  CommonFunction.deepCopy = function (target, source) {
    for (var key in source) {
      target[key] = CommonFunction.clone(source[key]);
    }
    return target;
  };

  //生成guid
  CommonFunction.createGuid = function () {
    var s = [];
    var hexDigits = "0123456789abcdef";
    for (var i = 0; i < 36; i++) {
      s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1);
    }
    s[14] = "4"; // bits 12-15 of the time_hi_and_version field to 0010
    s[19] = hexDigits.substr((s[19] & 0x3) | 0x8, 1); // bits 6-7 of the clock_seq_hi_and_reserved to 01
    s[8] = s[13] = s[18] = s[23] = "-";

    var uuid = s.join("");
    return uuid;
  }; ////无

  //判断某个点是否在圆内
  CommonFunction.isIn = function (x0, y0, x, y, r) {
    //放大区域
    if ((x0 - x) * (x0 - x) + (y0 - y) * (y0 - y) < r * r) return true;
    else return false;
  };
  //判断是否在圆的边沿
  CommonFunction.isOn = function (x0, y0, x, y, r) {
    //放大镜边缘
    if ((x0 - x) * (x0 - x) + (y0 - y) * (y0 - y) == r * r) return true;
    else return false;
  };
  MyFA.CommonFunction = CommonFunction;
})();
