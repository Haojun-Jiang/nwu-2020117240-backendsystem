this.MyFurnitureAssistant = this.MyFurnitureAssistant || {};
// 定义别名(快捷名)：
if (typeof this.MyFA === "undefined") {
  this.MyFA = this.MyFurnitureAssistant;
}
//照片场景Model
(function () {
  function PhotoSceneModel(image) {
    //image:房间照片

    // 脏标志：如果文件有改动，则置为true；新建文件不用理睬这个标志
    this.dirty = false;
    //原始场景照片对象
    this.image;
    //原始场景照片像素宽度
    this.imageWidth;
    //原始场景照片像素高度
    this.imageHeight;
    //场景地板铺设结果数组
    this.wallFloorSymbolArr = [];
    this.wallFloorSymbolArr[0] = { isStretched: false, floorUrl: "" };
    this.wallFloorSymbolArr[1] = { isStretched: false, floorUrl: "" };
    this.wallFloorSymbolArr[2] = { isStretched: false, floorUrl: "" };
    this.wallFloorSymbolArr[3] = { isStretched: false, floorUrl: "" };
    this.wallFloorSymbolArr[4] = { isStretched: false, floorUrl: "" }; //目前最多五面墙

    //每像素长度（单位：mm/pix）
    this.LengthPerPix;
    //相机距离墙体的最远物理距离
    this.MaxDistance;
    //最远垂直线总长
    this.MaxVerticalLength;
    //最远横线总长
    this.MaxHorizontalLength;
    //左墙线物理距离
    this._p1p4;
    //右墙线物理距离
    this._p2p5;
    //左墙线与水平线的夹角
    this.pl;
    //右墙线与水平线的夹角
    this.pr;
    this.Out;
    //场景是否打开完成
    this.isOpenFinished = false;

    //场景缩放比例
    this.scale;
    //标注的墙高
    this.WallDenote;
    //场景灭点坐标
    this.DisappearedPoint;
    //场景在X方向的偏移角度（场景矫正时使用）
    this.OffsetAngleX;
    //场景在Y方向的偏移角度（场景矫正时使用）
    this.OffsetAngleY;

    //Original：原始矩阵
    this.Original;
    //原始矩阵的备份
    this.originalBackup;
    //Contour：轮廓图
    this.Contour;
    //Gray：灰度图矩阵
    this.Gray;
    //轮廓图的备份
    this.contourBackup;
    //墙线model
    this.WallLineModel;

    //家具model集合
    this.furModels = [];

    if (image != undefined) {
      this.image = image;
      this.imageWidth = image.width;
      this.imageHeight = image.height;

      //判断照片类型（横屏还是竖屏）
      if (this.imageWidth > this.imageHeight) {
        //如果宽>高，横屏
        this.PhotoType = 0;
      } else {
        //如果宽<高，竖屏
        this.PhotoType = 1;
      }
      //计算场景缩放比例
      this.setPhotoSceneScale();
    }
  }

  var p = PhotoSceneModel.prototype;

  //设置场景的缩放比例值
  p.setPhotoSceneScale = function () {
    ////横屏
    if (window.orientation == 90 || window.orientation == -90) {
      //如果屏幕宽高是在竖屏时获取的
      if (window.innerWidth < window.innerHeight) {
        //则peiqiValue.screenHeight / this.imageWidth
        this.scale = window.innerHeight / (this.imageWidth / 2);
      }
      //如果屏幕宽高是在横屏时获取的
      else {
        //则peiqiValue.screenWidth/this.imageWidth
        this.scale = window.innerWidth / (this.imageWidth / 2);
      }
    }

    //竖屏
    if (window.orientation == 0 || window.orientation == 180) {
      //如果屏幕宽高是在横屏时获取的
      if (window.innerWidth > window.innerHeight) {
        //则peiqiValue.screenWidth/this.imageHeight
        this.scale = window.innerHeight / (this.imageWidth / 2);
      }
      //如果屏幕宽高是在竖屏时获取的
      else {
        //则peiqiValue.screenHeight / this.imageHeight
        this.scale = window.innerWidth / (this.imageWidth / 2);
      }
    }

    ///*全屏模式*/
    //////横屏
    //if (window.orientation == 90 || window.orientation == -90) {
    //    //如果屏幕宽高是在竖屏时获取的
    //    if (window.innerWidth < window.innerHeight) {
    //        //则peiqiValue.screenHeight / this.imageWidth
    //        this.scale = (window.innerHeight) / (this.imageWidth / 2);
    //    }
    //        //如果屏幕宽高是在横屏时获取的
    //    else {
    //        //则peiqiValue.screenWidth/this.imageWidth
    //        this.scale = (window.innerWidth) / (this.imageWidth / 2);
    //    }
    //}

    ////竖屏
    //if (window.orientation == 0 || window.orientation == 180) {
    //    //如果屏幕宽高是在横屏时获取的
    //    if (window.innerWidth > window.innerHeight) {
    //        //则peiqiValue.screenWidth/this.imageHeight
    //        this.scale = (window.innerWidth - 25) / (this.imageHeight / 2);
    //    }
    //        //如果屏幕宽高是在竖屏时获取的
    //    else {
    //        //则peiqiValue.screenHeight / this.imageHeight
    //        this.scale = (window.innerHeight - 25) / (this.imageHeight / 2);
    //    }
    //}
    ///*全屏模式*/

    if (window.orientation == undefined) {
      window.orientation = 0;
      this.scale = (window.innerHeight - 10) / (this.imageHeight / 2);
    }
  };

  //在地板铺设模式下设置场景比例（按屏幕宽进行缩放）
  p.setPhotoSceneScaleWhenFloor = function () {
    ////横屏
    if (window.orientation == 90 || window.orientation == -90) {
      //如果屏幕宽高是在竖屏时获取的
      if (window.innerWidth < window.innerHeight) {
        //alert(111)
        //则peiqiValue.screenHeight / this.imageWidth
        this.scale = (window.innerWidth - 25) / (this.imageHeight / 2);
      }
      //如果屏幕宽高是在横屏时获取的
      else {
        //alert(222)
        //则peiqiValue.screenWidth/this.imageWidth
        this.scale = (window.innerHeight - 25) / (this.imageHeight / 2);
      }
    }

    //竖屏
    if (window.orientation == 0 || window.orientation == 180) {
      //如果屏幕宽高是在横屏时获取的
      if (window.innerWidth > window.innerHeight) {
        //alert(555)
        //则peiqiValue.screenWidth/this.imageHeight
        this.scale = window.innerHeight / (this.imageWidth / 2);
      }
      //如果屏幕宽高是在竖屏时获取的
      else {
        //alert(666)
        //则peiqiValue.screenHeight / this.imageHeight
        this.scale = window.innerWidth / (this.imageWidth / 2);
      }
    }
  };

  //计算照片的各种距离、角度等
  p.CalculateDistanceAndAngle = function () {
    //判断最远墙线的实际高度是否已被标注
    if (typeof this.WallDenote != "undefined") {
      var walls = this.WallLineModel.walls;
      //如果标注的高度是竖线
      if (Math.abs(walls[2] - walls[0]) <= 100) {
        //alert("竖线");
        //每像素长度（单位：mm/pix）=标注的尺寸/Math.abs(y1-y2)
        this.LengthPerPix = this.WallDenote / Math.abs(walls[3] - walls[1]);
      }
      //如果标注的高度是横线
      else {
        //alert("横线");
        //每像素长度（单位：mm/pix）=标注的尺寸/Math.abs(x1-x2)
        this.LengthPerPix = this.WallDenote / Math.abs(walls[2] - walls[0]);
      }

      //最远横线总长=照片像素宽度*每像素长度
      this.MaxHorizontalLength = (this.imageWidth / 2) * this.LengthPerPix;
      //最远垂直线总长=照片像素高度*每像素长度
      this.MaxVerticalLength = (this.imageHeight / 2) * this.LengthPerPix;

      //照片横屏
      if (this.PhotoType == 0) {
        //this.MaxDistance = this.MaxHorizontalLength / 2 / Math.tan(31 * Math.PI * 2 / 360);
        this.MaxDistance =
          this.MaxVerticalLength / 2 / Math.tan((31 * Math.PI * 2) / 360);
        //this._p1p4 = Math.tan(59 * Math.PI * 2 / 360) * this._p1p6;
        //this._p2p5 = Math.tan(59 * Math.PI * 2 / 360) * this._p2p7;
      }
      //照片竖屏
      else {
        //this.MaxDistance = this.MaxHorizontalLength / 2 / Math.tan(25 * Math.PI * 2 / 360);
        this.MaxDistance =
          this.MaxVerticalLength / 2 / Math.tan((25 * Math.PI * 2) / 360);
        //this._p1p4 = Math.tan(65 * Math.PI * 2 / 360) * this._p1p6;
        //this._p2p5 = Math.tan(65 * Math.PI * 2 / 360) * this._p2p7;
      }

      var p1y = walls[1] <= walls[3] ? walls[1] : walls[3];
      var p2y = walls[1] <= walls[3] ? walls[3] : walls[1];

      this._p1p3h = Math.abs(p1y - this.imageHeight / 2) * this.LengthPerPix;
      this._p3p2h = Math.abs(this.imageHeight / 2 - p2y) * this.LengthPerPix;
      if (this.PhotoType == 0) {
        this.Out = this._p3p2h * Math.tan((25 * Math.PI * 2) / 360);
        //this.Out = this._p1p3h * Math.tan(25 * Math.PI * 2 / 360);
      } else {
        this.Out = this._p3p2h * Math.tan((31 * Math.PI * 2) / 360);
        //this.Out = this._p1p3h * Math.tan(31 * Math.PI * 2 / 360);
      }

      var arr = this.WallLineModel.arr;

      if (arr.length == 8) {
        var p1x = arr[5].Px;
        var p2x = arr[6].Px;

        this._p1p3 = Math.abs(p1x - this.imageWidth / 4) * this.LengthPerPix;
        this._p3p2 = Math.abs(this.imageWidth / 4 - p2x) * this.LengthPerPix;
        //最远墙线左边距（mm）
        this._p1p6 = this.MaxHorizontalLength / 2 - this._p1p3;
        //最远墙线右边距（mm）
        this._p2p7 = this.MaxHorizontalLength / 2 - this._p3p2;

        //计算左墙线和右墙线
        //照片横屏
        if (this.PhotoType == 0) {
          this._p1p4 = Math.tan((59 * Math.PI * 2) / 360) * this._p1p6;
          this._p2p5 = Math.tan((59 * Math.PI * 2) / 360) * this._p2p7;
        }
        //照片竖屏
        else {
          this._p1p4 = Math.tan((65 * Math.PI * 2) / 360) * this._p1p6;
          this._p2p5 = Math.tan((65 * Math.PI * 2) / 360) * this._p2p7;
        }

        //计算pl和pr
        var verY = Math.abs(
          this.DisappearedPoint.Py - (arr[5].Py + arr[6].Py) * 0.5
        );
        var herXLeft = Math.abs(this.DisappearedPoint.Px - arr[5].Px);
        var herXRight = Math.abs(this.DisappearedPoint.Px - arr[6].Px);

        this.pl = (Math.atan(verY / herXLeft) / ((Math.PI * 2) / 360)) * -1;
        this.pr = Math.atan(verY / herXRight) / ((Math.PI * 2) / 360);
      } else {
        //计算pl和pr
        var a =
          Math.abs(this.DisappearedPoint.Px - this.imageWidth * 0.5) *
          this.LengthPerPix;
        var x =
          (a * (this.MaxDistance - this.Out)) /
          (this.MaxHorizontalLength * 0.5 + a);
        this.pr = Math.atan(x / a) / ((Math.PI * 2) / 360);
        this.pl = (90 - this.pr) * -1;

        var left = (arr[4].Px - arr[3].Px) * this.LengthPerPix;
        var right = (arr[5].Px - arr[4].Px) * this.LengthPerPix;

        var p1p4 = MyFA.CommonFunction.getDistanceOfPointToPoint(
          arr[3].Px,
          arr[3].Py,
          arr[4].Px,
          arr[4].Py
        );
        var p2p5 = MyFA.CommonFunction.getDistanceOfPointToPoint(
          arr[5].Px,
          arr[5].Py,
          arr[4].Px,
          arr[4].Py
        );

        //计算左墙线和右墙线
        this._p1p4 = (p1p4 * left) / (arr[4].Px - arr[3].Px);
        this._p2p5 = (p2p5 * right) / (arr[5].Px - arr[4].Px);

        //this._p1p4 = left;
        //this._p2p5 = right;

        //this._p1p4 = left/ (Math.cos(this.pl*(-1) * 2 * Math.PI / 360));
        //this._p2p5 = right / (Math.cos(this.pr  * 2 * Math.PI / 360));
      }
    }
  };

  //识别墙体，返回一个数组
  p.RecognizeWall = function () {
    var mat0 = cv.imageShrink(cv.imread(this.image));
    //Original：原始图
    this.Original = mat0;
    this.originalBackup = mat0.clone();

    //由原始矩阵推出轮廓图、灰度图等
    this.GetMatsFromOriginal(mat0);

    //var mat8 = cv.imageShrink(cv.imageShrink(this.Contour));

    //var ratio = cv.ratio(mat8);
    //var thredhold = 2.379 * Math.max(mat8.col, mat8.row) * ratio + 25;
    //if (thredhold > Math.min(mat8.col, mat8.row) * 2 / 3) thredhold = Math.min(mat8.col, mat8.row) * 2 / 3;

    ////再次合并直线
    //var lines = cv.hough2(mat8, thredhold);
    //var result = mergeLines(lines, mat8);

    //var scalorRatio = 4;
    //var walls = cv.recognizingWall(result, mat8);
    ////返回的结果统一乘以缩放比例，目的返回原始图片的坐标
    //for (var i = 0; i < walls.length; i++) {
    //    walls[i] = walls[i] * scalorRatio;
    //}
    //PhotoSceneModel.result = walls;
    var walls = [
      (0.5 * this.imageWidth) / 2,
      (0.3 * this.imageHeight) / 2,
      (0.5 * this.imageWidth) / 2,
      (0.7 * this.imageHeight) / 2,
    ];
    return walls;
  };

  //由原始矩阵推出轮廓图、灰度图等
  p.GetMatsFromOriginal = function (originalMat) {
    var mat = cv.cvtColor(originalMat, CV_RGBA2GRAY);
    var mat2 = cv.convertScaleAbs(cv.Scharr(mat, 1, 0));
    var mat3 = cv.convertScaleAbs(cv.Scharr(mat, 0, 1));
    var mat4 = cv.addWeighted(mat2, 0.5, mat3, 0.5);
    var mat5 = cv.threshold(mat4, 60);
    //加黑边
    var mat6 = cv.blackborder(mat5);
    //滤波降噪
    var mat7 = cv.erodeByArea(mat6, 80);

    //Contour：轮廓图
    this.Contour = mat7;

    //Gray：灰度图矩阵
    this.Gray = mat;
    ////原始图的备份
    //this.originalBackup = originalMat.clone();
    //轮廓图的备份
    this.contourBackup = MyFA.CommonFunction.clone(mat7);
  };

  //合并直线
  function mergeLines(lines, mat8) {
    //再次合并直线
    var merg = Math.min(mat8.col, mat8.row) / 10; // 合并的距离阈值
    var result = new Array(),
      counter = 0;
    for (var m = 0; m < lines.length; m = m + 4) {
      if (lines[m] > -1) {
        result[counter] = lines[m];
        result[counter + 1] = lines[m + 1];
        result[counter + 2] = lines[m + 2];
        result[counter + 3] = lines[m + 3];
        for (var n = m + 4; n < lines.length; n = n + 4) {
          if (lines[n] > -1) {
            if (
              Math.abs(result[counter] - lines[n]) +
                Math.abs(result[counter + 1] - lines[n + 1]) <
                merg &&
              Math.abs(result[counter + 2] - lines[n + 2]) +
                Math.abs(result[counter + 3] - lines[n + 3]) <
                merg
            ) {
              result[counter] = (result[counter] + lines[n]) / 2;
              result[counter + 1] = (result[counter + 1] + lines[n + 1]) / 2;
              result[counter + 2] = (result[counter + 2] + lines[n + 2]) / 2;
              result[counter + 3] = (result[counter + 3] + lines[n + 3]) / 2;
              lines[n] = lines[n + 1] = lines[n + 2] = lines[n + 3] = -1;
            }
          }
        }
        counter += 4;
      }
    }
    return result;
  }

  // 计算灭点，返回灭点的坐标
  p.GetDisappearedPoints = function () {
    var arr = this.WallLineModel.arr;
    //正对墙角的情况（6点5线）
    if (arr.length == 6) {
      //arr是对墙体识别结果进行排列、剔除以后的点集合
      //arr[0], arr[1], arr[2]分别为上半部分从左至右的三个点
      //arr[3], arr[4], arr[5]分别为下半部分从左至右的三个点
      //左边墙灭点
      var dpOfLeftWall = MyFA.CommonFunction.segmentsIntr(
        arr[1],
        arr[2],
        arr[4],
        arr[5]
      );
      //右边墙灭点
      var dpOfRightWall = MyFA.CommonFunction.segmentsIntr(
        arr[0],
        arr[1],
        arr[3],
        arr[4]
      );
      //场景灭点：左右墙灭点连线与竖直墙线交点
      //var dp = MyFA.CommonFunction.segmentsIntr(dpOfLeftWall, dpOfRightWall, arr[1], arr[4]);

      var midLinePoint1 = { Px: this.imageWidth / 4, Py: 0 };
      var midLinePoint2 = { Px: this.imageWidth / 4, Py: 100 };

      //场景灭点：左右墙灭点连线与照片中线交点
      var dp = MyFA.CommonFunction.segmentsIntr(
        dpOfLeftWall,
        dpOfRightWall,
        midLinePoint1,
        midLinePoint2
      );

      this.wa = [];
      this.wa.push(dp);

      //最终计算出来的灭点坐标
      this.DisappearedPoint = dp;
    }
    ////正对矩形墙面的情况（8点8线）
    if (arr.length == 8) {
      var wallType = this.WallLineModel.wallType;
      //正对墙面下计算灭点
      if (wallType == 0) {
        //arr是对墙体识别结果进行排列、剔除以后的点集合
        //arr[0], arr[1], arr[2], arr[3]分别为上半部分从左至右的四个点
        //arr[4], arr[5], arr[6], arr[7]分别为下半部分从左至右的四个点
        var x1 = arr[1].Px;
        var y1 = arr[1].Py;
        var p1 = MyFA.CommonFunction.segmentsIntr(
          arr[0],
          arr[1],
          arr[2],
          arr[3]
        );
        if (!p1) {
          x1 = p1.Px;
          y1 = p1.Py;
        }

        var x2 = arr[2].Px;
        var y2 = arr[2].Py;
        var p2 = MyFA.CommonFunction.segmentsIntr(
          arr[6],
          arr[7],
          arr[2],
          arr[3]
        );
        if (!p2) {
          x2 = p2.Px;
          y2 = p2.Py;
        }

        var x3 = arr[6].Px;
        var y3 = arr[6].Py;
        var p3 = MyFA.CommonFunction.segmentsIntr(
          arr[6],
          arr[7],
          arr[4],
          arr[5]
        );
        if (!p3) {
          x3 = p3.Px;
          y3 = p3.Py;
        }

        var x4 = arr[5].Px;
        var y4 = arr[5].Py;
        var p4 = MyFA.CommonFunction.segmentsIntr(
          arr[0],
          arr[1],
          arr[4],
          arr[5]
        );
        if (!p4) {
          x4 = p4.Px;
          y4 = p4.Py;
        }

        // 理论上4个灭点应该重合，但实际误差可能并不重合，所以平均一下
        var x = Math.round((x1 + x2 + x3 + x4) / 4);
        var y = Math.round((y1 + y2 + y3 + y4) / 4);

        this.wa = [];
        this.wa.push({ Px: x1, Py: y1 });
        this.wa.push({ Px: x2, Py: y2 });
        this.wa.push({ Px: x3, Py: y3 });
        this.wa.push({ Px: x4, Py: y4 });
        this.wa.push({ Px: x, Py: y });

        //最终计算出来的灭点坐标
        this.DisappearedPoint = { Px: x, Py: y };
      } else {
        /*  只有一面墙的情况下计算灭点*/
        var injectPoint = MyFA.CommonFunction.segmentsIntr(
          arr[1],
          arr[2],
          arr[5],
          arr[6]
        );
        //如果上下两条墙线无交点
        if (!injectPoint) {
          this.DisappearedPoint = {
            Px: (arr[1].Px + arr[2].Px) / 2,
            Py: (arr[1].Py + arr[5].Py) / 2,
          };
        }
        //如果上下两条墙线有交点
        else {
          this.DisappearedPoint = {
            Px: (arr[1].Px + arr[2].Px) / 2,
            Py: injectPoint.Py,
          };
        }
      }
    }
  };

  //（场景矫正）计算偏移角度
  p.CalculateOffsetAngle = function () {
    var lengthPerPix = this.LengthPerPix;
    var maxDistance = this.MaxDistance;

    var cmX = Math.abs(this.imageWidth * 0.25 - this.DisappearedPoint.Px);
    var cmY = Math.abs(this.imageHeight * 0.25 - this.DisappearedPoint.Py);

    var offsetAngleX =
      Math.atan((cmX * lengthPerPix) / maxDistance) / ((Math.PI * 2) / 360);
    var offsetAngleY =
      Math.atan((cmY * lengthPerPix) / maxDistance) / ((Math.PI * 2) / 360);

    var arr = this.WallLineModel.arr;

    if (arr.length == 8) {
      //偏右为负，偏左为正
      if (arr[5].Py > arr[6].Py) {
        offsetAngleX = offsetAngleX * -1;
        offsetAngleY = offsetAngleY * -1;
      }
    } else {
      var dpOfLeftWall = MyFA.CommonFunction.segmentsIntr(
        arr[1],
        arr[2],
        arr[4],
        arr[5]
      );
      //右边墙灭点
      var dpOfRightWall = MyFA.CommonFunction.segmentsIntr(
        arr[0],
        arr[1],
        arr[3],
        arr[4]
      );
      //偏右为负，偏左为正
      if (dpOfLeftWall.Py > dpOfRightWall.Py) {
        offsetAngleX = offsetAngleX * -1;
        offsetAngleY = offsetAngleY * -1;
      }
    }
    this.OffsetAngleX = offsetAngleX;
    this.OffsetAngleY = offsetAngleY;
  };

  //（撤销地板时）将original矩阵和contour矩阵恢复为原始值
  p.restoreOriginalMat = function () {
    ////Contour：轮廓图
    //this.Contour = MyFA.CommonFunction.clone(this.contourBackup);
    //Original：原始图
    this.Original = this.originalBackup.clone();
  };

  // contour：原始轮廓图矩阵
  // original：原始照片矩阵
  // gray：原始照片的灰度图矩阵
  //seedsArray:手指触摸时所经过的点的集合
  //wallLocation:墙面位置标识
  // repetition：平铺方向：1、按纹理图片宽高与房间宽高一致方式重复贴图；2、按纹理图片高宽与房间宽高对应方式重复贴图
  p.prepaireFill = function (
    contour,
    original,
    gray,
    seedsArray,
    wallLocation,
    floorMode,
    isSaveShadow
  ) {
    var _this = this;
    _this.isFilled = false;
    var arr = this.WallLineModel.arr;

    var FloodWidith,
      FloodHeight /*地面宽高*/,
      TileWidith = window.floorWidth,
      TileHeight = window.floorHeight; /*瓷砖宽高*/

    //alert("TileWidith :" + TileWidith);
    //alert("TileHeight :" + TileHeight);

    repetition = 1 /*1、正铺；2、竖铺*/;

    var stretchTextile; //任意伸拉纹理图
    //用于临时存放伸拉结果的canvas
    var canvasPrepair = document.createElement("canvas");

    var upleft, upright, downright, downleft; //拉伸的四点坐标

    var stretchMatOffsetX, stretchMatOffsetY; //拉伸结果矩阵相对于（0,0）点的X、Y偏移量

    //根据墙面位置确定canvas尺寸、地面宽高以及四点坐标
    switch (wallLocation) {
      case 0:
        if (arr.length == 8) {
          (FloodWidith = (arr[3].Px - arr[0].Px) * this.LengthPerPix),
            (FloodHeight = this._p1p4);

          //解出[arr[0],arr[1]两点构成直线的方程]
          var equationLeftWall = MyFA.CommonFunction.calLinearEquationByPoints(
            arr[0],
            arr[1]
          );
          if (equationLeftWall.b != 0) {
            FloodHeight = this._p1p4;
          }
          //如果只有一面墙的时候
          else {
            FloodHeight = (arr[1].Py - arr[0].Py) * this.LengthPerPix;
          }

          var pt1 = { Px: 0, Py: 0 };
          var pt2 = { Px: this.imageWidth / 2, Py: 0 };
          var ulPt = MyFA.CommonFunction.segmentsIntr(pt1, pt2, arr[0], arr[1]);
          var urPt = MyFA.CommonFunction.segmentsIntr(pt1, pt2, arr[2], arr[3]);

          upleft = new cvv.Vector(0, 0);
          upright = new cvv.Vector(Math.floor(urPt.Px - ulPt.Px), 0);
          downright = new cvv.Vector(
            Math.floor(arr[2].Px - ulPt.Px),
            Math.floor(arr[2].Py)
          );
          downleft = new cvv.Vector(
            Math.floor(arr[1].Px - ulPt.Px),
            Math.floor(arr[1].Py)
          );

          canvasPrepair.width = Math.floor(urPt.Px - ulPt.Px);
          canvasPrepair.height =
            Math.floor(arr[1].Py) >= Math.floor(arr[2].Py)
              ? Math.floor(arr[1].Py)
              : Math.floor(arr[2].Py);

          stretchMatOffsetX = Math.floor(ulPt.Px);
          stretchMatOffsetY = 0;
        } else {
          FloodWidith = this._p1p4;
          FloodHeight = this._p2p5;
          //alert("FloodWidith :" + FloodWidith);
          //alert("FloodHeight :" + FloodHeight);

          var pt1 = { Px: 0, Py: 0 };
          var pt2 = { Px: this.imageWidth / 2, Py: 0 };
          var ulPt = MyFA.CommonFunction.segmentsIntr(pt1, pt2, arr[0], arr[1]);
          var urPt = MyFA.CommonFunction.segmentsIntr(pt1, pt2, arr[1], arr[2]);

          upleft = new cvv.Vector(0, Math.floor(arr[1].Py));
          upright = new cvv.Vector(Math.floor(arr[1].Px - ulPt.Px), 0);
          downright = new cvv.Vector(
            Math.floor(urPt.Px - ulPt.Px),
            Math.floor(arr[1].Py)
          );
          downleft = new cvv.Vector(
            Math.floor(arr[1].Px - ulPt.Px),
            Math.floor(arr[1].Py) * 2
          );

          //canvasPrepair.width = Math.floor((urPt.Px - ulPt.Px));
          //canvasPrepair.height = Math.floor(arr[1].Py) * 2;

          canvasPrepair.width = Math.floor(
            MyFA.CommonFunction.getDistanceOfPointToPoint(
              arr[1].Px,
              arr[1].Py,
              urPt.Px,
              urPt.Py
            )
          );
          canvasPrepair.height = Math.floor(
            MyFA.CommonFunction.getDistanceOfPointToPoint(
              arr[1].Px,
              arr[1].Py,
              ulPt.Px,
              ulPt.Py
            )
          );

          stretchMatOffsetX = Math.floor(ulPt.Px);
          stretchMatOffsetY = Math.floor(arr[1].Py) * -1;
        }
        break;
      case 1:
        if (arr.length == 8) {
          FloodWidith = this._p2p5;
          FloodHeight = this.WallDenote;

          var pt1 = { Px: this.imageWidth / 2, Py: 0 };
          var pt2 = { Px: this.imageWidth / 2, Py: this.imageHeight / 2 };
          var urPt = MyFA.CommonFunction.segmentsIntr(pt1, pt2, arr[2], arr[3]);
          var drPt = MyFA.CommonFunction.segmentsIntr(pt1, pt2, arr[6], arr[7]);

          upleft = new cvv.Vector(0, Math.floor(arr[2].Py - urPt.Py));
          upright = new cvv.Vector(Math.floor(urPt.Px - arr[2].Px), 0);
          downright = new cvv.Vector(
            Math.floor(drPt.Px - arr[2].Px),
            Math.floor(drPt.Py - urPt.Py)
          );
          downleft = new cvv.Vector(0, Math.floor(arr[6].Py - urPt.Py));

          canvasPrepair.width = Math.floor(this.imageWidth / 2 - arr[2].Px);
          canvasPrepair.height = Math.floor(drPt.Py - urPt.Py);

          stretchMatOffsetX = Math.floor(arr[2].Px);
          stretchMatOffsetY = Math.floor(urPt.Py);
        } else {
          //FloodWidith = this._p1p4;
          FloodWidith = this._p2p5;
          FloodHeight = this.WallDenote;

          var pt1 = { Px: this.imageWidth / 2, Py: 0 };
          var pt2 = { Px: this.imageWidth / 2, Py: this.imageHeight / 2 };

          var urPt = MyFA.CommonFunction.segmentsIntr(pt1, pt2, arr[1], arr[2]);
          var drPt = MyFA.CommonFunction.segmentsIntr(pt1, pt2, arr[4], arr[5]);

          upleft = new cvv.Vector(0, Math.floor(arr[1].Py - urPt.Py));
          upright = new cvv.Vector(Math.floor(urPt.Px - arr[1].Px), 0);
          downright = new cvv.Vector(
            Math.floor(drPt.Px - arr[1].Px),
            Math.floor(drPt.Py - urPt.Py)
          );
          downleft = new cvv.Vector(0, Math.floor(arr[4].Py - urPt.Py));

          canvasPrepair.width = Math.floor(this.imageWidth / 2 - arr[1].Px);
          canvasPrepair.height = Math.floor(drPt.Py - urPt.Py);

          stretchMatOffsetX = Math.floor(arr[1].Px);
          stretchMatOffsetY = Math.floor(urPt.Py);
        }
        break;
      case 2:
        if (arr.length == 8) {
          FloodWidith = (arr[2].Px - arr[1].Px) * this.LengthPerPix;

          //解出[arr[4],arr[5]两点构成直线的方程]
          var equationLeftWall = MyFA.CommonFunction.calLinearEquationByPoints(
            arr[4],
            arr[5]
          );
          if (equationLeftWall.b != 0) {
            FloodHeight = this._p1p4 >= this._p2p5 ? this._p1p4 : this._p2p5;
          }
          //如果只有一面墙的时候
          else {
            FloodHeight = (arr[4].Py - arr[5].Py) * this.LengthPerPix;
          }

          var pt1 = { Px: 0, Py: this.imageHeight / 2 };
          var pt2 = { Px: this.imageWidth / 2, Py: this.imageHeight / 2 };
          var drPt = MyFA.CommonFunction.segmentsIntr(pt1, pt2, arr[6], arr[7]);
          var dlPt = MyFA.CommonFunction.segmentsIntr(pt1, pt2, arr[4], arr[5]);

          downright = new cvv.Vector(
            Math.floor(drPt.Px - dlPt.Px),
            Math.floor(drPt.Py - arr[5].Py)
          );
          downleft = new cvv.Vector(0, Math.floor(dlPt.Py - arr[5].Py));
          upleft = new cvv.Vector(Math.floor(arr[5].Px - dlPt.Px), 0);
          upright = new cvv.Vector(Math.floor(arr[6].Px - dlPt.Px), 0);

          canvasPrepair.width = Math.floor(drPt.Px - dlPt.Px);
          canvasPrepair.height = Math.floor(this.imageHeight / 2 - arr[5].Py);

          stretchMatOffsetX = Math.floor(dlPt.Px);
          stretchMatOffsetY =
            Math.floor(arr[5].Py) <= Math.floor(arr[6].Py)
              ? Math.floor(arr[5].Py)
              : Math.floor(arr[6].Py);
        } else {
          FloodWidith = this._p1p4;
          FloodHeight = this._p2p5;

          var pt1 = { Px: 0, Py: this.imageHeight / 2 };
          var pt2 = { Px: this.imageWidth / 2, Py: this.imageHeight / 2 };
          var dlPt = MyFA.CommonFunction.segmentsIntr(pt1, pt2, arr[3], arr[4]);
          var drPt = MyFA.CommonFunction.segmentsIntr(pt1, pt2, arr[4], arr[5]);

          upleft = new cvv.Vector(
            0,
            Math.floor(this.imageHeight / 2 - arr[4].Py)
          );
          upright = new cvv.Vector(Math.floor(arr[4].Px - dlPt.Px), 0);
          downright = new cvv.Vector(
            Math.floor(drPt.Px - dlPt.Px),
            Math.floor(this.imageHeight / 2 - arr[4].Py)
          );
          downleft = new cvv.Vector(
            Math.floor(arr[4].Px - dlPt.Px),
            Math.floor(this.imageHeight / 2 - arr[4].Py) * 2
          );

          //canvasPrepair.width = Math.floor((drPt.Px - dlPt.Px));
          //canvasPrepair.height = Math.floor((this.imageHeight / 2 - arr[4].Py)) * 2;

          canvasPrepair.width = MyFA.CommonFunction.getDistanceOfPointToPoint(
            arr[4].Px,
            arr[4].Py,
            dlPt.Px,
            dlPt.Py
          );
          canvasPrepair.height = MyFA.CommonFunction.getDistanceOfPointToPoint(
            arr[4].Px,
            arr[4].Py,
            drPt.Px,
            drPt.Py
          );

          stretchMatOffsetX = Math.floor(dlPt.Px);
          stretchMatOffsetY = Math.floor(arr[4].Py);
        }
        break;
      case 3:
        if (arr.length == 8) {
          FloodWidith = this._p1p4;
          FloodHeight = this.WallDenote;

          var pt1 = { Px: 0, Py: 0 };
          var pt2 = { Px: 0, Py: this.imageHeight / 2 };
          var ulPt = MyFA.CommonFunction.segmentsIntr(pt1, pt2, arr[0], arr[1]);
          var dlPt = MyFA.CommonFunction.segmentsIntr(pt1, pt2, arr[4], arr[5]);

          upleft = new cvv.Vector(0, 0);
          upright = new cvv.Vector(
            Math.floor(arr[1].Px),
            Math.floor(arr[1].Py - ulPt.Py)
          );
          downright = new cvv.Vector(
            Math.floor(arr[5].Px),
            Math.floor(arr[5].Py - ulPt.Py)
          );
          downleft = new cvv.Vector(0, Math.floor(dlPt.Py - ulPt.Py));

          canvasPrepair.width =
            Math.floor(arr[1].Px) >= Math.floor(arr[5].Px)
              ? Math.floor(arr[1].Px)
              : Math.floor(arr[5].Px);
          canvasPrepair.height = Math.floor(dlPt.Py - ulPt.Py);

          stretchMatOffsetX = 0;
          stretchMatOffsetY = Math.floor(ulPt.Py);
        } else {
          FloodWidith = this._p1p4;
          FloodHeight = this.WallDenote;

          var pt1 = { Px: 0, Py: 0 };
          var pt2 = { Px: 0, Py: this.imageHeight / 2 };
          var ulPt = MyFA.CommonFunction.segmentsIntr(pt1, pt2, arr[0], arr[1]);
          var dlPt = MyFA.CommonFunction.segmentsIntr(pt1, pt2, arr[3], arr[4]);

          upleft = new cvv.Vector(0, 0);
          upright = new cvv.Vector(
            Math.floor(arr[1].Px),
            Math.floor(arr[1].Py - ulPt.Py)
          );
          downright = new cvv.Vector(
            Math.floor(arr[4].Px),
            Math.floor(arr[4].Py - ulPt.Py)
          );
          downleft = new cvv.Vector(0, Math.floor(dlPt.Py - ulPt.Py));

          canvasPrepair.width =
            Math.floor(arr[1].Px) >= Math.floor(arr[4].Px)
              ? Math.floor(arr[1].Px)
              : Math.floor(arr[4].Px);
          canvasPrepair.height = Math.floor(dlPt.Py - ulPt.Py);

          stretchMatOffsetX = 0;
          stretchMatOffsetY = Math.floor(ulPt.Py);
        }
        break;
      case 4:
        if (arr.length == 8) {
          FloodWidith = (arr[2].Px - arr[1].Px) * this.LengthPerPix;
          FloodHeight = this.WallDenote;

          upleft = new cvv.Vector(0, 0);
          upright = new cvv.Vector(Math.floor(arr[2].Px - arr[1].Px), 0);
          downright = new cvv.Vector(
            Math.floor(arr[2].Px - arr[1].Px),
            Math.floor(arr[5].Py - arr[1].Py)
          );
          downleft = new cvv.Vector(0, Math.floor(arr[5].Py - arr[1].Py));

          canvasPrepair.width = Math.floor(
            arr[2].Px - arr[1].Px >= arr[6].Px - arr[5].Px
              ? arr[2].Px - arr[1].Px
              : arr[6].Px - arr[5].Px
          );
          canvasPrepair.height = Math.floor(
            arr[5].Py - arr[1].Py >= arr[6].Py - arr[2].Py
              ? arr[5].Py - arr[1].Py
              : arr[6].Py - arr[2].Py
          );

          stretchMatOffsetX =
            Math.floor(arr[1].Px) <= Math.floor(arr[5].Px)
              ? Math.floor(arr[1].Px)
              : Math.floor(arr[5].Px);
          stretchMatOffsetY =
            Math.floor(arr[1].Py) <= Math.floor(arr[2].Py)
              ? Math.floor(arr[1].Py)
              : Math.floor(arr[2].Py);
        }
        break;
    }

    var ctxPrepair = canvasPrepair.getContext("2d");
    var img = new Image();
    //解决图片的跨域问题
    img.crossOrigin = "Anonymous";
    img.src = window.floorImgSrc;

    img.onload = function () {
      var canvasFill = document.createElement("canvas");
      var ctx2 = canvasFill.getContext("2d");

      //如下是平铺的程序代码 t==2 时进行竖铺
      if (repetition == 2) {
        //如果是地板
        if (window.installedType == 3) {
          canvasFill.width = canvasPrepair.width * (TileHeight / FloodHeight);

          canvasFill.height = canvasPrepair.height * (TileWidith / FloodWidith);
          //瓷砖的宽和高？
        }
        //如果是壁纸
        else {
          canvasFill.width = canvasPrepair.width * (TileHeight / FloodHeight);
          canvasFill.height =
            img.width >= canvasPrepair.height
              ? canvasPrepair.height
              : img.width;
        }

        ctx2.rotate((90 * Math.PI) / 180); //第二个canvas画布内容旋转90度
        ctx2.drawImage(img, 0, -img.height); //旋转后他会平移到取原点坐标到-img.height
        ctxPrepair.fillStyle = ctxPrepair.createPattern(canvasFill, "repeat"); //导入已经旋转好的第二个canvs画布进行平铺
      } else {
        //如果是地板
        if (window.installedType == 3) {
          canvasFill.width = Math.floor(
            canvasPrepair.width * (TileWidith / FloodWidith)
          );

          canvasFill.height = Math.floor(
            canvasPrepair.height * (TileHeight / FloodHeight)
          );
          if (
            canvasFill.width / img.width <= 1 &&
            canvasFill.height / img.height <= 1
          ) {
            ctx2.drawImage(img, 0, 0);
          } else {
            ctx2.drawImage(
              img,
              0,
              0,
              img.width,
              img.height,
              0,
              0,
              canvasFill.width,
              canvasFill.height
            );
          }

          ctxPrepair.fillStyle = ctxPrepair.createPattern(canvasFill, "repeat");
          ctxPrepair.fillRect(0, 0, canvasPrepair.width, canvasPrepair.height);
        }
        //如果是壁纸
        else {
          canvasFill.width = canvasPrepair.width * (TileWidith / FloodWidith);
          canvasFill.height = canvasPrepair.height * (TileHeight / FloodHeight);
          ctx2.drawImage(
            img,
            0,
            0,
            img.width,
            img.height,
            0,
            0,
            canvasFill.width,
            canvasFill.height
          );

          //alert("drawImage花费时间为：" + (t2.getTime() - t1.getTime()) / 1000 + "秒");

          ctxPrepair.fillStyle = ctxPrepair.createPattern(canvasFill, "repeat");
          ctxPrepair.fillRect(0, 0, canvasPrepair.width, canvasPrepair.height);
        }
      }

      var wallFloorSymbolArr = _this.wallFloorSymbolArr;

      //确保每面墙只伸拉一次（同一铺设内容下）
      //如果isStretched标识为false，或此时铺设内容和上一次铺设内容不一致，则必须重新进行伸拉
      if (
        !wallFloorSymbolArr[wallLocation].isStretched ||
        wallFloorSymbolArr[wallLocation].floorUrl != window.floorImgSrc
      ) {
        var mat10 = cv.imread(canvasPrepair);
        stretchTextile = cv.getTransformedBitmap(
          mat10,
          canvasPrepair.width,
          canvasPrepair.height,
          upleft,
          upright,
          downright,
          downleft
        );
        //伸拉过以后，将isStretched标识设置为ture,且floorUrl设为window.floorImgSrc
        wallFloorSymbolArr[wallLocation].isStretched = true;
        //保存该面墙的伸拉结果
        wallFloorSymbolArr[wallLocation].stretchTextile = stretchTextile;
        wallFloorSymbolArr[wallLocation].floorUrl = window.floorImgSrc;
        wallFloorSymbolArr[wallLocation].stretchMatOffsetX = stretchMatOffsetX;
        wallFloorSymbolArr[wallLocation].stretchMatOffsetY = stretchMatOffsetY;
      } else {
        stretchTextile = wallFloorSymbolArr[wallLocation].stretchTextile;
      }

      //判断地板的铺设模式
      switch (floorMode) {
        //如果选择的是填充模式
        case "0":
          try {
            //对位进行填充
            _this.seedFill(contour, original, seedsArray);
            _this.stretchResultLocation(
              contour,
              original,
              stretchTextile,
              stretchMatOffsetX,
              stretchMatOffsetY,
              isSaveShadow
            );
          } catch (e) {
            alert(e);
          }

          break;
        //如果选择的是画刷模式
        case "1":
          try {
            _this.stretchResultLocation1(
              original,
              stretchTextile,
              stretchMatOffsetX,
              stretchMatOffsetY,
              seedsArray,
              isSaveShadow
            );
          } catch (e) {
            alert(e);
          }

          break;
      }
      _this.isFilled = true;

      //var contourCanvas = document.getElementById("contourPic");
      //contourCanvas.width = stretchTextile.col;
      //contourCanvas.height = stretchTextile.row;
      //var ctx2 = contourCanvas.getContext("2d");
      //ctx2.putImageData(cv.RGBA2ImageData(stretchTextile), 0, 0);
    };
  };

  // 功能：根据种子像素所在位置进行区域填充
  // 参数：
  //     contour：轮廓图
  //     original：原始照片
  //     pixseeds：种子像素坐标数组，其中的元素类型为cvv.mypix
  // 说明：轮廓图上，照片轮廓是白点，像素亮度为255。识别的墙线需要合并到轮廓图上，像素亮度为250
  p.seedFill = function (contour, original, pixseeds) {
    var a = 0;
    var seeds = new Array();
    var OffsetY; // = y * contour.col;
    var x, y;

    for (var i = 0; i < pixseeds.length; i++) {
      if (
        pixseeds[i].X < 0 ||
        pixseeds[i].Y < 0 ||
        pixseeds[i].X >= contour.col ||
        pixseeds[i].Y >= contour.row
      )
        continue; //种子像素坐标不在图片内
      seeds.push(pixseeds[i]);
    }

    while (seeds.length > 0) {
      var pix123 = seeds.pop();
      (x = pix123.X), (y = pix123.Y);
      OffsetY = y * contour.col;
      contour.data[OffsetY + x] = 127; //127是已遍历标志；255是轮廓；250是墙线
      ++x;
      while (x < contour.col && contour.data[OffsetY + x] < 250) {
        //向右填充至边界
        a++;
        contour.data[OffsetY + x] = 127;
        ++x;
      }
      var Xright = x - 1; //保存最右边界
      x = pix123.X;
      --x;
      while (x >= 0 && contour.data[OffsetY + x] < 250) {
        //向左填充至边界
        a++;
        contour.data[OffsetY + x] = 127;
        --x;
      }
      var Xleft = x + 1; //保存最左边界

      //从最左边界向最右边界，扫描下一行
      x = Xleft;
      ++y;
      if (y < contour.row - 1) {
        OffsetY = y * contour.col;
        while (x <= Xright) {
          var Pflag = 0; //1表示可以填充，0表示到达边界处或已被填充过
          while (contour.data[OffsetY + x] < 127 && x < Xright) {
            //不是边界且未被填充
            if (Pflag == 0) Pflag = 1;
            ++x;
          }
          if (Pflag == 1) {
            //最右像素作为种子入栈
            if (x == Xright && contour.data[OffsetY + x] < 127)
              //到了最右，像素即没填充过，也不是边界
              seeds.push(new cvv.mypix(x, y));
            else seeds.push(new cvv.mypix(x - 1, y)); //像素填充过或是边界，或是边界且（填充过或是边界）
            Pflag = 0;
          }
          //跳过右边的孔和区域边界的凹陷处
          var Xcenter = x;
          while (contour.data[OffsetY + x] >= 127 && x < Xright) ++x;
          if (x == Xcenter) ++x;
        }
      }
      //从最左边界向最右边界，扫描上一行
      x = Xleft;
      y -= 2;
      if (y > 0) {
        OffsetY = y * contour.col;
        while (x <= Xright) {
          var Pflag = 0; //1表示可以填充，0表示到达边界处或已被填充过
          while (contour.data[OffsetY + x] < 127 && x < Xright) {
            //不是边界且未被填充
            if (Pflag == 0) Pflag = 1;
            ++x;
          }
          if (Pflag == 1) {
            //最右像素作为种子入栈
            if (x == Xright && contour.data[OffsetY + x] < 127)
              seeds.push(new cvv.mypix(x, y));
            else seeds.push(new cvv.mypix(x - 1, y));
            Pflag = 0;
          }
          //跳过右边的孔和区域边界的凹陷处
          var Xcenter = x;
          while (contour.data[OffsetY + x] >= 127 && x < Xright) ++x;
          if (x == Xcenter) ++x;
        }
      }
    }
    return contour;
  };

  //功能：对拉伸结果进行定位（填充模式下）
  p.stretchResultLocation = function (
    contour,
    original,
    stretchTextile,
    stretchMatOffsetX,
    stretchMatOffsetY,
    isSaveShadow
  ) {
    //对位进行填充
    //以墙线上最左上点坐标为起始点(ox,oy)开始遍历轮廓图，换算记此点在纹理图片上的像素点坐标
    //      换算方法：1、根据种子像素坐标确定所在墙面；
    //                2、找出最上的墙线顶角（若最上2顶角一样高，则选左上顶角）
    //                3、确定是左上顶点还是右上顶点
    //function fill(contour, origianl, stretchTextile, offsetX, offsetY) {
    //原始矩阵的备份，用以保存光影
    var originalBackup = this.originalBackup;
    var contourOffsetY,
      originalOffsetY,
      textileOffsetY,
      contourOffsetX,
      originalOffsetX,
      textileOffsetX;
    for (var y = 0; y < stretchTextile.row; y = y + 1) {
      //遍历纹理伸拉图片的所有像素
      //if (y >= contour.row) break;//如果纹理图超出轮廓图的高度，则结束
      if (y + stretchMatOffsetY > contour.row || y + stretchMatOffsetY < 0)
        continue;
      contourOffsetY = y * contour.col + stretchMatOffsetY * contour.col;
      originalOffsetY = contourOffsetY * 4;
      textileOffsetY = y * stretchTextile.col * 4;
      for (x = 0; x < stretchTextile.col; x = x + 1) {
        //if (x >= contour.col) break;//如果纹理图超出轮廓图的宽度，则遍历下一行
        if (x + stretchMatOffsetX > contour.col || x + stretchMatOffsetX < 0)
          continue;
        textileOffsetX = x * 4;
        if (stretchTextile.data[textileOffsetY + textileOffsetX + 3] == 0)
          continue;
        contourOffsetX = x + stretchMatOffsetX;
        originalOffsetX = contourOffsetX * 4;

        if (contourOffsetX < 0) {
          continue;
        }
        if (contour.data[contourOffsetY + contourOffsetX] == 127) {
          // 保留光影的贴
          if (isSaveShadow) {
            original.data[originalOffsetY + originalOffsetX] =
              stretchTextile.data[textileOffsetY + textileOffsetX] *
              (originalBackup.data[originalOffsetY + originalOffsetX] / 255 +
                0.3);
            original.data[originalOffsetY + originalOffsetX + 1] =
              stretchTextile.data[textileOffsetY + textileOffsetX + 1] *
              (originalBackup.data[originalOffsetY + originalOffsetX + 1] /
                255 +
                0.3);
            original.data[originalOffsetY + originalOffsetX + 2] =
              stretchTextile.data[textileOffsetY + textileOffsetX + 2] *
              (originalBackup.data[originalOffsetY + originalOffsetX + 2] /
                255 +
                0.3);
          } else {
            original.data[originalOffsetY + originalOffsetX] =
              stretchTextile.data[textileOffsetY + textileOffsetX];
            original.data[originalOffsetY + originalOffsetX + 1] =
              stretchTextile.data[textileOffsetY + textileOffsetX + 1];
            original.data[originalOffsetY + originalOffsetX + 2] =
              stretchTextile.data[textileOffsetY + textileOffsetX + 2];
          }
        }
      }
    }
  };

  //功能：对拉伸结果进行定位（笔刷模式下）
  p.stretchResultLocation1 = function (
    original,
    stretchTextile,
    stretchMatOffsetX,
    stretchMatOffsetY,
    seeds,
    isSaveShadow
  ) {
    //原始矩阵的备份，用以保存光影
    var originalBackup = this.originalBackup;
    var textileOffsetY, contourOffsetX, originalOffsetX, textileOffsetX;

    for (var y = 0; y < seeds.length; y = y + 1) {
      //遍历纹理伸拉图片的所有像素
      //计算该点所属的墙面
      var wallLocationOfSeed = this.getWallLocationByPoint(
        seeds[y].X * this.scale,
        seeds[y].Y * this.scale
      );

      //如果该点所属的墙面和手指按下时所属的墙面不一致
      if (wallLocationOfSeed != window.wallLocation) {
        var wallFloorSymbolArr = this.wallFloorSymbolArr;
        //如果该点所属的墙面，曾经伸拉过且地板url和现在所选的地板一致，则填充
        if (
          wallFloorSymbolArr[wallLocationOfSeed].isStretched &&
          wallFloorSymbolArr[wallLocationOfSeed].floorUrl == window.floorImgSrc
        ) {
          var stretchTextile1 =
            wallFloorSymbolArr[wallLocationOfSeed].stretchTextile;
          //定位原始矩阵和伸拉矩阵互相对应的像素点的索引
          originalOffsetY = seeds[y].Y * 4 * original.col;
          textileOffsetY =
            (seeds[y].Y -
              wallFloorSymbolArr[wallLocationOfSeed].stretchMatOffsetY) *
            4 *
            stretchTextile1.col;
          originalOffsetX = seeds[y].X * 4;
          textileOffsetX =
            (seeds[y].X -
              wallFloorSymbolArr[wallLocationOfSeed].stretchMatOffsetX) *
            4;

          //判断是否超出画布左右边界
          if (
            !(
              seeds[y].X >= original.col ||
              seeds[y].X <= 0 ||
              seeds[y].X - stretchMatOffsetX >= stretchTextile.col ||
              seeds[y].X - stretchMatOffsetX <= 0
            )
          ) {
            //如果像素点为黑色，则舍弃
            if (
              !(
                stretchTextile1.data[textileOffsetY + textileOffsetX] == 0 &&
                stretchTextile1.data[textileOffsetY + textileOffsetX + 1] ==
                  0 &&
                stretchTextile1.data[textileOffsetY + textileOffsetX + 2] == 0
              )
            ) {
              // 保留光影的贴
              if (isSaveShadow) {
                original.data[originalOffsetY + originalOffsetX] =
                  stretchTextile1.data[textileOffsetY + textileOffsetX] *
                  (originalBackup.data[originalOffsetY + originalOffsetX] /
                    255 +
                    0.3);
                original.data[originalOffsetY + originalOffsetX + 1] =
                  stretchTextile1.data[textileOffsetY + textileOffsetX + 1] *
                  (originalBackup.data[originalOffsetY + originalOffsetX + 1] /
                    255 +
                    0.3);
                original.data[originalOffsetY + originalOffsetX + 2] =
                  stretchTextile1.data[textileOffsetY + textileOffsetX + 2] *
                  (originalBackup.data[originalOffsetY + originalOffsetX + 2] /
                    255 +
                    0.3);
              }
              // 不保留光影的贴
              else {
                original.data[originalOffsetY + originalOffsetX] =
                  stretchTextile1.data[textileOffsetY + textileOffsetX];
                original.data[originalOffsetY + originalOffsetX + 1] =
                  stretchTextile1.data[textileOffsetY + textileOffsetX + 1];
                original.data[originalOffsetY + originalOffsetX + 2] =
                  stretchTextile1.data[textileOffsetY + textileOffsetX + 2];
              }
            }
          }
        }
      } else {
        //判断是否超出画布左右边界
        if (
          !(
            seeds[y].X >= original.col ||
            seeds[y].X <= 0 ||
            seeds[y].X - stretchMatOffsetX >= stretchTextile.col ||
            seeds[y].X - stretchMatOffsetX <= 0
          )
        ) {
          //定位原始矩阵和伸拉矩阵互相对应的像素点的索引
          originalOffsetY = seeds[y].Y * 4 * original.col;
          textileOffsetY =
            (seeds[y].Y - stretchMatOffsetY) * 4 * stretchTextile.col;
          originalOffsetX = seeds[y].X * 4;
          textileOffsetX = (seeds[y].X - stretchMatOffsetX) * 4;

          //如果像素点为黑色，则舍弃
          if (
            !(
              stretchTextile.data[textileOffsetY + textileOffsetX] == 0 &&
              stretchTextile.data[textileOffsetY + textileOffsetX + 1] == 0 &&
              stretchTextile.data[textileOffsetY + textileOffsetX + 2] == 0
            )
          ) {
            // 保留光影的贴
            if (isSaveShadow) {
              original.data[originalOffsetY + originalOffsetX] =
                stretchTextile.data[textileOffsetY + textileOffsetX] *
                (originalBackup.data[originalOffsetY + originalOffsetX] / 255 +
                  0.3);
              original.data[originalOffsetY + originalOffsetX + 1] =
                stretchTextile.data[textileOffsetY + textileOffsetX + 1] *
                (originalBackup.data[originalOffsetY + originalOffsetX + 1] /
                  255 +
                  0.3);
              original.data[originalOffsetY + originalOffsetX + 2] =
                stretchTextile.data[textileOffsetY + textileOffsetX + 2] *
                (originalBackup.data[originalOffsetY + originalOffsetX + 2] /
                  255 +
                  0.3);
            }
            // 不保留光影的贴
            else {
              original.data[originalOffsetY + originalOffsetX] =
                stretchTextile.data[textileOffsetY + textileOffsetX];
              original.data[originalOffsetY + originalOffsetX + 1] =
                stretchTextile.data[textileOffsetY + textileOffsetX + 1];
              original.data[originalOffsetY + originalOffsetX + 2] =
                stretchTextile.data[textileOffsetY + textileOffsetX + 2];
            }
          }
        }
      }
    }
  };

  //获取缩放后的照片指定区域的像素数据（目的：支持放大镜功能）
  p.getImageDataForMagnifier = function () {
    var iCtx = MyFA.MainController.resultPic.canvas.getContext("2d");
    this.imageDataLeft = iCtx.getImageData(
      0,
      0,
      MyFA.Magnifier.r * 2,
      MyFA.Magnifier.r * 2
    );
    this.imageDataRight = iCtx.getImageData(
      Math.floor(
        MyFA.MainController.resultPic.canvas.width - MyFA.Magnifier.r * 2
      ),
      0,
      MyFA.Magnifier.r * 2,
      MyFA.Magnifier.r * 2
    );
  };

  //确定某个点所处的墙面
  p.getWallLocationByPoint = function (ex, ey) {
    var scale = this.scale; //场景缩放比例

    var upLine, downLine;
    var yInUpLine, yInDownLine;

    //wallLocation：墙面位置标识
    //0：房顶
    //1：右墙
    //2：地面
    //3：左墙
    //4：正面墙（目前仅限于正对墙面的情况）
    var wallLocation;
    var arr = this.WallLineModel.arr;

    //如果是正对墙面的情况 ，首先两条竖直墙线作为区分X坐标的分界
    if (arr.length == 8) {
      //如果ex小于左边的竖直线
      if (ex < (arr[1].Px + arr[5].Px) * 0.5 * scale) {
        //解出上下两条线的方程
        upLine = MyFA.CommonFunction.calLinearEquationByPoints(arr[0], arr[1]);
        downLine = MyFA.CommonFunction.calLinearEquationByPoints(
          arr[4],
          arr[5]
        );
        //yInUpLine = X坐标在直线(arr[0], arr[1])上的y坐标
        yInUpLine = (upLine.c * -1 - upLine.a * (ex / scale)) / upLine.b;
        //yInDownLine = X坐标在直线(arr[4], arr[5])上的y坐标
        yInDownLine =
          (downLine.c * -1 - downLine.a * (ex / scale)) / downLine.b;

        //如果ey / scale < yInUpLine，则点击的是房顶
        if (ey / scale < yInUpLine) {
          wallLocation = 0;
        }
        //如果ey / scale > yInDownLine，则点击的是地面
        else if (ey / scale > yInDownLine) {
          wallLocation = 2;
        }
        //否则，点击的是左墙
        else {
          wallLocation = 3;
        }
      }
      //如果ex大于右边的竖直线
      else if (ex > (arr[2].Px + arr[6].Px) * 0.5 * scale) {
        upLine = MyFA.CommonFunction.calLinearEquationByPoints(arr[2], arr[3]);
        downLine = MyFA.CommonFunction.calLinearEquationByPoints(
          arr[6],
          arr[7]
        );
        //yInUpLine = X坐标在直线(arr[2], arr[3])上的y坐标
        yInUpLine = (upLine.c * -1 - upLine.a * (ex / scale)) / upLine.b;
        //yInDownLine = X坐标在直线(arr[6], arr[7])上的y坐标
        yInDownLine =
          (downLine.c * -1 - downLine.a * (ex / scale)) / downLine.b;
        //如果ey / scale < yInUpLine，则点击的是房顶
        if (ey / scale < yInUpLine) {
          wallLocation = 0;
        }
        //如果ey / scale > yInDownLine，则点击的是地面
        else if (ey / scale > yInDownLine) {
          wallLocation = 2;
        }
        //否则，点击的是右墙
        else {
          wallLocation = 1;
        }
      }
      //如果ex大于左边的竖直线，而小于右边的竖直线
      else {
        yInUpLine = (arr[1].Py + arr[2].Py) * 0.5;
        yInDownLine = (arr[5].Py + arr[6].Py) * 0.5;
        //如果ey / scale < yInUpLine，则点击的是房顶
        if (ey / scale < yInUpLine) {
          wallLocation = 0;
        }
        //如果ey / scale > yInDownLine，则点击的是地面
        else if (ey / scale > yInDownLine) {
          wallLocation = 2;
        }
        //否则，点击的是正面墙
        else {
          wallLocation = 4;
        }
      }
    }
    //如果是正对墙角的情况 ，首先唯一的竖直墙线作为区分X坐标的分界
    else {
      if (ex < (arr[1].Px + arr[4].Px) * 0.5 * scale) {
        upLine = MyFA.CommonFunction.calLinearEquationByPoints(arr[0], arr[1]);
        downLine = MyFA.CommonFunction.calLinearEquationByPoints(
          arr[3],
          arr[4]
        );
        //yInUpLine = X坐标在直线(arr[0], arr[1])上的y坐标
        yInUpLine = (upLine.c * -1 - upLine.a * (ex / scale)) / upLine.b;
        //yInDownLine = X坐标在直线(arr[3], arr[4])上的y坐标
        yInDownLine =
          (downLine.c * -1 - downLine.a * (ex / scale)) / downLine.b;

        //如果ey / scale < yInUpLine，则点击的是房顶
        if (ey / scale < yInUpLine) {
          wallLocation = 0;
        }
        //如果ey / scale > yInDownLine，则点击的是地面
        else if (ey / scale > yInDownLine) {
          wallLocation = 2;
        }
        //否则，点击的是左墙
        else {
          wallLocation = 3;
        }
      } else {
        upLine = MyFA.CommonFunction.calLinearEquationByPoints(arr[1], arr[2]);
        downLine = MyFA.CommonFunction.calLinearEquationByPoints(
          arr[4],
          arr[5]
        );
        //yInUpLine = X坐标在直线(arr[1], arr[2])上的y坐标
        yInUpLine = (upLine.c * -1 - upLine.a * (ex / scale)) / upLine.b;
        //yInDownLine = X坐标在直线(arr[4], arr[5])上的y坐标
        yInDownLine =
          (downLine.c * -1 - downLine.a * (ex / scale)) / downLine.b;

        //如果ey / scale < yInUpLine，则点击的是房顶
        if (ey / scale < yInUpLine) {
          wallLocation = 0;
        }
        //如果ey / scale > yInDownLine，则点击的是地面
        else if (ey / scale > yInDownLine) {
          wallLocation = 2;
        }
        //否则，点击的是右墙
        else {
          wallLocation = 1;
        }
      }
    }
    return wallLocation;
  };

  //打开场景model
  p.OpenFile = function () {
    // 用文件名检索文件ID
    //设计的恢复
    var saveDesign = JSON.parse(window.currentDesignJson);
    ////恢复场景的识别结果
    //MyFA.WallLineModel.arr = saveDesign.arr;
    //MyFA.WallLineModel.walls = saveDesign.walls;
    //this.WallDenote = saveDesign.WallDenote;

    MyFA.CommonFunction.deepCopy(this, saveDesign.photoScene);
    // 何路：这些都应该是model私有的方法，暴露出来不好
    this.setPhotoSceneScale();
    this.GetDisappearedPoints();
    this.CalculateOffsetAngle();

    var _this = this;

    var img = new Image();
    //获取场景原始矩阵
    img.src = saveDesign.photoScene.original;
    img.onload = function () {
      var tempMat = cv.imread(img);
      _this.Original = tempMat;
      var img1 = new Image();
      //获取场景原始备份矩阵
      img1.src = saveDesign.photoScene.originalBackup;
      img1.onload = function () {
        var tempMat = cv.imread(img1);
        _this.originalBackup = tempMat;
        _this.GetMatsFromOriginal(_this.originalBackup);
        _this.isOpenFinished = true;
      };
    };
    ////TODO:根据designid获取设计详细信息，防止读取设计列表时效率低下，读取列表时仅获取designID和designName
    //myCustomService.GetDecorationDesignByID(designID, 100, 1)
    //      .success(function (data) {

    //      })
    //      .error(function (data) {

    //      });
  };

  //保存场景信息
  //(将场景model部分重要信息拷贝给另一个对象target,最后将target返回)
  p.SaveFile = function () {
    var target = new Object();
    target.WallLineModel = {
      arr: this.WallLineModel.arr,
      walls: this.WallLineModel.walls,
    };
    target.WallDenote = this.WallDenote;
    target.original = writeMat(this.Original);
    target.originalBackup = writeMat(this.originalBackup);

    //原始场景照片像素宽度
    target.imageWidth = this.imageWidth;
    target.imageHeight = this.imageHeight;

    target.LengthPerPix = this.LengthPerPix;
    target._p1p4 = this._p1p4;
    //右墙线物理距离
    target._p2p5 = this._p2p5;
    //左墙线与水平线的夹角
    target.pl = this.pl;
    //右墙线与水平线的夹角
    target.pr = this.pr;
    target.Out = this.Out;
    //场景在X方向的偏移角度（场景矫正时使用）
    target.OffsetAngleX = this.OffsetAngleX;
    //场景在Y方向的偏移角度（场景矫正时使用）
    target.OffsetAngleY = this.OffsetAngleY;

    target.furModels = [];
    for (var i = 0; i < this.furModels.length; i++) {
      var furModel = new MyFA.FurnitureModel();

      this.furModels[i].parent = undefined;
      this.furModels[i].image = undefined;
      furModel = MyFA.CommonFunction.deepCopy(furModel, this.furModels[i]);

      furModel.isSelected = false;
      target.furModels.push(furModel);

      this.furModels[i].parent = this;
      this.furModels[i].image = undefined;

      var img = new Image();
      //解决图片的跨域问题
      img.crossOrigin = "Anonymous";
      img.src = this.furModels[i].imgSrc;
      this.furModels[i].image = img;
    }
    return target;
  };

  //将某个矩阵转换为url
  function writeMat(__imgMat) {
    var iCanvas = document.createElement("canvas");
    var iCtx = iCanvas.getContext("2d");
    var width = __imgMat.col,
      height = __imgMat.row,
      imageData = iCtx.createImageData(width, height);
    imageData.data.set(__imgMat.data);

    iCanvas.width = width;
    iCanvas.height = height;
    iCtx.putImageData(imageData, 0, 0);
    var url = iCanvas.toDataURL("image/jpeg");
    return url;
  }

  //删除某个家具model
  p.removeFurModel = function (furnitureModel) {
    for (var i = 0; i < this.furModels.length; i++) {
      if (this.furModels[i] == furnitureModel) {
        this.furModels.splice(i, 1);
        break;
      }
    }
  };

  MyFA.PhotoSceneModel = PhotoSceneModel;
})();
