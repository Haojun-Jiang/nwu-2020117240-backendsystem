<template>
    <el-card class="box-card">
        <!-- 表单 -->
        <el-form :model="editShop" :rules="editShopRules" ref="editShopRef" label-width="100px">

            <el-form-item label="是否冻结" prop="isFreezing">
                <el-select v-model="editShop.isFreezing">
                    <el-option label="是" :value="1"></el-option>
                    <el-option label="否" :value="0"></el-option>
                </el-select>
            </el-form-item>

            <el-form-item label="是否停用" prop="isStoped">
                <el-select v-model="editShop.isStoped">
                    <el-option label="是" :value="1"></el-option>
                    <el-option label="否" :value="0"></el-option>
                </el-select>
            </el-form-item>

            <el-form-item label="免费试用期" prop="FreeTryExpried">
                <el-col :span="11">
                    <el-date-picker type="date" placeholder="选择日期" v-model="editShop.FreeTryExpried"
                    format="yyyy 年 MM 月 dd 日" value-format="yyyy-MM-dd" style="width: 200px;"></el-date-picker>
                </el-col>
            </el-form-item>

            <el-form-item label="VIP有效期" prop="VIPExpired">
                <el-col :span="11">
                    <el-date-picker type="date" placeholder="选择日期" v-model="editShop.VIPExpried"
                    format="yyyy 年 MM 月 dd 日" value-format="yyyy-MM-dd" style="width: 200px;"></el-date-picker>
                </el-col>
            </el-form-item>

            <el-form-item>
                <el-button type="primary" @click="subMit">提交</el-button>
                <el-button type="primary" @click="fallBack">返回</el-button>
            </el-form-item>
        </el-form>
    </el-card>
</template>
<script>
/* eslint-disable */
import { admUpdateShop } from '@/api/index'

export default {
    name: 'editPro',
    data() {
        return {
            editShop: {
                isFreezing: this.$store.state.cache.rowData.isFreezing,
                isStoped: this.$store.state.cache.rowData.isStoped,
                FreeTryExpried: this.$store.state.cache.rowData.FreeTryExpired,
                VIPExpried: this.$store.state.cache.rowData.VIPExpired,
                UserID: this.$store.state.cache.rowData.UserID
            },
            editShopRules: {
                isFreezing: [
                    { required: true, message: '请选择是否冻结', trigger: 'change' }
                ],
                isStoped: [
                    { required: true, message: '请选择是否停用', trigger: 'change' }
                ],
                FreeTryExpried: [
                    { message: '请选择免费试用期', trigger: 'change' }
                ],
                VIPExpried: [
                    { message: '请选择VIP有效期', trigger: 'change' }
                ]
            }
        }
    },
    methods: {
        subMit() {
            this.$refs.editShopRef.validate(async valid => {
                if (!valid) return false;
                console.log(this.editShop);
                const { data: res } = await admUpdateShop(this.editShop);
                if (res.status !== 0) return this.$message.error(res.message);
                this.$message.success(res.message);
                this.$router.push('/manage/shops')
            })
        },

        fallBack() {
            this.$router.push('/manage/shops')
        }
    },
}
</script>
<style lang="less" scoped>
.el-form {
    width: 500px;
}

input[type="file"] {
    display: none;
}

.avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
}

.avatar-uploader .el-upload:hover {
    border-color: #409EFF;
}
</style>
