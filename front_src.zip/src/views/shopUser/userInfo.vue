<template>
    <el-card class="box-card">
        <div slot="header" class="clearfix">
            <span>基本资料</span>
        </div>
        <!-- 表单 -->
        <el-form :model="userForm" :rules="userFormRules" ref="userFormRef" label-width="100px">
            <el-form-item label="用户名" prop="UserName">
                <el-input v-model="userForm.UserName" minlength="1" maxlength="10"></el-input>
            </el-form-item>
            <el-form-item label="店铺名" prop="ShopName">
                <el-input v-model="userForm.ShopName" minlength="1" maxlength="10"></el-input>
            </el-form-item>
            <el-form-item label="用户电话" prop="MobilePhone">
                <el-input v-model="userForm.MobilePhone" minlength="11" maxlength="11"></el-input>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" @click="submitFn">提交修改</el-button>
                <el-button @click="resetFn">重置</el-button>
            </el-form-item>
        </el-form>
    </el-card>
</template>

<script>
import { updateUserinfo } from '@/api'
export default {
  name: 'UserInfo',
  data () {
    return {
      userForm: {
        UserName: this.$store.state.userInfo.UserName, // 默认值用登录后获取到的用户名
        ShopName: this.$store.state.userInfo.ShopName,
        MobilePhone: this.$store.state.userInfo.MobilePhone
      },
      // 表单的验证规则对象
      userFormRules: {
        UserName: [
          { required: true, message: '请输入用户名', trigger: 'blur' },
          { pattern: /^\S{1,10}$/, message: '用户名必须是1-10位的非空字符串', trigger: 'blur' }
        ],
        ShopName: [
          { required: true, message: '请输入商户名', trigger: 'blur' },
          { pattern: /^\S{1,10}$/, message: '商户名必须是1-10位的非空字符串', trigger: 'blur' }
        ],
        MobilePhone: [
          { required: true, message: '请输入想修改的电话号码', trigger: 'blur' },
          { pattern: /^1[3-9]\d{9}$/, message: '请输入正确的电话号码', trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    submitFn () {
      this.$refs.userFormRef.validate(async valid => {
        if (valid) {
          const { data: res } = await updateUserinfo(this.userForm)
          console.log(res)
          if (res.status !== 0) return this.$message.error('修改失败')
          this.$message.success('修改成功')
          // 更新vuex中的用户信息
          this.$store.dispatch('initUserInfo')
        } else {
          return false
        }
      })
    },
    resetFn () {
      this.$refs.userFormRef.resetFields()
    }
  }
}
</script>
<style lang="less" scoped>
.el-form {
    width: 500px;
}
</style>
