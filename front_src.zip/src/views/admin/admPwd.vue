<template>
    <el-card class="box-card">
        <div slot="header" class="clearfix">
            <span>重置密码</span>
        </div>
        <!-- 表单 -->
        <el-form :model="pwdForm" :rules="pwdFormRules" ref="pwdFormRef" label-width="100px">
            <el-form-item label="原密码" prop="Password">
                <el-input v-model="pwdForm.Password" type="password"></el-input>
            </el-form-item>
            <el-form-item label="新密码" prop="newPassword">
                <el-input v-model="pwdForm.newPassword" type="password"></el-input>
            </el-form-item>
            <el-form-item label="确认新密码" prop="Rep_Password">
                <el-input v-model="pwdForm.Rep_Password" type="password"></el-input>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" @click="updatePwd">修改密码</el-button>
                <el-button>重置</el-button>
            </el-form-item>
        </el-form>
    </el-card>
</template>
<script>
/* eslint-disable */
import { updateAdminPwd } from '@/api/index'
export default {
  name: 'UserPwd',
  data () {
    // 验证新密码和确认新密码是否一致
    var samePwd = (rule, value, callback) => {
      if (value === this.pwdForm.Password) {
        callback(new Error('新密码不能与原密码相同'))
      } else {
        callback()
      }
    }
    // 验证确认新密码是否与新密码一致
      var rePwd = (rule, value, callback) => {
        if (value !== this.pwdForm.newPassword) {
          callback(new Error('确认新密码与新密码不一致'))
        }
            callback()
      }
      return {
            // 表单的数据对象
            pwdForm: {
                Password: '',
                newPassword: '',
                Rep_Password: ''
            },
            // 表单的验证规则对象
            pwdFormRules: {
                Password: [
                    { required: true, message: '请输入密码', trigger: 'blur' },
                    { pattern: /^\S{4,15}$/, message: '密码长度必须是4-15位的非空字符串', trigger: 'blur' }
                ],
                newPassword: [
                    { required: true, message: '请输入新密码', trigger: 'blur' },
                    { pattern: /^\S{4,15}$/, message: '密码长度必须是4-15位的非空字符串', trigger: 'blur' },
                    { validator: samePwd, trigger: 'blur' }
                ],
                Rep_Password: [
                    { required: true, message: '请再次确认新密码', trigger: 'blur' },
                    { pattern: /^\S{4,15}$/, message: '密码长度必须是4-15位的非空字符串', trigger: 'blur' },
                    { validator: rePwd, trigger: 'blur' }
                ]
            }
        }
    },
    methods: {
        // 修改密码
        updatePwd () {
            this.$refs.pwdFormRef.validate(async valid => {
                if (!valid) return false
                const { data: res } = await updateAdminPwd(this.pwdForm)
                if (res.status !== 0) return this.$message.error('修改密码失败')

                this.$message.success('修改密码成功')
                this.$refs.pwdFormRef.resetFields()
            })
        },
        restFn () {
            this.$refs.pwdFormRef.resetFields()
        }
    }
}
</script>
<style lang="less" scoped>
.el-form {
    width: 500px;
}
</style>
