<template>
    <el-container class="main-container">
        <!-- 头部区域 -->
        <el-header>
            <!-- 右侧的菜单 -->
            <el-menu class="el-menu-top" mode="horizontal" background-color="#23262E" text-color="#fff"
                active-text-color="#409EFF">
                <el-menu-item index="2"><i class="el-icon-switch-button" @click="logoutFn"></i>退出</el-menu-item>
            </el-menu>
        </el-header>
        <el-container>
            <!-- 侧边栏区域 -->
            <el-aside width="200px">
        <div class="user-box">
          <span>welcome admin</span>
        </div>
        <!-- 左侧导航菜单 -->
        <el-menu
          default-active="$route.path"
          class="el-menu-vertical-demo"
          background-color="#23262E"
          text-color="#fff"
          active-text-color="#409EFF"
          unique-opened
          router
        >
          <!-- 包含子菜单的“一级菜单” -->
          <el-submenu index="/admin">
            <template slot="title">
              <i class="el-icon-s-tools"></i>
              <span>个人信息</span>
            </template>
            <el-menu-item index="/admin/updatepwd"
              ><i class="el-icon-star-on"></i>修改密码</el-menu-item
            >
          </el-submenu>
          <!-- 包含子菜单的“一级菜单” -->
          <el-submenu index="/manage">
            <template slot="title">
              <i class="el-icon-s-tools"></i>
              <span>商铺</span>
            </template>
            <el-menu-item index="/manage/shops"
              ><i class="el-icon-star-on"></i>商铺列表</el-menu-item
            >
            <el-menu-item index="/manage/products"
              ><i class="el-icon-star-on"></i>商品列表</el-menu-item
            >
          </el-submenu>
        </el-menu>
      </el-aside>
            <el-container>
                <!-- 页面主体区域 -->
                <el-main>
                  <router-view></router-view>
                </el-main>
            </el-container>
        </el-container>
    </el-container>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
  computed: {
    ...mapGetters(['UserName'])
  },

  name: 'my-layout',
  methods: {
    logoutFn () {
      this.$confirm('sure?', 'tips', {
        confirmButtonText: 'YES',
        cancelButtonText: 'NO',
        type: 'warning'
      })
        .then(() => {
          // 执行推出登录的操作
          // 清空token
          this.$store.commit('updateToken', '')
          this.$router.push('/admin-login')
        })
        .catch((err) => err)
    }
  }
}
</script>
<style lang="less" scoped>
.main-container {
    height: 100%;

    .el-header,
    .el-aside {
        background-color: #23262e;
    }

    .el-header {
        padding: 0;
        display: flex;
        justify-content: space-between;
    }

    .el-main {
        overflow-y: scroll;
        height: 725px;
        background-color: #F2F2F2;
    }
}

.user-box {
  height: 70px;
  display: flex;
  justify-content: center;
  align-items: center;
  border-top: 1px solid #000;
  border-bottom: 1px solid #000;
  user-select: none;
  img {
    width: 35px;
    height: 35px;
    border-radius: 50%;
    background-color: #fff;
    margin-right: 15px;
    object-fit: cover;
  }
  span {
    color: white;
    font-size: 12px;
  }
}

.avatar {
    border-radius: 50%;
    width: 35px;
    height: 35px;
    background-color: #fff;
    margin-right: 10px;
    object-fit: cover;
}
.el-aside {
  .el-submenu,
  .el-menu-item {
    width: 200px;
    user-select: none;
  }
}
</style>
