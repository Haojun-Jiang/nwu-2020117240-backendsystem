<template>
    <el-table :data="ProductList" border style="width: 100%">
        <el-table-column fixed prop="ProductID" label="商品编号" width="100">
        </el-table-column>
        <el-table-column prop="ProductName" label="产品名称" width="200">
            <template slot-scope="scope">
                <el-input v-if="scope.row.ProductID==editID" @input="handleChange(scope.$index)" v-module="scope.row.ProductName" size="mini" style="width: 100px" aria-placeholder="scope.row.ProductName"></el-input>
                <span v-else>{{scope.row.ProductName}}</span>
            </template>
        </el-table-column>

        <el-table-column prop="ProductPic" label="预览图" width="120">
            <template slot-scope="scope">
                <el-popover placement="top-start" title trigger="hover">
                    <img :src="scope.row.ProductPic" alt="" style="aspect-ratio: attr(width) / attr(height) 100px;">
                    <img slot="reference" :src="scope.row.ProductPic" style="width: 30px; height: 30px;">
                </el-popover>
            </template>
        </el-table-column>

        <el-table-column prop="IsWithdraw" label="是否上架" width="150">
            <template slot-scope="scope">
                <el-input v-if="scope.row.ProductID==editID" v-module="scope.row.IsWithdraw" size="mini" style="width: 120px;" :placeholder="scope.row.IsWithdraw"></el-input>
                <span v-else>{{scope.row.IsWithdraw==1?'是':'否'}}</span>
            </template>
        </el-table-column>

        <el-table-column prop="Width" label="宽度" width="150">
            <template slot-scope="scope">
                <el-input v-if="scope.row.ProductID==editID" v-module="scope.row.Width" @input="updateW(scope.row)" size="mini" style="width: 120px;" :placeholder="scope.row.Width"></el-input>
                <span v-else>{{scope.row.Width}}</span>
            </template>
        </el-table-column>

        <el-table-column prop="Hight" label="高度" width="150">
            <template slot-scope="scope">
                <el-input v-if="scope.row.ProductID==editID" v-module="scope.row.Hight" size="mini" style="width: 120px;" :placeholder="scope.row.Hight"></el-input>
                <span v-else>{{scope.row.Hight}}</span>
            </template>

        </el-table-column>
        <el-table-column prop="Taobao" label="淘宝链接" width="150">
            <template slot-scope="scope">
                <el-input v-if="scope.row.ProductID==editID" v-module="scope.row.Taobao" size="mini" style="width: 120px;" :placeholder="scope.row.Taobao"></el-input>
                <span v-else>{{scope.row.Taobao}}</span>
            </template>
        </el-table-column>

        <el-table-column>
            <template slot="header" slot-scope="scope">
                <el-input v-model="Keywords" size="mini" placeholder="输入关键字搜索" @keyup.enter.native="handleSearch(scope.$index, scope.row)"/>
            </template>
            <template slot-scope="scope">
                <el-button v-if="scope.row.IsWithdraw==1" size="mini" type="success" @click="handleDeposit(scope.$index, scope.row)">上架</el-button>
                <el-button v-if="scope.row.IsWithdraw==0" size="mini" type="danger" @click="handleWithdraw(scope.$index, scope.row)">下架</el-button>
            </template>
        </el-table-column>
    </el-table>
</template>

<script>
/* eslint-disable */
import { admgetProducts, admUpdateProduct, admSearchProduct } from '@/api/index'

export default {
    data () {
        return {
            ProductList: [],
            editID: '',
            Keywords: ''
        }
      },
    methods: {

        handleWithdraw(index, row) {
                this.$confirm('sure?', 'tips', {
                confirmButtonText: 'YES',
                cancelButtonText: 'NO',
                type: 'warning'
            })
            .then(async () => {
                var data = {
                    ProductID: row.ProductID,
                    IsWithdraw: 1
                }
                const { data: res } = await admUpdateProduct(data)
                if (res.status !== 0) {
                    console.log(data)
                    return this.$message.error(res.message)
                } else {
                    this.$message.success(res.message)
                    location.reload()
                }
            })
            .catch((err) => err)
            console.log(index, row);
        },
        handleDeposit(index, row) {
                this.$confirm('sure?', 'tips', {
                confirmButtonText: 'YES',
                cancelButtonText: 'NO',
                type: 'warning'
            })
            .then(async () => {
                var data = {
                    ProductID: row.ProductID,
                    IsWithdraw: 0
                }
                const { data: res } = await admUpdateProduct(data)
                if (res.status !== 0) {
                    console.log(data)
                    return this.$message.error(res.message)
                } else {
                    this.$message.success(res.message)
                    location.reload()
                }
            })
            .catch((err) => err)
            console.log(index, row);
        },
        async handleSearch(index, row) {
            var data = {
                Keywords: this.Keywords
            }
            const { data: res } = await admSearchProduct(data)
            if (res.length === 0 ) {
                console.log(res)
                return this.$message.error(res.message)
            } else {
                this.ProductList = res
                console.log(res)
            }
        },
        async fatchProductList() {
            const { data: res } = await admgetProducts();
            if (res.length !== 0) {
                this.ProductList = res;
            } else {
                console.log(res.message);
                this.$message.error(res.message);
            }
        }
    },
    mounted() {
        this.fatchProductList()
    }
}
</script>
<style lang="less" scoped></style>
