<!-- eslint-disable -->
<template>
    <el-table :data="tableData" style="width: 100%">
        <el-table-column fixed label="ID" prop="UserID">
        </el-table-column>
        <el-table-column label="用户名" prop="UserName">
        </el-table-column>
        <el-table-column label="商铺名" prop="ShopName">
        </el-table-column>
        <el-table-column label="VIP到期时间" prop="VIPExpried" :formatter="formatDate">
        </el-table-column>
        <el-table-column label="上次登录时间" prop="LastLoginTime" :formatter="formatDateTime">
        </el-table-column>
        <el-table-column label="是否停用" prop="isStoped">
            <template slot-scope="scope">
                <span>{{ scope.row.isStoped == 1 ? '是' : '否' }}</span>
            </template>
        </el-table-column>
        <el-table-column label="是否冻结" prop="isFreeing">
            <template slot-scope="scope">
                <span>{{ scope.row.isFreeing == 1 ? '是' : '否' }}</span>
            </template>
        </el-table-column>
        <el-table-column align="right">
            <template slot="header" slot-scope="scope">
                <el-input v-model="Keywords" size="mini" placeholder="输入关键字搜索" @keyup.enter.native="handleSearch(scope.$index, scope.row)"/>
            </template>
            <template slot-scope="scope">
                <el-button size="mini" @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
                <el-button size="mini" type="danger" @click="handleDelete(scope.$index, scope.row)">删除</el-button>
            </template>
        </el-table-column>
    </el-table>
</template>

<script>
/* eslint-disable */
import { mapMutations } from 'vuex'
import { admgetShops, admSearchShop } from '@/api/index.js'
export default {
    data() {
        return {
            tableData: [],
            Keywords: ''
        }
    },
    methods: {
        ...mapMutations('cache', ['changeRowData']),
        handleEdit(index, row) {
            this.changeRowData(this.tableData[index])
            this.$router.push({
                path: '/edit/shops',
            })
            console.log(index, row);
        },
        handleDelete(index, row) {
            console.log(index, row);
        },
        async handleSearch(index, row) {
            var Key = {
                Keywords: this.Keywords
            }
            console.log(Key)
            const { data: res } = await admSearchShop(Key)
            console.log(res)
            if (res.status === 0) {
                return this.$message.error(res.message)
            }
            else {
                this.tableData = res
                this.$message.success(res.message)
            }
        },
        async fatchShoplist() {
            const { data: res } = await admgetShops()
            console.log(res)
            if (res.length !== 0) {
                this.tableData = res
            }
            else {
                console.log('获取失败')
            }
        },
        formatDateTime(row, column) {
            // 获取单元格数据
            let data = row[column.property]
            if (data == null) {
                return null
            }
            let dt = new Date(data)
            return dt.getFullYear() + '-' + (dt.getMonth() + 1) + '-' + dt.getDate() + ' ' + dt.getHours() + ':' + dt.getMinutes() + ':' + dt.getSeconds()
        },
        formatDate(row, column) {
            // 获取单元格数据
            let data = row[column.property]
            if (data == null) {
                return null
            }
            let dt = new Date(data)
            return dt.getFullYear() + '-' + (dt.getMonth() + 1) + '-' + dt.getDate()
        },

    },
    mounted() {
        this.fatchShoplist()
    }
}
</script>
