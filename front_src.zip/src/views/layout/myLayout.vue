<template>
    <el-container class="main-container">
        <!-- 头部区域 -->
        <el-header>
            <!-- 右侧的菜单 -->
            <el-menu class="el-menu-top" mode="horizontal" background-color="#23262E" text-color="#fff"
                active-text-color="#409EFF">
                <el-submenu index="1">
                    <template slot="title">
                        <span>个人中心</span>
                    </template>
                    <el-menu-item index="1-1"><i class="el-icon-s-operation"></i>基本资料</el-menu-item>
                    <el-menu-item index="1-2"><i class="el-icon-key"></i>商铺列表</el-menu-item>
                    <el-menu-item index="1-3"><i class="el-icon-key"></i>重置密码</el-menu-item>
                </el-submenu>
                <el-menu-item index="2"><i class="el-icon-switch-button" @click="logoutFn"></i>退出</el-menu-item>
            </el-menu>
        </el-header>
        <el-container>
            <!-- 侧边栏区域 -->
            <el-aside width="200px">
        <div class="user-box">
          <span>welcome {{ UserName }}</span>
        </div>
        <!-- 左侧导航菜单 -->
        <el-menu
          default-active="$route.path"
          class="el-menu-vertical-demo"
          background-color="#23262E"
          text-color="#fff"
          active-text-color="#409EFF"
          unique-opened
          router
        >
          <!-- 不包含子菜单的“一级菜单” -->
          <el-menu-item index="/home"
            ><i class="el-icon-s-tools"></i>home</el-menu-item
          >
          <!-- 包含子菜单的“一级菜单” -->
          <el-submenu index="/my">
            <template slot="title">
              <i class="el-icon-s-tools"></i>
              <span>个人信息</span>
            </template>
            <el-menu-item index="/my/edit"
              ><i class="el-icon-star-on"></i>修改信息</el-menu-item
            >
            <el-menu-item index="/my/password"
              ><i class="el-icon-star-on"></i>修改密码</el-menu-item
            >
          </el-submenu>
          <!-- 包含子菜单的“一级菜单” -->
          <el-submenu index="/product">
            <template slot="title">
              <i class="el-icon-s-tools"></i>
              <span>商铺</span>
            </template>
            <el-menu-item index="/product/list"
              ><i class="el-icon-star-on"></i>商品列表</el-menu-item
            >
            <el-menu-item index="/product/add"
              ><i class="el-icon-star-on"></i>添加商品</el-menu-item
            >
          </el-submenu>
          <!-- 不包含子菜单的“一级菜单” -->
          <el-menu-item index="/vip"
            ><i class="el-icon-star-on"></i>VIP</el-menu-item
          >
        </el-menu>
      </el-aside>
            <el-container>
                <!-- 页面主体区域 -->
                <el-main>
                  <router-view></router-view>
                </el-main>
            </el-container>
        </el-container>
    </el-container>
</template>

<script>
import { mapGetters } from 'vuex'
import { getUserinfo } from '@/api'

export default {
  computed: {
    ...mapGetters(['UserName', 'ShopName', 'isStoped', 'FreeTryExpried', 'VIPExpried '])
  },

  name: 'my-layout',
  methods: {
    logoutFn () {
      this.$confirm('sure?', 'tips', {
        confirmButtonText: 'YES',
        cancelButtonText: 'NO',
        type: 'warning'
      })
        .then(() => {
          // 执行推出登录的操作
          // 清空token
          this.$store.commit('updateToken', '')
          this.$router.push('/login')
        })
        .catch((err) => err)
    },
    async getUserinfo () {
      const { data: res } = await getUserinfo()
      console.log(res)
      this.menus = res.data
    }
  }
}
</script>
<style lang="less" scoped>
.main-container {
    height: 100%;

    .el-header,
    .el-aside {
        background-color: #23262e;
    }

    .el-header {
        padding: 0;
        display: flex;
        justify-content: space-between;
    }

    .el-main {
        overflow-y: scroll;
        height: 725px;
        background-color: #F2F2F2;
    }
}

.user-box {
  height: 70px;
  display: flex;
  justify-content: center;
  align-items: center;
  border-top: 1px solid #000;
  border-bottom: 1px solid #000;
  user-select: none;
  img {
    width: 35px;
    height: 35px;
    border-radius: 50%;
    background-color: #fff;
    margin-right: 15px;
    object-fit: cover;
  }
  span {
    color: white;
    font-size: 12px;
  }
}

.avatar {
    border-radius: 50%;
    width: 35px;
    height: 35px;
    background-color: #fff;
    margin-right: 10px;
    object-fit: cover;
}
.el-aside {
  .el-submenu,
  .el-menu-item {
    width: 200px;
    user-select: none;
  }
}
</style>
