<template>
    <div class = 'header'>
        <h3>top</h3>
    </div>
</template>

<script>

</script>

<style lang="less" scoped>
.header{
    height: 50px;
    background: pink;
}
</style>
