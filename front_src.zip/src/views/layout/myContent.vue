<template>
    <div>
        <Header></Header>
        <router-view></router-view>
    </div>
</template>

<script>
/* eslint-disable */
import Header from './myHeader.vue'
export default{
    components:{
        Header
    }
}
</script>

<style lang="less" scoped>

</style>