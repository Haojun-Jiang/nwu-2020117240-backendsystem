<template>
    <el-table :data="tableData" style="width: 100%">
        <el-table-column prop="Width" label="宽(cm)">
        </el-table-column>
        <el-table-column prop="Hight" label="长(cm)">
        </el-table-column>
        <el-table-column label="操作">
            <template slot-scope="scope">
                <el-button size="mini" @click="handleJump(scope.$index, scope.row)">加入设计</el-button>
            </template>
        </el-table-column>
    </el-table>
</template>

<script>
/* eslint-disable */
import { getProductSpecList2 } from '@/api/index.js'
export default {
    data() {
        return {
            tableData: [],
            ProductPic: this.$store.state.cache.rowData.ProductPic,
            ProductID: this.$store.state.cache.rowData.ProductID
        }
    },
    methods: {
        async getdata() {
            console.log(this.ProductID)
            var { data: res } = await getProductSpecList2({ ProductID: this.ProductID })
            console.log(res)
            this.tableData = res
        },
        async handleJump(index, row) {
            console.log(this.ProductList[index].ProductID);
            var dt = {
                ProductID: this.ProductList[index].ProductID
            }
            var { data: res } = await clientDapei(dt);
            console.log(res);
            if (res.status) {
                this.$messagge.err(res.message)
            } else {
                window.open('http://127.0.0.1:5500/dapei.html')
            }
        }
    },
    mounted() {
        this.getdata()
    }
}
</script>
