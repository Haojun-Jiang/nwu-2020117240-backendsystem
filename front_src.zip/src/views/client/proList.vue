<template>
    <el-table :data="ProductList" border style="width: 100%">

        <el-table-column prop="ProductName" label="产品名称" width="100">
        </el-table-column>

        <el-table-column prop="ShopName" label="店铺名称" width="150">
        </el-table-column>

        <el-table-column prop="ProductPic" label="预览图" width="120">
            <template slot-scope="scope">
                <el-popover placement="top-start" title trigger="hover">
                    <img :src="scope.row.ProductPic" alt="" style="aspect-ratio: attr(width) / attr(height) 100px;">
                    <img slot="reference" :src="scope.row.ProductPic" style="width: 30px; height: 30px;">
                </el-popover>
            </template>
        </el-table-column>

        <el-table-column prop="Width" label="宽度" width="150">
        </el-table-column>

        <el-table-column prop="Hight" label="高度" width="150">
        </el-table-column>

        <el-table-column prop="Taobao" label="淘宝链接" width="200">
            <template slot-scope="scope">
            <a :href="scope.row.Taobao" target="_blank">{{ scope.row.Taobao }}</a>
            </template>
        </el-table-column>

        <el-table-column prop="QRCode" label="二维码" width="150">
            <template slot-scope="scope">
                <img :src="scope.row.QRCode" alt="QR Code" style="width: 100px; height: 100px;">
            </template>
        </el-table-column>

        <el-table-column>
            <template slot="header" slot-scope="scope">
                <el-input v-model="Keywords" size="mini" placeholder="输入关键字搜索" @keyup.enter.native="handleSearch(scope.$index, scope.row)"/>
            </template>
            <template slot-scope="scope">
                <el-button size="mini" type="success" @click="handleJump(scope.$index, scope.row)">加入设计</el-button>
            </template>
        </el-table-column>
    </el-table>
</template>

<script>
/* eslint-disable */
import { mapMutations } from 'vuex'
import { clientProlist, clientSearchProduct, clientDapei } from '@/api/index'

export default {
    data () {
        return {
            ProductList: [],
            Keywords: ''
        }
      },
    methods: {
        ...mapMutations('cache',['changeRowData']),

        async handleSearch(index, row) {
            console.log(index, row);
            var dt = {
                Keywords: this.Keywords,
                test: ''
            }
            const { data: res } = await clientSearchProduct(dt);
            if (res.length !== 0 && !res.status) {
                this.ProductList = res;
            } else {
                console.log(res.message);
                this.$message.error(res.message);
            }
        },

        async fatchProductList() {
            const { data: res } = await clientProlist();
            if (res.length !== 0) {
                this.ProductList = res;
            } else {
                console.log(res.message);
                this.$message.error(res.message);
            }
        },

        async handleJump(index, row) {
            this.changeRowData(row)
            this.$router.push({
                path: '/client/spec',
            })
            // console.log(this.ProductList[index].ProductID);
            // var dt = {
            //     ProductID: this.ProductList[index].ProductID
            // }
            // var { data: res } = await clientDapei(dt);
            // console.log(res);
            // if (res.status) {
            //     this.$messagge.err(res.message)
            // } else {
            //     window.open('http://127.0.0.1:5500/dapei.html')
            // }
        }
    },
    mounted() {
        this.fatchProductList()
    }
}
</script>
<style lang="less" scoped></style>
