<template>
  <div>
    <h2>给图片加边框并转换为Base64格式</h2>
    <div>
      <label>选择边框颜色：
        <input type="color" v-model="borderColor">
      </label>
    </div>
    <canvas ref="canvas"></canvas>
    <button @click="addBorderAndConvert">添加边框并转换</button>
  </div>
</template>

<script>
/* eslint-disable */
import { addborder } from '@/api';
export default {
  data() {
    return {
      mainImage: this.$store.state.cache.rowData.ProductPic,
      borderColor: "#000000" // 默认边框颜色为黑色
    };
  },
  methods: {
    // handleFileChange(event) {
    //   const file = event.target.files[0];
    //   if (!file) return;

    //   const reader = new FileReader();
    //   reader.onload = (e) => {
    //     const img = new Image();
    //     img.onload = () => {
    //       this.mainImage = img;
    //     };
    //     img.src = e.target.result;
    //   };
    //   reader.readAsDataURL(file);
    // },
    addBorderAndConvert() {
      const canvas = this.$refs.canvas;
      const ctx = canvas.getContext('2d');

      if (!this.mainImage) return;

      const img = new Image();
      img.src = this.mainImage;
      img.onload = async () => {
        const width = img.width;
        const height = img.height;

        canvas.width = width;
        canvas.height = height;

        // 绘制主要图片
        ctx.drawImage(img, 0, 0, width, height);

        // 获取边框颜色
        const borderColor = this.borderColor;

        // 绘制四条边框
        ctx.fillStyle = borderColor;
        ctx.fillRect(0, 0, canvas.width, 5); // 上边框
        ctx.fillRect(0, 0, 5, canvas.height); // 左边框
        ctx.fillRect(canvas.width - 5, 0, 5, canvas.height); // 右边框
        ctx.fillRect(0, canvas.height - 5, canvas.width, 5); // 下边框

        // 将Canvas中的图片转换为base64格式
        const base64ImageData = canvas.toDataURL('image/png');

        // 这里可以调用API将base64格式的图片数据发送给后端
        var dt = {
          ProductPic: base64ImageData
        };
        var { data: res } = await addborder(dt);
        console.log(res);
        if (res.status === 0) {
          this.$message.success('添加边框并转换成功');
          window.open('http://127.0.0.1:5500/dapei.html')
        } else {
          this.$message.error('添加边框并转换失败');
        }
      }
    }
  }
}
</script>
