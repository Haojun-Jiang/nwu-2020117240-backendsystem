<template>
  <div>
    <h1>我的主页</h1>
    <div v-if="wheatherisStoped">
      <p>您已停用</p>
    </div>
    <div v-else-if="showBuyVipButton">
      <p>购买VIP</p>
      <el-button type="primary" @click="$router.push('/vip')">购买</el-button>
    </div>
    <div v-else-if="showFreeTrial">
      <p>免费试用期还有 {{ daysUntilFreeTrialExpires }} 天</p>
    </div>
    <div v-else>
      <p>VIP到期日期: {{ vipExpirationDate }}</p>
    </div>
  </div>
</template>

<script>
/* eslint-disable */
import { getUserinfo } from '@/api';
export default {
    data() {
        return {
            UserInfo: {}
        }
    },
    methods: {
        async getUserInfo() {
            const { data: res} = await getUserinfo();
            this.UserInfo = res.data;
        }
    },
    created() {
        this.getUserInfo();
    },
    watch: {
        UserInfo: {
            handler(newVal) {
                console.log(newVal);
            },
            deep: true
        }
    },
    setup() {
    },
    computed: {
    wheatherisStoped() {
        if(this.UserInfo.isStoped){
          this.$store.commit('updateToken', '')
          return this.UserInfo.isStoped;
        }
        else return false
    },
    showBuyVipButton() {
      const currentDate = new Date();
      return (!this.UserInfo.FreeTryExpried || new Date(this.UserInfo.FreeTryExpried) < currentDate) &&
             (!this.UserInfo.VIPExpried || new Date(this.UserInfo.VIPExpried) < currentDate);
    },
    showFreeTrial() {
      const currentDate = new Date();
      return this.UserInfo.FreeTryExpried && new Date(this.UserInfo.FreeTryExpried) > currentDate &&
             (!this.UserInfo.VIPExpried || new Date(this.UserInfo.VIPExpried) < currentDate);
    },
    daysUntilFreeTrialExpires() {
      const currentDate = new Date();
      const freetryDate = new Date(this.UserInfo.FreeTryExpried);
      const diffTime = freetryDate.getTime() - currentDate.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays;
    },
    vipExpirationDate() {
      if (!this.UserInfo.VIPExpried) return '';
      const vipDate = new Date(this.UserInfo.VIPExpried);
      const year = vipDate.getFullYear();
      const month = vipDate.getMonth() + 1;
      const day = vipDate.getDate();
      return `${year}年${month < 10 ? '0' + month : month}月${day < 10 ? '0' + day : day}日`;
    }
  },
}
</script>

<style lang="less" scoped>

</style>
