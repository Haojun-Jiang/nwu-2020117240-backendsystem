<template>
  <div class="reg-container">
    <div class="reg-box">
      <div class="title-box"></div>
      <el-form ref="form" :model="form" :rules="rulesObj">
        <el-form-item prop='ShopName'>
          <el-input placeholder="商铺名" v-model="form.ShopName"></el-input>
        </el-form-item>
        <el-form-item prop='UserName'>
          <el-input placeholder="用户名" v-model="form.UserName"></el-input>
        </el-form-item>
        <el-form-item prop='MobilePhone'>
          <el-input placeholder="电话号码" v-model="form.MobilePhone"></el-input>
        </el-form-item>
        <el-form-item prop='Password'>
          <el-input placeholder="密码" v-model="form.Password"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" class='btn-reg' @click="regUser">注册</el-button>
          <el-link type="info" @click="$router.push('/login')">去登录</el-link>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script>
import { registerAPI } from '@/api'

export default {
  name: 'my-reg',
  data () {
    return {
      form: {
        ShopName: '',
        UserName: '',
        MobilePhone: '',
        salt: '000',
        Password: ''
      },
      rulesObj: {
        ShopName: [
          { required: true, message: '请输入商铺名', trigger: 'blur' },
          {
            pattern: /^\S{0,10}$/,
            message: '商铺名为零到十个字符',
            trigger: 'blur'
          }
        ],
        UserName: [
          { required: true, message: '请输入用户名', trigger: 'blur' },
          {
            pattern: /^\S{1,15}$/,
            message: '用户名为一到十五个字符',
            trigger: 'blur'
          }
        ],
        MobilePhone: [
          {
            pattern: /^1[3-9]\d{9}$/,
            message: '请输入电话号码',
            trigger: 'blur'
          }
        ]
      }
    }
  },
  methods: {
    regUser () {
      this.$refs.form.validate(async valid => {
        if (!valid) return false
        console.log(this.form)

        const { data: res } = await registerAPI(this.form)
        console.log(res)
        if (res.status !== 0) return this.$message.error(res.message)
        this.$message.success(res.message)
        this.$router.push('/login')
      })
    }
  }
}
</script>

<style lang="less" scoped>
.reg-container {
  background: url('/src/login_bg.jpg') center;
  background-size: cover;
  height: 100%;

  .reg-box {
    width: 400px;
    height: 400px;
    background-color: #fff;
    border-radius: 3px;
    position: absolute;
    top: 50%;
    left: 50%;
    padding: 0 30px;
    transform: translate(-50%, -50%);
    box-sizing: border-box;

    .title-box {
      height: 60px;
      background: url('/src/login_title.png') center no-repeat;
    }

    .btn-reg {
      width: 100%;
    }
  }
}
</style>
