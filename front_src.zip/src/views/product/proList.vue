<template>
    <el-table :data="ProductList" border style="width: 100%">
        <el-table-column fixed prop="ProductID" label="商品编号" width="100">
        </el-table-column>
        <el-table-column prop="ProductName" label="产品名称" width="150">
            <template slot-scope="scope">
                <el-input v-if="scope.row.ProductID==editID" @input="handleChange(scope.$index)" v-module="scope.row.ProductName" size="mini" style="width: 100px" aria-placeholder="scope.row.ProductName"></el-input>
                <span v-else>{{scope.row.ProductName}}</span>
            </template>
        </el-table-column>

        <el-table-column prop="ProductPic" label="预览图" width="120">
            <template slot-scope="scope">
                <el-popover placement="top-start" title trigger="hover">
                    <img :src="scope.row.ProductPic" alt="" style="aspect-ratio: attr(width) / attr(height) 100px;">
                    <img slot="reference" :src="scope.row.ProductPic" style="width: 30px; height: 30px;">
                </el-popover>
            </template>
        </el-table-column>

        <el-table-column prop="IsWithdraw" label="是否上架" width="150">
            <template slot-scope="scope">
                <el-input v-if="scope.row.ProductID==editID" v-module="scope.row.IsWithdraw" size="mini" style="width: 120px;" :placeholder="scope.row.IsWithdraw"></el-input>
                <span v-else>{{scope.row.IsWithdraw==1?'是':'否'}}</span>
            </template>
        </el-table-column>

        <el-table-column prop="Width" label="宽度" width="150">
            <template slot-scope="scope">
                <el-input v-if="scope.row.ProductID==editID" v-module="scope.row.Width" @input="updateW(scope.row)" size="mini" style="width: 120px;" :placeholder="scope.row.Width"></el-input>
                <span v-else>{{scope.row.Width}}</span>
            </template>
        </el-table-column>

        <el-table-column prop="Hight" label="高度" width="150">
            <template slot-scope="scope">
                <el-input v-if="scope.row.ProductID==editID" v-module="scope.row.Hight" size="mini" style="width: 120px;" :placeholder="scope.row.Hight"></el-input>
                <span v-else>{{scope.row.Hight}}</span>
            </template>

        </el-table-column>
        <el-table-column prop="Taobao" label="淘宝链接" width="150">
            <template slot-scope="scope">
                <el-input v-if="scope.row.ProductID==editID" v-module="scope.row.Taobao" size="mini" style="width: 120px;" :placeholder="scope.row.Taobao"></el-input>
                <span v-else>{{scope.row.Taobao}}</span>
            </template>
        </el-table-column>

        <el-table-column prop="QRCode" label="二维码" width="150">
            <template slot-scope="scope">
                <img :src="scope.row.QRCode" alt="QR Code" style="width: 100px; height: 100px;" @click="saveQRCode(scope.$index, scope.row)">
            </template>
        </el-table-column>

        <el-table-column label="操作">
            <template slot-scope="scope">
                <el-button v-if="scope.row.ProductID!=editID" size="mini" @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
                <el-button v-if="scope.row.ProductID!=editID" size="mini" type="danger" @click="handleDelete(scope.$index, scope.row)">删除</el-button>
                <el-button v-if="scope.row.ProductID==editID" size="mini" type="success" @click="handleSave(scope.$index, scope.row)">保存</el-button>
            </template>
        </el-table-column>
    </el-table>
</template>

<script>
/* eslint-disable */
import { mapMutations } from 'vuex'
import { getProductList, deleteProduct, getUserinfo } from '@/api/index'

export default {
    data () {
        return {
            ProductList: [],
            editID: '',
            UserInfo:{}
        }
      },
    methods: {
        // handleBug(val) {
        //     this.ProductList.push({ 
        //         ProductID: '',
        //         ProductName: '',
        //         ProductPic: '',
        //         IsWithdraw: '',
        //         Width: '',
        //         Hight: '',
        //         Taobao: ''
        //     })
        //     this.ProductList.splice(this.ProductList.length - 1, 1)
        // },
        ...mapMutations('cache',['changeRowData']),

        handleChange(index) {
            var moment = this.ProductList[index]
            this.$set(this.ProductList, index, moment)
            console.log(this.ProductList[index])
        },

        handleEdit(index, row) {
            this.changeRowData(row)
            this.$router.push({
                path: '/product/edit',
            })
        },

        handleSave(index, row) {
            this.editID = ''
        },

        handleDelete(index, row) {
                this.$confirm('sure?', 'tips', {
                confirmButtonText: 'YES',
                cancelButtonText: 'NO',
                type: 'warning'
            })
            .then(async () => {
                var data = {
                    ProductID: this.ProductList[index].ProductID
                }
                const { data: res } = await deleteProduct(data)
                if (res.status !== 0) {
                    console.log(data)
                    return this.$message.error(res.message)
                } else {
                    this.$message.success(res.message)
                    location.reload()
                }
            })
            .catch((err) => err)
            console.log(index, row);
        },
        
        // updateW(row) {
        //     if (row.Width) {
        //         row.Hight = (row.Width / scale).toFixed(2);
        //     }
        // },
        // updateH(row) {
        //     if (row.Hight) {
        //         row.Width = (row.Hight * scale).toFixed(2);
        //     }
        // },

        async fatchProductList() {
            const { data: res } = await getProductList();
            if (res.length !== 0) {
                this.ProductList = res;
            } else {
                console.log(res.message);
                this.$message.error(res.message);
            }
        },

        async fatchUserinfo() {
            const { data: res } = await getUserinfo();
            if (res.length !== 0) {
                this.UserInfo = res;
            } else {
                console.log(res.message);
                this.$message.error(res.message);
            }
        },
        wheatherisVIP() {
            return !(!this.UserInfo.FreeTryExpried || new Date(this.UserInfo.FreeTryExpried) < currentDate) &&
            (!this.UserInfo.VIPExpried || new Date(this.UserInfo.VIPExpried) < currentDate)
        },
        saveQRCode(index, row) {
            if(this.wheatherisVIP()) {
                this.editID = row.ProductID
                console.log(index, row);
                var blob = this.base64ToBlob(this.ProductList[index].QRCode);
                const downloadLink = document.createElement('a'); 
                downloadLink.href = URL.createObjectURL(blob);
                downloadLink.download = this.ProductList[index].ProductName + '.png'; // 下载文件名为商品名称，并设置文件扩展名
                // 触发点击事件下载图片
                downloadLink.click();
            } else {
                this.$message.error('您不是VIP会员,无法使用该功能')
                this.$router.push({ path: '/vip' })
            }
        },
        base64ToBlob(base64Data) {
            const byteCharacters = atob(base64Data.split(',')[1]);
            const byteNumbers = new Array(byteCharacters.length);
            for (let i = 0; i < byteCharacters.length; i++) {
                byteNumbers[i] = byteCharacters.charCodeAt(i);
            }
            const byteArray = new Uint8Array(byteNumbers);
            return new Blob([byteArray], { type: 'image/jpeg' });
    }

    },
    mounted() {
        this.fatchProductList()
        this.fatchUserinfo()
    }
}
</script>
<style lang="less" scoped></style>
