<template>
    <el-card class="box-card">
      <div slot="header" class="clearfix">
        <span>新增商品</span>
      </div>
      <!-- 表单 -->
      <el-form :model="newProlist" :rules="newProRules" ref="newProRef" label-width="100px">
        <el-form-item label="商品名称" prop="ProductName">
          <el-input v-model="newProlist.ProductName"></el-input>
        </el-form-item>

        <el-form-item label="淘宝链接" prop="Taobao">
          <el-input v-model="newProlist.Taobao"></el-input>
        </el-form-item>

        <el-form-item label="上传图片" ref="newProRef" prop="ProductPic">
          <el-upload
            class="upload-demo"
            action="#"
            :show-file-list="false"
            :before-upload="beforeUpload"
            :on-change="handleChange"
            :auto-upload="false"
            :data="newProlist"
            ref="newProRef"
            >
            <img v-if="newProlist.ProductPic" :src="newProlist.ProductPic" class="avatar">
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          </el-upload>
        </el-form-item>

        <el-form-item label="宽度" prop="Width">
          <el-input v-model="newProlist.Width" @input="updateW"></el-input>
        </el-form-item>

        <el-form-item label="高度" prop="Hight">
          <el-input v-model="newProlist.Hight" @input="updateH"></el-input>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="subMit">提交</el-button>
        </el-form-item>
      </el-form>
    </el-card>
</template>
<script>
/* eslint-disable */
import { newProduct } from '@/api/index'
var scale = 1;
  export default {
    name: 'newPro',
    data () {
      return {
        newProlist: {
          ProductName: '',
          Taobao: '',
          Width: '',
          Hight: '',
          IsWithdraw: 0,
          ProductPic: ''
        },

        newProRules: {
            ProductName: [
                { required: true, message: '请输入商品名称', trigger: 'blur' }
            ],
            Taobao: [
                { required: true, message: '请输入淘宝链接', trigger: 'blur' }
            ],
            Width: [
                { min: 1, max: 1000, required: true, message: '请输入宽度(单位：厘米)', trigger: 'blur' }
            ],
            Hight: [
                { min: 1, max: 1000, required: true, message: '请输入高度(单位：厘米)', trigger: 'blur' }
            ]
        },
        
      }
    },
    methods: {
      updateW () {
        if (this.newProlist.Width ) {
          this.newProlist.Hight = (this.newProlist.Width / scale).toFixed(2);
        }
      },
      
      updateH () {
        if (this.newProlist.Hight ) {
          this.newProlist.Width = (this.newProlist.Hight * scale).toFixed(2);
        }
      },
        handleChange (file, filelist) {
            if (filelist.length === 0) this.newProlist.ProductPic = '';
            else {
              const fr = new FileReader();
              fr.readAsDataURL(filelist[0].raw);
              fr.onload = () => {
                this.newProlist.ProductPic = fr.result;
                console.log(this.newProlist.ProductPic);
                const img = new Image();
                img.src = fr.result;
                img.onload = () => {
                  scale = img.width / img.height;
                  console.log(scale);
                }
              }
            }
        },

        beforeUpload (file) {
            return true;
        },

        subMit () {
            this.$refs.newProRef.validate(async valid => {
                if (!valid) return false;
                const { data: res } = await newProduct(this.newProlist);
                if (res.status !== 0) return this.$message.error(res.message);
                this.$message.success(res.message);
                this.$router.push('/product/list')
            })
        }
    },

    watch: {
      'newProlist.Width' (val) {
        if (val) {
          this.updateH();
        }
      },
      'newProlist.Hight' (val) {
        if (val) {
          this.updateW();
        }
      }
    }
  }
  </script>
  <style lang="less" scoped>
  .el-form {
    width: 500px;
  }
  input[type="file"] {
        display: none;
    }
 
    .avatar-uploader .el-upload {
        border: 1px dashed #d9d9d9;
        border-radius: 6px;
        cursor: pointer;
        position: relative;
        overflow: hidden;
    }
 
    .avatar-uploader .el-upload:hover {
        border-color: #409EFF;
    }
  </style>
