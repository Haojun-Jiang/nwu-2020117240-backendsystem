<template>
    <div>
        <div>
            <h2>规格列表</h2>
            <el-table :data="tableData" style="width: 100%">
                <el-table-column prop="Width" label="宽(cm)">
                </el-table-column>
                <el-table-column prop="Hight" label="长(cm)">
                </el-table-column>
                <el-table-column label="操作">
                    <template slot-scope="scope">
                        <el-button size="mini" type="danger"
                            @click="handleDelete(scope.$index, scope.row)">删除</el-button>
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <div>
            <h2>-------------------------------------------------------------------</h2>
        </div>
        <div>
            <h2>添加规格</h2>
            <el-form label-width="80px" :model="newSpec" ref="addProRef" :rules="addPecRules">
                <el-form-item label="宽(cm)">
                    <el-input v-model="newSpec.Width" @input="updateW"></el-input>
                </el-form-item>
                <el-form-item label="长(cm)">
                    <el-input v-model="newSpec.Hight" @input="updateH"></el-input>
                </el-form-item>

                <el-form-item>
                    <el-button type="primary" @click="subMit">提交</el-button>
                    <el-button type="primary" @click="fallBack">返回</el-button>
                </el-form-item>
            </el-form>
        </div>
    </div>
</template>
<script>
/* eslint-disable */
import { getProductSpecList, deleteProductSpec, addProductSpec } from '@/api';

export default {
    data() {
        return {
            ProductID: this.$store.state.cache.rowData.ProductID,
            tableData: [],
            newSpec: {
                Width: '',
                Hight: '',
                ProductID: this.$store.state.cache.rowData.ProductID
            },
            scale: this.$store.state.cache.rowData.Width / this.$store.state.cache.rowData.Hight,
        
        addSpecRules: {
            Width: [
                { required: true, message: '请输入宽', trigger: 'blur' },
                { type: "number", min: 1, max: 1000, message: '数值在1到1000之间', trigger: 'blur' }
            ],
            Hight: [
                { required: true, message: '请输入长', trigger: 'blur' },
                { type: "number" ,min: 1, max: 1000, message: '数值在1到1000之间', trigger: 'blur' }
            ],
        }
        }
    },

    methods: {
        async getdata() {
            console.log(this.ProductID)
            var { data: res } = await getProductSpecList({ ProductID: this.ProductID })
            console.log(res)
            this.tableData = res
        },
        async handleDelete(index, row) {
            var { data: res } = await deleteProductSpec({ SpecifiID: row.SpecifiID })
            if (res.status === 0) {
                this.$message({
                    message: '删除成功',
                    type: 'success'
                });
                this.getdata()
            } else {
                this.$message({
                    message: '删除失败',
                    type: 'error'
                });
            }
        },
        async subMit() {
            var { data: res } = await addProductSpec(this.newSpec)
            if (res.status === 0) {
                this.$message({
                    message: '添加成功',
                    type: 'success'
                });
                this.getdata()
            } else {
                this.$message({
                    message: '添加失败',
                    type: 'error'
                });
            }
        },
        fallBack() {
            this.$router.push('/product/edit')
        },
        updateW() {
            if (this.newSpec.Width) {
                this.newSpec.Hight = (this.newSpec.Width / this.scale).toFixed(2);
            }
        },

        updateH() {
            if (this.newSpec.Hight) {
                this.newSpec.Width = (this.newSpec.Hight * this.scale).toFixed(2);
            }
        }
    },
    watch: {
        'newSpec.Width'(val) {
            if (val) {
                this.updateH();
            }
        },
        'newSpec.Hight'(val) {
            if (val) {
                this.updateW();
            }
        }
    },
    mounted() {
        this.getdata()
    }

}
</script>

<style lang="less" scoped>
.el-form {
    width: 500px;
}

input[type="file"] {
    display: none;
}

.avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
}

.avatar-uploader .el-upload:hover {
    border-color: #409EFF;
}
</style>