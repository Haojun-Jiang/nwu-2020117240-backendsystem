<template>
    <el-card class="box-card">
      <div slot="header" class="clearfix">
        <span>编辑商品</span>
      </div>
      <!-- 表单 -->
      <el-form :model="editPro" :rules="editProRules" ref="editProRef" label-width="100px">
        <el-form-item label="商品名称" prop="ProductName">
          <el-input v-model="editPro.ProductName"></el-input>
        </el-form-item>

        <el-form-item label="淘宝链接" prop="Taobao">
          <el-input v-model="editPro.Taobao"></el-input>
        </el-form-item>

        <el-form-item label="宽度" prop="Width">
          <el-input v-model="editPro.Width" @input="updateW"></el-input>
        </el-form-item>

        <el-form-item label="高度" prop="Hight">
          <el-input v-model="editPro.Hight" @input="updateH"></el-input>
        </el-form-item>

        <el-form-item label="是否上架" prop="IsWithdraw">
            <el-select v-model="editPro.IsWithdraw" placeholder="请选择">
                <el-option label="是" :value="0"></el-option>
                <el-option label="否" :value="1"></el-option>
            </el-select>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="subMit">提交</el-button>
          <el-button type="primary" @click="fallBack">返回</el-button>
          <el-button type="primary" @click="addSpec">添加规格</el-button>
        </el-form-item>
      </el-form>
    </el-card>
</template>
<script>
/* eslint-disable */
import { updateProduct } from '@/api/index'

  export default {
    name: 'editPro',
    data () {
      return {
        editPro: {
          ProductID: this.$store.state.cache.rowData.ProductID,
          ProductName: this.$store.state.cache.rowData.ProductName,
          Taobao: this.$store.state.cache.rowData.Taobao,
          Width: this.$store.state.cache.rowData.Width,
          Hight: this.$store.state.cache.rowData.Hight,
          IsWithdraw: this.$store.state.cache.rowData.IsWithdraw,
          ProductPic: this.$store.state.cache.rowData.ProductPic,
        },

        scale: this.$store.state.cache.rowData.Width / this.$store.state.cache.rowData.Hight,

        editProRules: {
            ProductName: [
                { required: true, message: '请输入商品名称', trigger: 'blur' }
            ],
            Taobao: [
                { required: true, message: '请输入淘宝链接', trigger: 'blur' }
            ],
            Width: [
                { required: true, message: '请输入宽度', trigger: 'blur' }
            ],
            Hight: [
                { required: true, message: '请输入高度', trigger: 'blur' }
            ]
        },
        
      }
    },
    methods: {
      updateW () {
        if (this.editPro.Width ) {
          this.editPro.Hight = (this.editPro.Width / this.scale).toFixed(2);
        }
      },
      
      updateH () {
        if (this.editPro.Hight ) {
          this.editPro.Width = (this.editPro.Hight * this.scale).toFixed(2);
        }
      },

        subMit () {
            this.$refs.editProRef.validate(async valid => {
                if (!valid) return false;
                const { data: res } = await updateProduct(this.editPro);
                if (res.status !== 0) return this.$message.error(res.message);
                this.$message.success(res.message);
                this.$router.push('/product/list')
            })
        },

        fallBack () {
            this.$router.push('/product/list')
        },

        addSpec () {
            this.$router.push('/spce')
        }
    },

    watch: {
      'editPro.Width' (val) {
        if (val) {
          this.updateH();
        }
      },
      'editpro.Hight' (val) {
        if (val) {
          this.updateW();
        }
      }
    }
  }
  </script>
  <style lang="less" scoped>
  .el-form {
    width: 500px;
  }
  input[type="file"] {
        display: none;
    }
 
    .avatar-uploader .el-upload {
        border: 1px dashed #d9d9d9;
        border-radius: 6px;
        cursor: pointer;
        position: relative;
        overflow: hidden;
    }
 
    .avatar-uploader .el-upload:hover {
        border-color: #409EFF;
    }
  </style>
