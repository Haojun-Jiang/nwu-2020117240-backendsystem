<template>
    <div>
      <h2>购买VIP</h2>
      <div>
        <h3>成为VIP后能获得二维码下载等权益</h3>
        <p>价格:168元每年</p>
        <el-button  type="primary" @click="buyVip()">购买</el-button>
      </div>
    </div>
</template>
<script>
import { buyvip } from '@/api'

export default {
  /* eslint-disable */
  data() {
    return {
      Payinformation:{
        PaymentAmount: 168
      }
    };
  },
    methods: {
      buyVip() {
        this.$alert('年费会员168元', '确认订单', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          showCancelButton: true,
          showClose: false,
          center: true,
          roundButton: true,
          customClass: 'alert-class'
        })
        .then(async () => {
          const {data: res} = await buyvip(this.Payinformation);
          if (res.status === 0) {
            this.$message({
              type: 'success',
              message: '购买成功'
            });
            this.$router.push('/home')
          } else {
            this.$message({
              type: 'error',
              message: '购买失败'
            });
          }
        })
        .catch((err) => err)
      }
    }
  };
  </script>
  