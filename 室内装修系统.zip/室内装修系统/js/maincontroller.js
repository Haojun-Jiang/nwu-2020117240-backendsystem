//大模块
const divStepOne = document.getElementById("divStepOne");
const divStepTwo = document.getElementById("divStepTwo");
const imageSrc = document.getElementById("imageSrc");
const imgcontent = document.getElementById("imgcontent");
//拍照
const canvas = document.getElementById("canvas");
const context = canvas.getContext("2d");
const camera = document.getElementById("camera");
const paizhao = document.getElementsByClassName("paizhao")[0];
const shut = document.getElementById("shut");
const start = document.getElementById("start");
const picture = document.getElementById("picture");
// 相册
const photo = document.getElementById("photo");
const file = document.getElementById("file");

const shutimg = document.getElementById("shutimg");
camera.onclick = () => {
  paizhao.style.display = "block";
};
shut.onclick = () => {
  paizhao.style.display = "none";
};
// 开启摄像头
start.addEventListener("click", function () {
  if (navigator.mediaDevices.getUserMedia) {
    // 标准的API
    const p = navigator.mediaDevices.getUserMedia({
      video: true,
    });
    p.then(function (mediaStream) {
      try {
        video.srcObject = mediaStream;
      } catch (error) {
        video.src = window.URL.createObjectURL(mediaStream);
      }
      video.onloadedmetadata = function (e) {
        // Do something with the video here.
        video.play();
      };
    });
    p.catch(function (err) {
      console.log(err.name);
    });
  }
});
// 拍照
picture.addEventListener("click", function () {
  context.drawImage(video, 0, 0, 640, 480);
  // 获取 canvas 上的图像数据
  const imageData = canvas.toDataURL("image/png"); // 可以指定其他图片格式，如 "image/jpeg"
  // // 创建一个下载链接
  // const link = document.createElement("a");
  // link.href = imageData;
  // link.download = "screenshot.png"; // 指定下载的文件名

  // // 模拟点击下载链接
  // link.click();
  const imgElement = document.createElement("img");
  imgElement.src = imageData;
  render(imageData);
});
function render(e) {
  // console.log(e);
  if (e != "" && e != undefined) {
    imgcontent.style.display = "block";
    divStepOne.style.display = "none";
    divStepTwo.style.display = "block";
    // imageSrc.src = e;
    paizhao.style.display = "none";
    main.selectPhoto(e);
    initPageStep1();
    // setCanvasPosition();
  } else {
    imgcontent.style.display = "none";
    divStepOne.style.display = "flex";
    divStepTwo.style.display = "none";
    imageSrc.src = e;
  }
}
photo.onclick = () => {
  file.click();
};
// 选择照片
file.addEventListener("change", function (e) {
  const { files } = this;
  const f = files[0];
  render(URL.createObjectURL(f));
});
// shutimg.onclick = () => {
//   render();
// };
////ok
function addPhotoToStage() {
  // var loadingDiv = document.createElement('div');
  // loadingDiv.innerHTML = '<ion-spinner class="spinner-energized"></ion-spinner><br/>正在识别...';
  // loadingDiv.style.cssText = 'position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);';
  // document.body.appendChild(loadingDiv);

  function hideLoading() {
    // document.body.removeChild(loadingDiv);
    initPageStep1();
    setCanvasPosition();
  }
  // 由于下面的方法引起阻塞，所以要在setTimeout中调用！
  // main.selectPhoto(hideLoading);

  // window.addEventListener("load", function () {
  //   init();
  // });
}
addPhotoToStage();
var main;
var furnitureModel;
function init() {
  setDivStepOneStyle();

  main = new MyFA.MainController();
  furnitureModel = new MyFA.FurnitureModel();
  //判断是新建还是打开已有设计
  if (
    window.openSymbol == 1 &&
    window.currentDesignIndex != -1 &&
    window.currentDesignIndex != undefined
  ) {
    MyFA.stepIndex = 3;
    showButton("divStepOne");
    hideButton("divStepTwo");
    setTimeout(function () {
      main.openDesign(function () {
        setCanvasPosition();
        initPageStep3();
      });
    }, 30);
  } else {
    //如果是新建
    MyFA.stepIndex = 0;
    //TODO:设置第一步样式
    //显示div1 隐藏div2
    initPageStep0();
    //将标尺的默认值恢复
    numberM = 2;
    numberDM = 70;
  }
}
init();
//////页面设置部分
/////帮助
function openHelp() {
  // 创建一个新窗口并加载帮助页面
  // var helpWindow = window.open("help.html", "_blank", "width=400,height=600");
  location.href = "help.html";
}

function setDivStepOneStyle() {
  //设置divStepOne的样式
  var divStepOne = document.getElementById("divStepOne");
  var divPaishe = document.getElementById("divPaishe");
  var divXiangce = document.getElementById("divXiangce");
  var divFanhui = document.getElementById("divFanhui");
  if (divStepOne != null) {
    //保留div的display属性
    var displayStyle = divStepOne.style.display;
    divStepOne.removeAttribute("style");
    divStepOne.style.display = displayStyle;
    ///对于电脑浏览器屏幕 初始进入是竖放 返回进入是横放
    if (window.orientation == 0 || window.orientation == 180) {
      if (localStorage.isweixinbro == "yes") {
        divStepOne.setAttribute("class", "altertools3");
      } else {
        divStepOne.setAttribute("class", "altertools1");
        ///竖屏：4
      }
    }

    if (window.orientation == 90 || window.orientation == -90) {
      if (localStorage.isweixinbro == "yes") {
        divStepOne.setAttribute("class", "altertools4");
      } else {
        divStepOne.setAttribute("class", "altertools2");
        ///横屏：5 7
      }
      //保证divStepOne垂直居中
      //如果屏幕宽高是在竖屏时获取的
      if (window.innerWidth < window.innerHeight) {
        var divTop = (window.innerWidth - 105) / 2;
        divStepOne.style.marginTop = divTop + "px";
      }
      //如果屏幕宽高是在横屏时获取的
      else {
        var divTop = (window.innerHeight - 105) / 2;
        divStepOne.style.marginTop = divTop + "px";
      }
    }
  }
}

function setCanvasPosition() {
  var divStepTwo = document.getElementById("divStepTwo");
  var can = document.getElementById("resultPic");
  if (divStepTwo == null || can == null) {
    return;
  }

  can.style.position = "absolute"; //绝对定位方式
  can.style.zIndex = -1; //canvas会在其他html元素的后边

  //大if开始
  if (MyFA.MainController.photoSceneView.isEditFloor || MyFA.stepIndex != 3) {
    //地板铺设模式下。如果是 横屏 ，将canvas居中显示
    //只能在移动端浏览器使用
    if (window.orientation == 90 || window.orientation == -90) {
      can.style.top = "0px";
      divStepTwo.style.top = "10px";
    }
    //电脑端浏览器
    // if (window.innerWidth > window.innerHeight) {
    //   can.style.top = "0px";
    //   divStepTwo.style.top = "10px";
    // }

    //如果屏幕宽高是在 竖屏 时获取的
    // if (window.peiqiValue.screenWidth < window.peiqiValue.screenHeight) {
    if (window.innerWidth < window.innerHeight) {
      // var left = (window.peiqiValue.screenHeight - can.width) / 2;
      var left = (window.innerHeight - can.width) / 2;
      can.style.left = left + "px";
      divStepTwo.style.left = left + 10 + "px";
    }
    //如果屏幕宽高是在横屏时获取的
    else {
      // var left = (window.peiqiValue.screenWidth - can.width) / 2;
      var left = (window.innerWidth - can.width) / 2;
      can.style.left = left + "px";
      divStepTwo.style.left = left + 10 + "px";
    }

    if (MyFA.stepIndex !== 0) {
      document.getElementById("pageContent").style.backgroundColor = "black";
    }

    //设置地板面板的位置
    // 不在home.html
    // if ($scope.isOpenFloorSetting) {
    //   $("#popverview1").css({ left: left + "px", top: "30px" });
    // }
  }

  //大if开始
  //地板铺设模式下。如果是竖屏
  if (window.orientation == 0 || window.orientation == 180) {
    can.style.left = "0px";
    divStepTwo.style.left = "10px";

    //如果屏幕宽高是在竖屏时获取的
    if (window.innerWidth < window.innerHeight) {
      var top = (window.innerHeight - can.height) / 2;

      if (top < 0) {
        top = 0;
      }

      can.style.top = top + "px";
      divStepTwo.style.top = top + 10 + "px";
    }
    //如果屏幕宽高是在横屏时获取的
    else {
      var top = (window.innerWidth - can.height) / 2;
      if (top < 0) {
        top = 0;
      }

      can.style.top = top + "px";
      divStepTwo.style.top = top + 10 + "px";
    }

    if (MyFA.stepIndex != 0) {
      document.getElementById("pageContent").style.backgroundColor = "black";
    }

    // //设置地板面板的位置
    // if ($scope.isOpenFloorSetting) {
    //   $("#popverview1").css({ left: "10px", top: top + 40 + "px" });
    // }
  } else {
    can.style.left = "0px";
    divStepTwo.style.left = "10px";

    if (window.orientation == 90 || window.orientation == -90) {
      can.style.top = "0px";
      divStepTwo.style.top = "10px";
    }
    if (window.orientation == 0 || window.orientation == 180) {
      //如果屏幕宽高是在竖屏时获取的
      if (window.innerWidth < window.innerHeight) {
        var top = (window.innerHeight - can.height) / 2;

        if (top < 0) {
          top = 0;
        }

        can.style.top = top + "px";
        divStepTwo.style.top = top + 10 + "px";
      }
      //如果屏幕宽高是在横屏时获取的
      else {
        var top = (window.innerWidth - can.height) / 2;
        if (top < 0) {
          top = 0;
        }

        can.style.top = top + "px";
        divStepTwo.style.top = top + 10 + "px";
      }
    }
    document.getElementById("pageContent").style.backgroundColor = "black";
  }
}

//stepIndex为0时，设置页面按钮样式
/////ok
function initPageStep0() {
  showButton("divStepOne");
  hideButton("divStepTwo");
}

//根据ID隐藏按钮
function hideButton(buttonId) {
  var button = document.getElementById(buttonId);
  if (button != null) button.style.display = "none";
}
//根据ID显示按钮 display = "block"
function showButton(buttonId) {
  var button = document.getElementById(buttonId);
  if (button != null) button.style.display = "block";
}
//根据ID显示按钮 display = "inline"
function showButton1(buttonId) {
  var button = document.getElementById(buttonId);
  if (button != null) button.style.display = "inline";
}
//stepIndex为1时，设置页面按钮样式
function initPageStep1() {
  // $("#pageContent").css({ "overflow-x": "scroll", "overflow-y": "scroll" });
  // document.getElementById("pageContent").style.overflowX = "scroll";
  // document.getElementById("pageContent").style.overflowY = "scroll";

  hideButton("divStepOne");
  showButton("divStepTwo");
  var divStepTwo = document.getElementById("divStepTwo");
  divStepTwo.style.width = "250px";

  //////先画线
  showButton1("rulerButton");
  showButton1("qiehuan1");
  showButton1("qiehuan2");
  showButton1("qiehuan3");
  //
  showButton1("HelpButton");

  hideButton("nextButton");

  hideButton("homePageButton");
  hideButton("furnitureButton");
  hideButton("FloorButton");
  hideButton("SaveButton");
  hideButton("SaveToPhone");
  hideButton("FloorSettingButton");
  hideButton("CancleButton");
  hideButton("DoneButton");
}

//stepIndex为2时，设置页面按钮样式
function initPageStep2() {
  var divStepTwo = document.getElementById("divStepTwo");
  divStepTwo.style.width = "60px";

  hideButton("rulerButton");
  hideButton("qiehuan1");
  hideButton("qiehuan2");
  hideButton("qiehuan3");

  showButton1("nextButton");
  hideButton("HelpButton");
}

//stepIndex为3时，设置页面按钮样式
function initPageStep3() {
  // $("#pageContent").css({ "overflow-x": "scroll", "overflow-y": "scroll" });
  document.getElementById("pageContent").style.overflowX = "scroll";
  document.getElementById("pageContent").style.overflowY = "scroll";

  hideButton("divStepOne");

  showButton("divStepTwo");

  hideButton("nextButton");
  hideButton("rulerButton");
  hideButton("qiehuan1");
  hideButton("qiehuan2");
  hideButton("qiehuan3");

  showButton1("furnitureButton");
  showButton1("FloorButton");
  showButton1("SaveButton");
  //微信版，隐藏“返回首页”和“保存图片到手机”按钮
  if (localStorage.isweixinbro != "yes") {
    showButton1("homePageButton");
    showButton1("SaveToPhone");
  } else {
    hideButton("homePageButton");
    hideButton("SaveToPhone");
  }

  hideButton("FloorSettingButton");
  hideButton("CancleButton");
  hideButton("DoneButton");
  showButton1("HelpButton");

  var divStepTwo = document.getElementById("divStepTwo");
  if (localStorage.isweixinbro == "yes") {
    divStepTwo.style.width = "180px";
  } else {
    divStepTwo.style.width = "320px";
  }
}

// 获取 divStepTwo 元素
// // var divStepTwo = document.getElementById('divStepTwo');
var maxW = document.body.clientWidth - divStepTwo.offsetWidth;
var maxH = document.body.clientHeight - divStepTwo.offsetHeight;
var oL, oT;
var isMoving = false; // 用于标记是否正在移动

// 手指触摸开始或鼠标按下，记录 div 的初始位置
divStepTwo.addEventListener("touchstart", function (e) {
  var ev = e || window.event;
  var touch = ev.targetTouches[0];
  oL = touch.clientX - divStepTwo.offsetLeft;
  oT = touch.clientY - divStepTwo.offsetTop;
  isMoving = true; // 开始移动
});

divStepTwo.addEventListener("mousedown", function (e) {
  var ev = e || window.event;
  oL = ev.clientX - divStepTwo.offsetLeft;
  oT = ev.clientY - divStepTwo.offsetTop;
  isMoving = true; // 开始移动
});

// 触摸中或鼠标移动，改变 div 的位置
function moveDiv(e) {
  if (!isMoving) return; // 如果没有开始移动，则不执行后续操作
  var ev = e || window.event;
  ev.preventDefault(); // 阻止默认滚动行为
  var clientX = ev.type.startsWith("touch")
    ? ev.targetTouches[0].clientX
    : ev.clientX;
  var clientY = ev.type.startsWith("touch")
    ? ev.targetTouches[0].clientY
    : ev.clientY;

  var oLeft = clientX - oL;
  var oTop = clientY - oT;

  if (oLeft < 0) {
    oLeft = 0;
  } else if (oLeft >= maxW) {
    oLeft = maxW;
  }

  if (oTop < 0) {
    oTop = 0;
  } else if (oTop >= maxH) {
    oTop = maxH;
  }

  divStepTwo.style.left = oLeft + "px";
  divStepTwo.style.top = oTop + "px";
}

// 触摸移动事件
divStepTwo.addEventListener("touchmove", moveDiv);
// 鼠标移动事件
document.addEventListener("mousemove", moveDiv);

// 手指触摸结束或鼠标释放，停止移动操作
function stopMoving() {
  isMoving = false; // 停止移动
}

// 触摸结束事件
divStepTwo.addEventListener("touchend", stopMoving);
// 鼠标释放事件
document.addEventListener("mouseup", stopMoving);
/*浮动工具条拖动事件*/
//点击事件
// var ox, oy;
// // var resultPic_width, resultPic_height;
// // var canvasLeft, canvasTop;
// function onTouch(event) {
//   //页面overflow属性设置为hidden,不允许滚动
//   document.getElementById("pageContent").style.overflowX = "hidden";
//   document.getElementById("pageContent").style.overflowY = "hidden";
//   var el = null;
//   if (event.target.id == "divStepTwo") {
//     //工具条本身被点击拖动
//     el = event.target;
//   } else if (event.target.parentNode.id == "divStepTwo") {
//     //工具条上的按钮被点击拖动
//     el = event.target.parentNode;
//   } else {
//     //不是预期的控件，不做响应
//     return;
//   }

//   ox = el.offsetLeft;
//   oy = el.offsetTop;
// }
// //点击松开事件
// function onRelease(event) {
//   //页面overflow属性设置为scroll,允许滚动
//   document.getElementById("pageContent").style.overflowX = "scroll";
//   document.getElementById("pageContent").style.overflowY = "scroll";
// }

// //拖拽事件
// function onDrag(event) {
//   //阻止事件冒泡，防止底层的控件跟着移动 直接调用的事件
//   event.stopPropagation();

//   var el = null;
//   if (event.target.id == "divStepTwo") {
//     //工具条本身被点击拖动
//     el = event.target;
//   } else if (event.target.parentNode.id == "divStepTwo") {
//     //工具条上的按钮被点击拖动
//     el = event.target.parentNode;
//   } else {
//     //不是预期的控件，不做响应
//     return;
//   }
//   var dx = event.gesture.deltaX;
//   var dy = event.gesture.deltaY;

//   el.style.left = ox + dx + "px";
//   el.style.top = oy + dy + "px";
// }
// // ////添加六种事件类型
// var divStepTwo = document.getElementById("divStepTwo");
// divStepTwo.addEventListener("touchstart", onTouch);
// divStepTwo.addEventListener("touchmove", onDrag);
// divStepTwo.addEventListener("touchend", onRelease);

// divStepTwo.addEventListener("mousedown", onTouch);
// divStepTwo.addEventListener("mousemove", onDrag);
// divStepTwo.addEventListener("mouseup", onRelease);

// /////DIV2里的部分按钮的对应的事件
//////帮助提示信息
// function showTooltip(message) {
//   var tooltip = document.createElement("div");
//   tooltip.setAttribute("class", "tooltip");
//   tooltip.innerHTML = message;
//   console.log(1230);
//   document.body.appendChild(tooltip);
// }

// function hideTooltip() {
//   var tooltips = document.getElementsByClassName("tooltip");
//   console.log(0123);
//   for (var i = 0; i < tooltips.length; i++) {
//     tooltips[i].parentNode.removeChild(tooltips[i]);
//   }
// }

// //第一个的下一步
function nextStep() {
  ////////需要

  /////////调整墙线以后出标尺功能
  main.ruler();
  initPageStep2();
}
// //切换视角1 正对矩形墙面
function qiehuan1() {
  main.qiehuan1();
}
//切换视角2 正对竖墙角
function qiehuan2() {
  main.qiehuan2();
}
//切换视角3 正对竖墙角
function qiehuan3() {
  main.qiehuan3();
}
//标完墙高以后选择家具
function thirdstep() {
  main.next();
  initPageStep3();
}
//返回上一页
function goBack() {
  try {
    hideButton("divStepTwo");
    window.history.back();
    var resul = document.getElementById("resultPic");
    resul.style.display = "none";
  } catch (e) {
    alert(e);
  }
}
function openModal() {
  var furnitureModel = new MyFA.FurnitureModel();
  furnitureModel.installedType = 2;
  furnitureModel.isInstanced = true;
  var modal = document.getElementById("modal");
  var selectBtn = document.getElementById("select-btn");
  var cancelBtn = document.getElementById("cancel-btn");
  var modalImages = document.querySelectorAll(".modal-images img");
  modal.style.display = "block";
  //保证每次只添加一个家具
  var isAddingFurniture = false;
  modalImages.forEach(function (img) {
    img.addEventListener("click", function () {
      var src = this.getAttribute("data-src");
      var width = this.getAttribute("width");
      var height = this.getAttribute("height");
      furnitureModel.imgSrc = src;
      furnitureModel.ProductHeight = height;
      furnitureModel.ProductWidth = width;
    });
  });
  furnitureModel.Pics = [];
  furnitureModel.pixWidth = 0;
  furnitureModel.pixHeight = 0;
  furnitureModel.picAngle = 0;

  furnitureModel.bblX = 0;
  furnitureModel.bblY = 0;
  furnitureModel.bblZ = 0;
  furnitureModel.bbrX = 600;
  furnitureModel.bbrY = 0;
  furnitureModel.bbrZ = 0;
  furnitureModel.btlX = 0;
  furnitureModel.btlY = 300;
  furnitureModel.btlZ = 0;
  furnitureModel.btrX = 600;
  furnitureModel.btrY = 300;
  furnitureModel.btrZ = 0;
  furnitureModel.fblX = 0;
  furnitureModel.fblY = 0;
  furnitureModel.fblZ = 100;
  furnitureModel.fbrX = 600;
  furnitureModel.fbrY = 0;
  furnitureModel.fbrZ = 100;
  furnitureModel.ftlX = 0;
  furnitureModel.ftlY = 300;
  furnitureModel.ftlZ = 100;
  furnitureModel.ftrX = 600;
  furnitureModel.ftrY = 300;
  furnitureModel.ftrZ = 100;
  ////根据
  furnitureModel.CustomProductHeight = furnitureModel.ProductHeight;
  furnitureModel.CustomProductWidth = furnitureModel.ProductWidth;
  furnitureModel.isNeedShadow = true;
  furnitureModel.CustomProductThickness = 0;
  furnitureModel.ProductThickness = 0;

  // 点击选择按钮，将选中的图片添加到界面中
  selectBtn.onclick = () => {
    // 添加家具操作
    main.addFurniture(furnitureModel);
    // 关闭模态框
    modal.style.display = "none";
  };

  // 点击取消按钮，关闭模态框
  cancelBtn.addEventListener("click", function () {
    modal.style.display = "none";
  });
}
function floorSettingEvent() {
  var divStepTwo = document.getElementById("divStepTwo");
  divStepTwo.style.width = "250px";

  showButton1("FloorButton");
  showButton1("FloorSettingButton");
  showButton1("CancleButton");
  showButton1("DoneButton");

  hideButton("homePageButton");
  hideButton("furnitureButton");
  hideButton("SaveButton");
  hideButton("SaveToPhone");

  // 添加一个按钮事件监听器，当用户点击此按钮时，弹出图片选择面板
  showImageSelector();
}

function showImageSelector() {
  // 创建一个包含图片的对话框
  var dialog = document.createElement("div");
  dialog.style.border = "1px solid #ccc";
  dialog.style.backgroundColor = "#fff";
  dialog.style.padding = "10px";
  dialog.style.position = "absolute";
  dialog.style.top = "50px";
  dialog.style.left = "50px";
  dialog.style.width = "400px";
  dialog.style.height = "400px";
  dialog.style.overflow = "scroll";

  // 创建标题元素
  var title1 = document.createElement("h2");
  title1.innerText = "壁纸类";
  // 将标题添加到div元素中
  dialog.appendChild(title1);
  // 在对话框中添加多个图片元素
  var images1 = [
    { src: "img/images2/tupian/壁纸1.png", width: 300, height: 300 },
    { src: "img/images2/tupian/壁纸2.png", width: 300, height: 300 },
    { src: "img/images2/tupian/壁纸3.png", width: 300, height: 300 },
    { src: "img/images2/tupian/壁纸4.png", width: 300, height: 300 },
    { src: "img/images2/tupian/壁纸5.png", width: 300, height: 300 },
    { src: "img/images2/tupian/壁纸6.png", width: 300, height: 300 },
    { src: "img/images2/tupian/壁纸7.png", width: 300, height: 300 },
    // ...
  ];
  for (var i = 0; i < images1.length; i++) {
    (function () {
      var image = images1[i];
      var imgElement = document.createElement("img");
      imgElement.src = image.src;
      imgElement.width = image.width;
      imgElement.height = image.height;

      imgElement.addEventListener("click", function () {
        window.selectedImageSrc = image.src;
        window.selectedImageWidth = image.width;
        window.selectedImageHeight = image.height;
        dialog.parentNode.removeChild(dialog);
      });

      // 在每次循环结束时，将 imgElement 添加到文档中
      dialog.appendChild(imgElement);
    })();
  }
  // 创建标题元素
  var title2 = document.createElement("h2");
  title2.innerText = "地板类";

  // 将标题添加到div元素中
  dialog.appendChild(title2);
  var images2 = [
    {
      src: "img/images2/tupian/佛山市/比萨斜塔-.jpg",
      width: 300,
      height: 300,
    },
    { src: "img/images2/tupian/佛山市/栎木-.jpg", width: 300, height: 300 },
    { src: "img/images2/tupian/佛山市/迷恋巴黎-.jpg", width: 300, height: 300 },
    { src: "img/images2/tupian/佛山市/槭木-.jpg", width: 300, height: 300 },
    { src: "img/images2/tupian/佛山市/桃花芯-.jpg", width: 300, height: 300 },
    { src: "img/images2/tupian/佛山市/条形乌木-.jpg", width: 300, height: 300 },
    { src: "img/images2/tupian/佛山市/维多利亚-.jpg", width: 300, height: 300 },
    { src: "img/images2/tupian/佛山市/香脂木豆-.jpg", width: 300, height: 300 },
    { src: "img/images2/tupian/佛山市/伊莎贝拉-.jpg", width: 300, height: 300 },
    { src: "img/images2/tupian/佛山市/柚木-.jpg", width: 300, height: 300 },
    { src: "img/images2/tupian/佛山市/紫檀色-.jpg", width: 300, height: 300 },

    {
      src: "img/images2/tupian/广东/波西米亚/LF30845.jpg",
      width: 300,
      height: 300,
    },
    {
      src: "img/images2/tupian/广东/地砖/BG603011(600x600).jpg",
      width: 300,
      height: 300,
    },
    {
      src: "img/images2/tupian/广东/地砖/BG603012(600x600).jpg",
      width: 300,
      height: 300,
    },
    {
      src: "img/images2/tupian/广东/地砖/BG603014(600x600).jpg",
      width: 300,
      height: 300,
    },
    {
      src: "img/images2/tupian/广东/地砖/YF600593(600×600mm).jpg",
      width: 300,
      height: 300,
    },
    {
      src: "img/images2/tupian/广东/地砖/YF600595(600×600mm).jpg",
      width: 300,
      height: 300,
    },
    {
      src: "img/images2/tupian/广东/地砖/YF601921(800x800，600x600).jpg",
      width: 300,
      height: 300,
    },
    {
      src: "img/images2/tupian/广东/地砖/YF633401（600x300）.jpg",
      width: 300,
      height: 300,
    },
    {
      src: "img/images2/tupian/广东/地砖/YF633403（600x300）.jpg",
      width: 300,
      height: 300,
    },
    {
      src: "img/images2/tupian/广东/地砖/YG802012.jpg",
      width: 300,
      height: 300,
    },
  ];

  for (var i = 0; i < images2.length; i++) {
    (function () {
      var image = images2[i];
      var imgElement = document.createElement("img");
      imgElement.src = image.src;
      imgElement.width = image.width;
      imgElement.height = image.height;

      imgElement.addEventListener("click", function () {
        window.selectedImageSrc = image.src;
        window.selectedImageWidth = image.width;
        window.selectedImageHeight = image.height;
        dialog.parentNode.removeChild(dialog);
      });

      // 在每次循环结束时，将 imgElement 添加到文档中
      dialog.appendChild(imgElement);
    })();
  }
  // 将对话框添加到HTML文档中
  document.body.appendChild(dialog);
}

function FloorBeginEvent() {
  //体验家具  下面调用代码  将家具 显示在照片 上.
  var furnitureModel = new MyFA.FurnitureModel();
  furnitureModel.installedType = 3;
  furnitureModel.isInstanced = true;
  furnitureModel.imgSrc = window.selectedImageSrc;
  furnitureModel.ProductWidth = window.selectedImageWidth * 3;
  furnitureModel.ProductHeight = window.selectedImageHeight * 2;

  window.floorImgSrc = furnitureModel.imgSrc;
  window.floorWidth = furnitureModel.ProductWidth;
  window.floorHeight = furnitureModel.ProductHeight;
  window.installedType = furnitureModel.installedType;
  main.floorBeginEvent();
}

function saveDesign() {
  //获取canvas元素
  var canvas = document.getElementById("resultPic");
  //转换为data URI
  var dataURL = canvas.toDataURL();
  //转换为Blob
  var blob = dataURItoBlob(dataURL);
  //创建Blob URL
  var url = URL.createObjectURL(blob);

  //触发提示框，让用户选择是否下载
  if (confirm("确定要下载设计吗？")) {
    //创建下载链接并触发点击下载
    var a = document.createElement("a");
    a.download = "design.png";
    a.href = url;
    // a.click();
    //触发下载框
    a.dispatchEvent(new MouseEvent("click"));
  }
}

//将data URI转换为Blob
function dataURItoBlob(dataURI) {
  var byteString = atob(dataURI.split(",")[1]);
  var mimeString = dataURI.split(",")[0].split(":")[1].split(";")[0];
  var ab = new ArrayBuffer(byteString.length);
  var ia = new Uint8Array(ab);
  for (var i = 0; i < byteString.length; i++) {
    ia[i] = byteString.charCodeAt(i);
  }
  return new Blob([ab], { type: mimeString });
}

// ///////////
// //保存设计原图到手机
function savePhotoToPhone() {
  ///navigator.userAgent 是一个包含有关浏览器的用户代理字符串的只读属性
  ///正则表达式，表示不区分大小写匹配 iPhone、iPad、iPod 或 Android 字符串
  var isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
  if (!isMobile) {
    alert("该功能仅在移动设备上可用。");
    return;
  }

  var canvas = document.getElementById("resultPic");
  var imgDataUrl = canvas.toDataURL();

  // 将图片转换为 Blob 对象
  ///通过 imgDataUrl.split(",")[1] 取得图片数据中的base64部分。
  ///使用 atob() 函数将base64解码为二进制数据。
  ///将二进制数据存储到 array 数组中。
  ///通过 new Blob([new Uint8Array(array)], { type: "phonedesign/png" }) 将 array 转换为 Blob 对象，设置对象类型为 phonedesign/png。
  ///该方法适用于在浏览器端生成图片数据，然后将其转换为Blob对象进行上传或保存等操作
  var blobBin = atob(imgDataUrl.split(",")[1]);
  var array = [];
  for (var i = 0; i < blobBin.length; i++) {
    array.push(blobBin.charCodeAt(i));
  }
  var file = new Blob([new Uint8Array(array)], { type: "phonedesign/png" });

  // 创建下载链接并触发点击下载
  if (confirm("确定要下载设计到手机吗？")) {
    var a = document.createElement("a");
    document.body.appendChild(a);
    a.style = "display: none";
    var url = window.URL.createObjectURL(file);
    a.href = url;
    a.download = "image.png";
    a.click();
    window.URL.revokeObjectURL(url);
  }
}
// //地板铺设点击“清除”按钮事件
function removeFloorResult() {
  main.removeFloorResult();
}

// ///////
//地板铺设点击“完成”按钮事件
function floorEndEvent() {
  // main.floorEndEvent();

  var divStepTwo = document.getElementById("divStepTwo");

  // divStepTwo.style.width = "320px";

  showButton1("FloorButton");

  showButton1("furnitureButton");
  showButton1("SaveButton");
  if (localStorage.isweixinbro == "no") {
    showButton1("homePageButton");
    showButton1("SaveToPhone");
  }

  hideButton("FloorSettingButton");
  hideButton("CancleButton");
  hideButton("DoneButton");

  // setCanvasPosition();
}
