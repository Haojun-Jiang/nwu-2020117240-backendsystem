const canvas = document.getElementById("canvas");
const context = canvas.getContext("2d");
const camera = document.getElementById("camera");
const divStepOne = document.getElementById("divStepOne");
const divStepTwo = document.getElementById("divStepTwo");
const paizhao = document.getElementsByClassName("paizhao")[0];
const shut = document.getElementById("shut");
camera.onclick = () => {
  paizhao.style.display = "block";
};
shut.onclick = () => {
  paizhao.style.display = "none";
};
// 开启摄像头
start.addEventListener("click", function () {
  if (navigator.mediaDevices.getUserMedia) {
    // 标准的API
    const p = navigator.mediaDevices.getUserMedia({
      video: true,
    });
    p.then(function (mediaStream) {
      try {
        video.srcObject = mediaStream;
      } catch (error) {
        video.src = window.URL.createObjectURL(mediaStream);
      }
      video.onloadedmetadata = function (e) {
        // Do something with the video here.
        video.play();
      };
    });
    p.catch(function (err) {
      console.log(err.name);
    });
  }
  // else if (navigator.mediaDevices.webkitGetUserMedia) {
  //   // WebKit
  //   const p = navigator.mediaDevices.webkitGetUserMedia({
  //     video: true,
  //   });
  //   p.then(function (mediaStream) {
  //     const video = document.querySelector("video");
  //     video.src = window.URL.createObjectURL(mediaStream);
  //     video.onloadedmetadata = function (e) {
  //       // Do something with the video here.
  //       video.play();
  //     };
  //   });
  //   p.catch(function (err) {
  //     console.log(err.name);
  //   });
  // }
});
// 拍照
picture.addEventListener("click", function () {
  context.drawImage(video, 0, 0, 640, 480);
  // 获取 canvas 上的图像数据
  const imageData = canvas.toDataURL("image/png"); // 可以指定其他图片格式，如 "image/jpeg"
  // // 创建一个下载链接
  // const link = document.createElement("a");
  // link.href = imageData;
  // link.download = "screenshot.png"; // 指定下载的文件名

  // // 模拟点击下载链接
  // link.click();
  const imgElement = document.createElement("img");
  imgElement.src = imageData;
  render(imageData);
});
const imageSrc = document.getElementById("imageSrc");
const imgcontent = document.getElementById("imgcontent");
function render(e) {
  if (e != "" && e != undefined) {
    imgcontent.style.display = "block";
    divStepOne.style.display = "none";
    divStepTwo.style.display = "block";
    imageSrc.src = e;
    paizhao.style.display = "none";
  } else {
    imgcontent.style.display = "none";
    divStepOne.style.display = "flex";
    divStepTwo.style.display = "none";
    imageSrc.src = e;
  }
}
// 相册
const photo = document.getElementById("photo");
// const file = document.getElementById('file')
photo.onclick = () => {
  file.click();
};
// 选择照片
file.addEventListener("change", function (e) {
  const { files } = this;
  const f = files[0];
  render(URL.createObjectURL(f));
});

const shutimg = document.getElementById("shutimg");
shutimg.onclick = () => {
  render();
};
