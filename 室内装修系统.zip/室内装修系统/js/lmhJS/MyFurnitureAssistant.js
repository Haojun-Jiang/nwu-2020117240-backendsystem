﻿this.MyFurnitureAssistant = this.MyFurnitureAssistant || {};
// 定义别名(快捷名)：
if (typeof this.MyFA === "undefined") {
  this.MyFA = this.MyFurnitureAssistant;
}
//主控制器类
(function () {
  "use strict";
  var seeds = new Array(); //铺设功能时要使用的种子数组
  var touchPointArray = new Array(); //铺设功能用以保存手指滑动痕迹的数组

  function MainController() {
    //初始化时处于向导第一步，stepIndex为0
    MyFA.stepIndex = 0;
    // 类字段初始化

    //初始化一个stage
    MainController.resultPic = new MyFA.CustomStage("resultPic");
    MainController.resultPic.name = "resultPic";
    createjs.Touch.enable(MainController.resultPic, true, true);
    //初始化场景view
    MainController.photoSceneView = new MyFA.PhotoSceneView(
      MainController.resultPic
    ); //全局的场景view
    MainController.photoSceneView.ClearCanvas();

    MainController.photoSceneModel = new Object(); //全局的场景model

    //window.addEventListener("orientationchange", this.orientationChangeEvent, false);
  }

  // 实例方法声明
  var p = MainController.prototype;

  // p.resultPic = new MyFA.CustomStage("resultPic");

  //转屏事件
  p.orientationChangeEvent = function () {
    try {
      if (
        window.orientation == 90 ||
        window.orientation == -90 ||
        window.orientation == 180 ||
        window.orientation == 0
      ) {
        //如果MyFA.stepIndex == 1|| MyFA.stepIndex == 2 || MyFA.stepIndex == 3（即已经渲染过线条）
        if (MyFA.stepIndex == 1 || MyFA.stepIndex == 2 || MyFA.stepIndex == 3) {
          //重新设置转屏后的场景缩放比例
          //如果是地板铺设下，按照手机屏幕宽度缩放，防止拖动画布和铺设地板操作冲突
          if (MainController.photoSceneView.isEditFloor) {
            MainController.photoSceneModel.setPhotoSceneScaleWhenFloor();
          }
          //非地板铺设模式下，按照手机屏幕高度缩放
          else {
            MainController.photoSceneModel.setPhotoSceneScale();
          }

          //重新设置canvas尺寸
          MainController.resultPic.canvas.width = Math.floor(
            MainController.photoSceneModel.Original.col *
              MainController.photoSceneModel.scale
          );
          MainController.resultPic.canvas.height = Math.floor(
            MainController.photoSceneModel.Original.row *
              MainController.photoSceneModel.scale
          );

          //如果处于向导第一步或第二步，重新绘制墙线
          if (MyFA.stepIndex == 1 || MyFA.stepIndex == 2) {
            //先移除已有墙线
            MainController.photoSceneView.RemoveWallLineContainer(true);
            MainController.photoSceneModel.getImageDataForMagnifier();
            //重新渲染墙体识别线
            MainController.photoSceneView.DrawWallLine(
              MainController.photoSceneModel.WallLineModel,
              MainController.photoSceneModel.scale,
              true
            );
          }
          //如果处于向导第二步，处理标尺的转屏问题
          if (MyFA.stepIndex == 2) {
            p.ruler();
          }
          //如果处于向导第三步，处理家具的转屏问题
          if (MyFA.stepIndex == 3) {
            p.updateFurnitures();
          }
        }
      }
    } catch (e) {
      alert(e);
    }
  };

  //转屏时调节各个家具的位置和比例
  p.updateFurnitures = function () {
    try {
      //遍历舞台上所有元素
      for (var i = 0; i < MainController.resultPic.numChildren; i++) {
        var fc = MainController.resultPic.getChildAt(i);
        var furnitureModel = fc.furnitureModel;
        var furnitureView = fc.furnitureView;
        //找到放置家具的container
        if (fc.name == "furniture") {
          //改变家具的放置位置
          furnitureView.UpdateFurPosition(
            fc,
            furnitureModel.leftUpPointX * MainController.photoSceneModel.scale,
            furnitureModel.leftUpPointY * MainController.photoSceneModel.scale
          );

          //如果是壁画类商品，则需要重新进行伸拉，而不是简单地改变bitmap的比例
          if (
            fc.furnitureModel.installedType == 2 ||
            fc.furnitureModel.installedType == 6 ||
            fc.furnitureModel.installedType == 7
          ) {
            //重新进行伸拉
            furnitureView.isStretchFinished = false;
            furnitureView.PutStretchResult(fc);
          } else {
            var furnitureBitmap = fc.getChildAt(0);
            //改变家具的放置比例
            furnitureView.UpdateFurScale(
              furnitureBitmap,
              furnitureModel.scaleX * MainController.photoSceneModel.scale,
              furnitureModel.scaleY * MainController.photoSceneModel.scale
            );
          }
        }
      }
      MainController.resultPic.update();
    } catch (e) {
      alert(e);
    }
  };

  // 加载照片到场景中
  p.selectPhoto = function (fnHideLoading) {
    window.currentDesignIndex = -1;
    var imageSrc = document.getElementById("imageSrc");
    //imageSrc.src = "img/0037.jpg";
    //imageSrc.src = "img/IMG_2648.JPG";
    // console.log(imageSrc);
    imageSrc.src = fnHideLoading;
    if (imageSrc.src != "") {
      var img = new Image();
      img.hideLoading = fnHideLoading;
      img.onload = handleImageLoad;
      img.src = imageSrc.src;
      //隐藏原照片
      // imageSrc.style.display = "none";
      imageSrc.src = "";
      // img.onerror = function () {
      //   console.log("图片加载失败");
      // };
    } else {
      //隐藏加载动画
      fnHideLoading();
      window.ionicPopup.alert({
        template: "未选中任何照片！ ",
      });
    }
  };

  //图片的加载事件
  function handleImageLoad(event) {
    try {
      var image = event.target;
      //实例化一个场景Model
      MainController.photoSceneModel = new MyFA.PhotoSceneModel(image);
      //识别照片
      var walls = MainController.photoSceneModel.RecognizeWall();
      //添加事件订阅
      MainController.resultPic.addSubscriber(
        MainController.photoSceneView.updateCanvas,
        MainController.photoSceneView,
        MainController.photoSceneModel
      );
      MainController.photoSceneModel.WallLineModel = new MyFA.WallLineModel(
        walls,
        image.width / 2,
        image.height / 2
      );

      //照片的缩放比例
      var scale = MainController.photoSceneModel.scale;

      //添加照片到舞台中
      MainController.resultPic.update();
      MainController.photoSceneModel.getImageDataForMagnifier();

      //将stepIndex属性设置为1
      MyFA.stepIndex = 1;

      //画线
      MainController.photoSceneView.DrawWallLine(
        MainController.photoSceneModel.WallLineModel,
        MainController.photoSceneModel.scale,
        true
      );

      //画布绑定放大镜功能（触摸瞬间或移动时均支持）

      MainController.photoSceneView.MagnifierView = new MyFA.Magnifier(
        MainController.resultPic,
        MainController.photoSceneModel
      );

      //墙体识别完毕的回调，关闭忙碌动画
      image.hideLoading();
    } catch (e) {
      // alert(e);
    }
  }

  //切换视角 正对矩形墙面
  p.qiehuan1 = function () {
    var wallLineModel = MainController.photoSceneModel.WallLineModel;
    var arr = wallLineModel.SetWallType(
      0,
      MainController.photoSceneModel.image.width / 2,
      MainController.photoSceneModel.image.height / 2
    );
    MainController.photoSceneView.DrawWallLine(
      MainController.photoSceneModel.WallLineModel,
      MainController.photoSceneModel.scale,
      true
    );
  };

  //切换视角 正对竖墙角
  p.qiehuan2 = function () {
    var wallLineModel = MainController.photoSceneModel.WallLineModel;
    var arr = wallLineModel.SetWallType(
      1,
      MainController.photoSceneModel.image.width / 2,
      MainController.photoSceneModel.image.height / 2
    );
    MainController.photoSceneView.DrawWallLine(
      MainController.photoSceneModel.WallLineModel,
      MainController.photoSceneModel.scale,
      true
    );
  };

  //切换视角 正对竖墙角
  p.qiehuan3 = function () {
    var wallLineModel = MainController.photoSceneModel.WallLineModel;
    var arr = wallLineModel.SetWallType(
      2,
      MainController.photoSceneModel.image.width / 2,
      MainController.photoSceneModel.image.height / 2
    );
    MainController.photoSceneView.DrawWallLine(
      MainController.photoSceneModel.WallLineModel,
      MainController.photoSceneModel.scale,
      true
    );
  };

  //调整墙线以后出标尺功能
  p.ruler = function () {
    //移除放大镜功能
    MainController.photoSceneView.MagnifierView.RemoveMagnifier();

    //移除墙线的pressmove事件，使用户不能再移动线条
    var lineContainer = MainController.resultPic.getChildByName("line");
    if (typeof lineContainer != "undefined" && lineContainer != null) {
      MainController.photoSceneView.WallLineView.clearPressmove(lineContainer);
    }

    MainController.photoSceneView.RemoveWallRulerContainer(false);
    MainController.photoSceneView.DrawWallRuler(
      MainController.photoSceneModel.WallLineModel.walls,
      MainController.photoSceneModel.image.width,
      MainController.photoSceneModel.scale
    );
    MyFA.stepIndex = 2;
  };

  //标完墙高以后选择家具
  p.next = function () {
    //矫正所标的点 调整至照片边沿
    var arr = MainController.photoSceneModel.WallLineModel.arr;
    var pLeft1 = { Px: 0, Py: 0 };
    var pLeft2 = { Px: 0, Py: MainController.photoSceneModel.imageHeight / 2 };

    var pRight1 = { Px: MainController.photoSceneModel.imageWidth / 2, Py: 0 };
    var pRight2 = {
      Px: MainController.photoSceneModel.imageWidth / 2,
      Py: MainController.photoSceneModel.imageHeight / 2,
    };

    var pBottom1 = {
      Px: 0,
      Py: MainController.photoSceneModel.imageHeight / 2,
    };
    var pBottom2 = {
      Px: MainController.photoSceneModel.imageWidth / 2,
      Py: MainController.photoSceneModel.imageHeight / 2,
    };

    if (arr.length == 8) {
      var a4x = MyFA.CommonFunction.segmentsIntr(
        arr[4],
        arr[5],
        pBottom1,
        pBottom2
      );
      if (a4x.Px < 0) {
        arr[4] = MyFA.CommonFunction.segmentsIntr(
          arr[4],
          arr[5],
          pLeft1,
          pLeft2
        );
      } else {
        arr[4] = MyFA.CommonFunction.segmentsIntr(
          arr[4],
          arr[5],
          pBottom1,
          pBottom2
        );
      }

      var a7x = MyFA.CommonFunction.segmentsIntr(
        arr[6],
        arr[7],
        pBottom1,
        pBottom2
      );
      if (a7x.Px > MainController.photoSceneModel.imageWidth / 2) {
        arr[7] = MyFA.CommonFunction.segmentsIntr(
          arr[6],
          arr[7],
          pRight1,
          pRight2
        );
      } else {
        arr[7] = MyFA.CommonFunction.segmentsIntr(
          arr[6],
          arr[7],
          pBottom1,
          pBottom2
        );
      }
    } else {
      var a3x = MyFA.CommonFunction.segmentsIntr(
        arr[3],
        arr[4],
        pBottom1,
        pBottom2
      );
      if (a3x.Px < 0) {
        arr[3] = MyFA.CommonFunction.segmentsIntr(
          arr[3],
          arr[4],
          pLeft1,
          pLeft2
        );
      } else {
        arr[3] = MyFA.CommonFunction.segmentsIntr(
          arr[3],
          arr[4],
          pBottom1,
          pBottom2
        );
      }

      var a5x = MyFA.CommonFunction.segmentsIntr(
        arr[4],
        arr[5],
        pBottom1,
        pBottom2
      );
      if (a5x.Px > MainController.photoSceneModel.imageWidth / 2) {
        arr[5] = MyFA.CommonFunction.segmentsIntr(
          arr[4],
          arr[5],
          pRight1,
          pRight2
        );
      } else {
        arr[5] = MyFA.CommonFunction.segmentsIntr(
          arr[4],
          arr[5],
          pBottom1,
          pBottom2
        );
      }
    }

    //记录标注的墙线高度
    MainController.photoSceneModel.WallDenote = numberM * 1000 + numberDM * 10;

    //计算场景灭点
    MainController.photoSceneModel.GetDisappearedPoints();

    //var shape3 = new createjs.Shape();
    //shape3.graphics.beginFill("blue");
    //shape3.graphics.drawCircle(MainController.photoSceneModel.DisappearedPoint.Px * MainController.photoSceneModel.scale,
    //    MainController.photoSceneModel.DisappearedPoint.Py * MainController.photoSceneModel.scale, 5);
    //shape3.graphics.endStroke();
    //MainController.resultPic.addChild(shape3);
    //MainController.resultPic.update();

    //计算照片场景距离（不能注释掉，否则无法计算pl和pr）
    MainController.photoSceneModel.CalculateDistanceAndAngle();

    //（场景矫正，计算偏移角度）
    MainController.photoSceneModel.CalculateOffsetAngle();

    //清除舞台上的线和标尺
    MainController.photoSceneView.RemoveWallLineContainer(false);
    MainController.photoSceneView.RemoveWallRulerContainer(false);
    MainController.resultPic.update();

    //canvas添加Click监听事件
    //点击空白处不选中任何家具
    MainController.resultPic.canvas.addEventListener(
      "click",
      p.stageClick,
      false
    );

    //canvas上添加touch监听事件
    MainController.resultPic.canvas.addEventListener(
      "touchstart",
      p.TouchStartEvent,
      false
    );
    //MainController.resultPic.canvas.addEventListener("touchmove", p.TouchMoveEvent, false);
    MainController.resultPic.canvas.addEventListener(
      "touchend",
      p.TouchEndEvent,
      false
    );

    //如果有从商城直接添加的家具，则将这些家具先加入到设计中
    if (window.selectFurnitureFromMall != undefined) {
      p.addFurniture(window.selectFurnitureFromMall);
    }

    MyFA.stepIndex = 3;
  };

  //添加家具加入到设计中
  //furniture:家具id或家具model
  p.addFurniture = function (furniture) {
    MainController.photoSceneView.isEditFloor = false;
    //MainController.photoSceneView.isEditFurniture = true;

    var furnitureModel;
    //如果传来的参数是已经实例化好的对象
    if (typeof furniture == "object") {
      furnitureModel = furniture;
    }
    //如果传来的参数是家具Id
    else {
      furnitureModel = new MyFA.FurnitureModel(furniture);
    }
    var timeOut = setTimeout(function () {
      timeOutHandler(furnitureModel);
    }, 100);
  };
  function timeOutHandler(furnitureModel) {
    //如果家具Model已被实例过，则销毁定时器
    if (furnitureModel.isInstanced) {
      window.selectFurnitureFromMall = undefined;
      //场景model中的furModels添加一个家具model
      furnitureModel.parent = MainController.photoSceneModel;

      ////将家具添加到家具集合里边
      MainController.photoSceneModel.furModels.push(furnitureModel);

      switch (furnitureModel.installedType) {
        case 0: //地面型家具
          var fPanel = new MyFA.FurnitureViewFloor(
            furnitureModel,
            MainController.resultPic
          );
          fPanel.addSubscriber(
            MainController.photoSceneView.selectFurniture,
            MainController.photoSceneView,
            null,
            "selectFurniture"
          );
          fPanel.addSubscriber(
            MainController.photoSceneView.drawAlertLineForFloorFurniture,
            MainController.photoSceneView,
            MainController.photoSceneModel,
            "drawAlertLine"
          );
          break;
        case 1:
        case 5: //家装饰品、灯具
          var fPanel = new MyFA.FurnitureViewOrnament(
            furnitureModel,
            MainController.resultPic
          );
          fPanel.addSubscriber(
            MainController.photoSceneView.selectFurniture,
            MainController.photoSceneView,
            null,
            "selectFurniture"
          );
          break;
        case 2:
        case 6:
        case 7: //艺术画、门、窗帘
          ////艺术化进入到这里 实例化家具wall对象
          var fPanel = new MyFA.FurnitureViewWall(
            furnitureModel,
            MainController.resultPic
          );
          fPanel.addSubscriber(
            MainController.photoSceneView.selectFurniture,
            MainController.photoSceneView,
            null,
            "selectFurniture"
          );
          fPanel.addSubscriber(
            MainController.photoSceneView.drawAlertLineForWallFurniture,
            MainController.photoSceneView,
            MainController.photoSceneModel,
            "drawAlertLine"
          );
          break;
      }
    }
    //如果家具还未被实例完，则继续等待
    else {
      var timeOut = setTimeout(function () {
        timeOutHandler(furnitureModel);
      }, 100);
    }
  }

  // TouchStart事件(双指旋转TouchStart)
  p.TouchStartEvent = function (e) {
    p.resultPic;
    var touches = e.targetTouches;
    //记录手指的个数，存在全局变量touches中
    window.fingerCount = touches.length;
    window.touches = touches;

    //如果是双指，且当前有家具被选中
    if (
      window.fingerCount == 2 &&
      typeof MainController.photoSceneView.SelectFurnitureContainer !=
        "undefined" &&
      MainController.photoSceneView.SelectFurnitureContainer != null
    ) {
      for (var i = 0, c = window.touches.length; i < c; i++) {
        //记录第一个指头按下时的位置。双指移动时使用
        if (i == 0) {
          window.firstFingerbeginX = window.touches[i].pageX;
          window.firstFingerbeginY = window.touches[i].pageY;
        }
        //记录每个手指开始时的坐标（解决ios版本起始坐标一致的问题）
        window.touches[i].beginX = window.touches[i].pageX;
        window.touches[i].beginY = window.touches[i].pageY;
      }
      //(地面型家具)如果是双指，且当前有家具被选中，则暂时移除被选中家具的pressmove事件，防止双指旋转时按在家具上产生事件冲突
      var furnitureView =
        MainController.photoSceneView.SelectFurnitureContainer.furnitureView;
      var furnitureModel =
        MainController.photoSceneView.SelectFurnitureContainer.furnitureModel;
      if (furnitureModel.installedType == 0) {
        MainController.photoSceneView.SelectFurnitureContainer.removeEventListener(
          "pressmove",
          furnitureView.furnitureMove,
          false
        );
      }
    }
  };

  // TouchEndEvent事件(双指旋转TouchEndEvent)
  p.TouchEndEvent = function (e) {
    var touches = e.changedTouches;
    for (var i = 0, l = touches.length; i < l; i++) {
      var touch = touches[i];
      var id = touch.identifier;
      //记录每一个手指松开时的坐标，更新至全局变量window.touches 中，下来计算旋转角度时使用
      for (var i1 = 0, c = window.touches.length; i1 < c; i1++) {
        if (id == window.touches[i1].identifier) {
          //记录每个手指松开时的坐标
          window.touches[i1].endX = touch.pageX;
          window.touches[i1].endY = touch.pageY;
        }
      }
    }
    //每抬起一个手指时， window.fingerCount -1；
    window.fingerCount = window.fingerCount - 1;

    //如果是双指
    if (window.touches.length == 2) {
      //如果是最后一个手指抬起，且当前有家具被选中，则对该家具进行双指旋转
      if (
        window.fingerCount == 0 &&
        typeof MainController.photoSceneView.SelectFurnitureContainer !=
          "undefined" &&
        MainController.photoSceneView.SelectFurnitureContainer != null
      ) {
        //判断家具的安装类型
        switch (
          MainController.photoSceneView.SelectFurnitureContainer.furnitureModel
            .installedType
        ) {
          //如果是地面类型的，则进行旋转
          case 0:
            var beginX1 = window.touches[0].beginX;
            var beginY1 = window.touches[0].beginY;
            var beginX2 = window.touches[1].beginX;
            var beginY2 = window.touches[1].beginY;

            var endX1 = window.touches[0].endX;
            var endY1 = window.touches[0].endY;
            var endX2 = window.touches[1].endX;
            var endY2 = window.touches[1].endY;

            //旋转前的向量
            var a = new cvv.Vector(beginX1, beginY1);
            var a1 = new cvv.Vector(beginX2, beginY2);
            var vectorBegin = new cvv.Vector(a, a1);

            //旋转后的向量
            var b = new cvv.Vector(endX1, endY1);
            var b1 = new cvv.Vector(endX2, endY2);
            var vectorEnd = new cvv.Vector(b, b1);

            //计算双指旋转的角度
            var rotation = MyFA.CommonFunction.calAngleOfTwoVectors(
              vectorBegin.X,
              vectorBegin.Y,
              vectorEnd.X,
              vectorEnd.Y
            );

            if (rotation > 0) {
              rotation = 10;
            } else {
              rotation = -10;
            }

            var furniture =
              MainController.photoSceneView.SelectFurnitureContainer
                .furnitureModel;
            var furnitureView =
              MainController.photoSceneView.SelectFurnitureContainer
                .furnitureView;
            //计算双指旋转后家具应该呈现的角度
            var angle = furniture.picAngle + rotation;
            //alert(angle);

            //在所有角度图片中，找出与计算出来的角度最接近的一张图片显示,并记录选出的角度图片的index
            var anglePicIndex = furniture.selectSuitablePictureByAngle(angle);

            //如果遍历找出的角度！=家具目前的放置角度，则进行家具图片的替换(使用遍历找出的角度图片)
            if (anglePicIndex != furniture.picIndex) {
              //进行旋转
              furnitureView.RotateFurnitureByAngle(
                MainController.photoSceneView.SelectFurnitureContainer,
                angle
              );

              //双指都移开时，重新给家具添加pressmove事件
              MainController.photoSceneView.SelectFurnitureContainer.addEventListener(
                "pressmove",
                furnitureView.furnitureMove,
                false
              );
              //如果家具开启了自动吸附功能
              if (furniture.isAutoAttatch) {
                var confirmPopup = window.ionicPopup.confirm({
                  title: "",
                  template: "是否要关闭家具自动吸附功能?",
                  cancelText: "取消",
                  okText: "确定",
                });
                confirmPopup.then(function (res) {
                  if (res) {
                    furniture.isAutoAttatch = false;
                  }
                });
              }
            }
            //双指都移开时，重新给家具添加pressmove事件
            else {
              MainController.photoSceneView.SelectFurnitureContainer.addEventListener(
                "pressmove",
                furnitureView.furnitureMove,
                false
              );
            }
            break;
          //如果是安装饰品类型的，在恢复家具的move事件
          default:
            break;
        }
      }
    }
  };

  //删除所选中的家具
  p.delSelectedFurniture = function () {
    //判断是否选中了某个家具
    if (
      typeof MainController.photoSceneView.SelectFurnitureContainer !=
        "undefined" &&
      MainController.photoSceneView.SelectFurnitureContainer != null &&
      window.confirmPopup == undefined
    ) {
      //防止多次点击删除按钮而出现多个删除框
      var confirmPopup = window.ionicPopup.confirm({
        title: "",
        template: "确定要删除该家具吗?",
        cancelText: "取消",
        okText: "确定",
      });
      window.confirmPopup = confirmPopup;
      confirmPopup.then(function (res1) {
        if (res1) {
          var furnitureModel =
            MainController.photoSceneView.SelectFurnitureContainer
              .furnitureModel;
          var furnitureView =
            MainController.photoSceneView.SelectFurnitureContainer
              .furnitureView;
          MainController.photoSceneModel.removeFurModel(furnitureModel);
          furnitureView.RemoveFurFromStage(
            MainController.photoSceneView.SelectFurnitureContainer,
            MainController.resultPic
          );
          MainController.photoSceneView.selectFurniture(null, -1);
          window.popover.hide();
        }
        window.confirmPopup = undefined;
      });
    } else {
      //alert("您未选中任何家具！");
    }
  };

  //调节家具亮度
  p.ChangeFurBrightness = function (brightness) {
    //brightness：亮度系数 范围-255—255
    var furnitureModel =
      MainController.photoSceneView.SelectFurnitureContainer.furnitureModel;
    furnitureModel.furnitureBrightness = brightness;
    var furnitureView =
      MainController.photoSceneView.SelectFurnitureContainer.furnitureView;
    furnitureView.ChangeFurBrightness(
      MainController.photoSceneView.SelectFurnitureContainer,
      brightness
    );
    MainController.resultPic.update();
  };

  //（手指按下时）判断在那一面墙上
  //（铺设地板时的touchstart事件）
  p.judgeWallLocation = function (e) {
    //var txt = document.getElementById("txtResult");
    //txt.textContent = ""
    //txt.textContent += (this);

    //获取滚动条的高度
    // var scrollTop = $("#pageContent").scrollTop();
    var scrollTop = document.getElementById("pageContent").scrollTop;
    //获取滚动条的宽度
    // var scrollLeft = $("#pageContent").scrollLeft();
    var scrollLeft = document.getElementById("pageContent").scrollLeft;
    var canvas = document.getElementById("resultPic");
    var ex = e.targetTouches[0].pageX - canvas.offsetLeft + scrollLeft;
    var ey = e.targetTouches[0].pageY - canvas.offsetTop + scrollTop;

    //将手指经过处左右10个像素的点都加入到seeds中
    for (var y = 0; y < 10; y++) {
      for (var x = 0; x < 10; x++) {
        if (MyFA.CommonFunction.isIn(x, y, 0, 0, 10))
          seeds.push(
            new cvv.mypix(
              Math.floor(ex / MainController.photoSceneModel.scale + x),
              Math.floor(ey / MainController.photoSceneModel.scale + y)
            )
          );
        if (MyFA.CommonFunction.isIn(x, y * -1, 0, 0, 10))
          seeds.push(
            new cvv.mypix(
              Math.floor(ex / MainController.photoSceneModel.scale + x),
              Math.floor(ey / MainController.photoSceneModel.scale - y)
            )
          );
        if (MyFA.CommonFunction.isIn(x * -1, y, 0, 0, 10))
          seeds.push(
            new cvv.mypix(
              Math.floor(ex / MainController.photoSceneModel.scale - x),
              Math.floor(ey / MainController.photoSceneModel.scale + y)
            )
          );
        if (MyFA.CommonFunction.isIn(x * -1, y * -1, 0, 0, 10))
          seeds.push(
            new cvv.mypix(
              Math.floor(ex / MainController.photoSceneModel.scale - x),
              Math.floor(ey / MainController.photoSceneModel.scale - y)
            )
          );
      }
    }

    touchPointArray.push(new cvv.mypix(ex, ey));

    var ctx = MainController.resultPic.canvas.getContext("2d");
    ctx.fillStyle = "red";
    ctx.strokeStyle = "red";
    ctx.beginPath();
    ctx.arc(ex, ey, 3, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    window.wallLocation = MainController.photoSceneModel.getWallLocationByPoint(
      ex,
      ey
    );
  };

  // 判断在哪一面墙上（鼠标按下时）
  // （铺设地板时的mousedown事件）
  p.judgeWallLocationmouse = function (e) {
    // 获取滚动条的高度
    var scrollTop = document.getElementById("pageContent").scrollTop;
    // 获取滚动条的宽度
    var scrollLeft = document.getElementById("pageContent").scrollLeft;
    var canvas = document.getElementById("resultPic");
    var ex = e.pageX - canvas.offsetLeft + scrollLeft;
    var ey = e.pageY - canvas.offsetTop + scrollTop;

    // 将鼠标按下处左右10个像素的点都加入到seeds中
    for (var y = 0; y < 10; y++) {
      for (var x = 0; x < 10; x++) {
        if (MyFA.CommonFunction.isIn(x, y, 0, 0, 10))
          seeds.push(
            new cvv.mypix(
              Math.floor(ex / MainController.photoSceneModel.scale + x),
              Math.floor(ey / MainController.photoSceneModel.scale + y)
            )
          );
        if (MyFA.CommonFunction.isIn(x, y * -1, 0, 0, 10))
          seeds.push(
            new cvv.mypix(
              Math.floor(ex / MainController.photoSceneModel.scale + x),
              Math.floor(ey / MainController.photoSceneModel.scale - y)
            )
          );
        if (MyFA.CommonFunction.isIn(x * -1, y, 0, 0, 10))
          seeds.push(
            new cvv.mypix(
              Math.floor(ex / MainController.photoSceneModel.scale - x),
              Math.floor(ey / MainController.photoSceneModel.scale + y)
            )
          );
        if (MyFA.CommonFunction.isIn(x * -1, y * -1, 0, 0, 10))
          seeds.push(
            new cvv.mypix(
              Math.floor(ex / MainController.photoSceneModel.scale - x),
              Math.floor(ey / MainController.photoSceneModel.scale - y)
            )
          );
      }
    }

    touchPointArray.push(new cvv.mypix(ex, ey));

    var ctx = MainController.resultPic.canvas.getContext("2d");
    ctx.fillStyle = "red";
    ctx.strokeStyle = "red";
    ctx.beginPath();
    ctx.arc(ex, ey, 3, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    window.wallLocation = MainController.photoSceneModel.getWallLocationByPoint(
      ex,
      ey
    );
  };
  //stage上的click事件
  p.stageClick = function (e) {
    //如果是单指touch，则视为单击,则点击空白处不选中任何家具

    var stage = MainController.resultPic;
    //如果点击的是除过家具以外的地方(FurnitureView.isTriggerPressupHandle不为true,即没有触发家具的pressup事件)
    if (MyFA.FurnitureView.isTriggerPressupHandle != true) {
      //alert(111)
      cancleSelectFur();
      MainController.photoSceneView.selectFurniture(null, -1);
      stage.update();
    } else {
      //alert(222)
      MyFA.FurnitureView.isTriggerPressupHandle = false;
    }
  };

  //（铺设地板时的touchend事件）
  p.canvasPressup = function () {
    touchPointArray.length = 0;
    var wallFloorSymbolArr = MainController.photoSceneModel.wallFloorSymbolArr;
    //如果是第一次伸拉，则需要加载忙碌动画
    if (
      !wallFloorSymbolArr[wallLocation].isStretched ||
      wallFloorSymbolArr[wallLocation].floorUrl != window.floorImgSrc
    ) {
      MainController.photoSceneView.isNeedLoading = true;
      // window.ionicLoading.show({
      //   template:
      //     '<ion-spinner class="spinner-energized"></ion-spinner><br/>正在铺设...',
      // });
      setTimeout(beginFill, 300);
    } else {
      beginFill();
    }
  };
  ///适合鼠标
  p.canvasPressupmouse = function () {
    touchPointArray.length = 0;
    var wallFloorSymbolArr = MainController.photoSceneModel.wallFloorSymbolArr;
    beginFill();
  };

  //开始填充地板
  function beginFill() {
    try {
      //松开时，开始填充
      //// contour：原始轮廓图矩阵
      // original：原始照片矩阵
      // gray：原始照片的灰度图矩阵
      //seedsArray:手指触摸时所经过的点的集合
      //wallLocation:墙面位置标识
      // repetition：平铺方向：1、按纹理图片宽高与房间宽高一致方式重复贴图；2、按纹理图片高宽与房间宽高对应方式重复贴图
      MainController.photoSceneModel.prepaireFill(
        MainController.photoSceneModel.Contour, //轮廓图
        MainController.photoSceneModel.Original, //原始图
        MainController.photoSceneModel.Gray, //灰度图
        seeds,
        window.wallLocation,
        MainController.photoSceneView.floorMode, //地板的铺设模式
        MainController.photoSceneView.isSaveShadow //是否保存光影（true）
      );
      //更新场景view
      putFloorResultToCanvas();
    } catch (e) {
      alert(e);
    }
  }

  //铺设地板展现在canvas上
  function putFloorResultToCanvas() {
    //如果铺设结果已成功写入场景照片矩阵中，则更新场景view（此处加判断是因为image的load事件是异步的）
    if (MainController.photoSceneModel.isFilled) {
      MainController.resultPic.update();
      seeds.length = 0;
      if (MainController.photoSceneView.isNeedLoading) {
        // window.ionicLoading.hide();
        MainController.photoSceneView.isNeedLoading = false;
      }
    }
    //如果铺设结果还未成功写入场景照片矩阵中，则继续等待
    else {
      var timeOut = setTimeout(putFloorResultToCanvas, 100);
    }
  }

  //canvas的move事件（铺设地板功能时用到）
  //（铺设地板时的touchmove事件）
  p.canvasPressmove = function (e) {
    // e.preventDefault();
    //获取滚动条的高度
    // var scrollTop = $("#pageContent").scrollTop();
    var scrollTop = document.getElementById("pageContent").scrollTop;
    //获取滚动条的宽度
    // var scrollLeft = $("#pageContent").scrollLeft();
    var scrollLeft = document.getElementById("pageContent").scrollLeft;
    var canvas = document.getElementById("resultPic");
    var ex = e.targetTouches[0].pageX - canvas.offsetLeft + scrollLeft;
    var ey = e.targetTouches[0].pageY - canvas.offsetTop + scrollTop;

    //连接手指移动的上一个点
    var ctx = MainController.resultPic.canvas.getContext("2d");
    ctx.fillStyle = "red";
    ctx.strokeStyle = "red";
    ctx.lineWidth = 6; //设置线宽
    ctx.beginPath();
    ctx.moveTo(
      touchPointArray[touchPointArray.length - 1].X,
      touchPointArray[touchPointArray.length - 1].Y
    );
    ctx.lineTo(ex, ey);
    //ctx.closePath();//可以把这句注释掉再运行比较下不同
    ctx.stroke(); //画线框

    //判断地板的铺设模式
    switch (MainController.photoSceneView.floorMode) {
      //如果选择的是填充模式
      case "0":
        //将手指经过处左右10个像素的点都加入到seeds中
        for (var y = 0; y < 10; y++) {
          for (var x = 0; x < 10; x++) {
            seeds.push(
              new cvv.mypix(
                Math.floor(ex / MainController.photoSceneModel.scale + x),
                Math.floor(ey / MainController.photoSceneModel.scale + y)
              )
            );
            seeds.push(
              new cvv.mypix(
                Math.floor(ex / MainController.photoSceneModel.scale + x),
                Math.floor(ey / MainController.photoSceneModel.scale - y)
              )
            );
            seeds.push(
              new cvv.mypix(
                Math.floor(ex / MainController.photoSceneModel.scale - x),
                Math.floor(ey / MainController.photoSceneModel.scale + y)
              )
            );
            seeds.push(
              new cvv.mypix(
                Math.floor(ex / MainController.photoSceneModel.scale - x),
                Math.floor(ey / MainController.photoSceneModel.scale - y)
              )
            );
          }
        }
        break;
      //如果选择的是画刷模式
      case "1":
        var x1 = Math.floor(
            touchPointArray[touchPointArray.length - 1].X /
              MainController.photoSceneModel.scale
          ),
          y1 = Math.floor(
            touchPointArray[touchPointArray.length - 1].Y /
              MainController.photoSceneModel.scale
          ),
          x2 = Math.floor(ex / MainController.photoSceneModel.scale),
          y2 = Math.floor(ey / MainController.photoSceneModel.scale);
        //将两点之间的整数点加入到seeds中
        MyFA.CommonFunction.getAllPointsOfLine(x1, y1, x2, y2, seeds);
        break;
    }

    //添加手指的滑动痕迹
    touchPointArray.push(new cvv.mypix(ex, ey));
  };
  //canvas的move 鼠标事件（铺设地板功能时用到）
  p.canvasPressmovemouse = function (e) {
    //获取滚动条的高度
    var scrollTop = document.getElementById("pageContent").scrollTop;
    //获取滚动条的宽度
    var scrollLeft = document.getElementById("pageContent").scrollLeft;
    var canvas = document.getElementById("resultPic");
    var ex = e.pageX - canvas.offsetLeft + scrollLeft;
    var ey = e.pageY - canvas.offsetTop + scrollTop;

    //连接鼠标移动的上一个点
    var ctx = MainController.resultPic.canvas.getContext("2d");
    ctx.fillStyle = "red";
    ctx.strokeStyle = "red";
    ctx.lineWidth = 6; //设置线宽
    ctx.beginPath();
    ctx.moveTo(
      touchPointArray[touchPointArray.length - 1].X,
      touchPointArray[touchPointArray.length - 1].Y
    );
    ctx.lineTo(ex, ey);
    //ctx.closePath();//可以把这句注释掉再运行比较下不同
    ctx.stroke(); //画线框

    //判断地板的铺设模式
    switch (MainController.photoSceneView.floorMode) {
      //如果选择的是填充模式
      case "0":
        //将鼠标经过处左右10个像素的点都加入到seeds中
        for (var y = 0; y < 10; y++) {
          for (var x = 0; x < 10; x++) {
            seeds.push(
              new cvv.mypix(
                Math.floor(ex / MainController.photoSceneModel.scale + x),
                Math.floor(ey / MainController.photoSceneModel.scale + y)
              )
            );
            seeds.push(
              new cvv.mypix(
                Math.floor(ex / MainController.photoSceneModel.scale + x),
                Math.floor(ey / MainController.photoSceneModel.scale - y)
              )
            );
            seeds.push(
              new cvv.mypix(
                Math.floor(ex / MainController.photoSceneModel.scale - x),
                Math.floor(ey / MainController.photoSceneModel.scale + y)
              )
            );
            seeds.push(
              new cvv.mypix(
                Math.floor(ex / MainController.photoSceneModel.scale - x),
                Math.floor(ey / MainController.photoSceneModel.scale - y)
              )
            );
          }
        }
        break;
      //如果选择的是画刷模式
      case "1":
        var x1 = Math.floor(
            touchPointArray[touchPointArray.length - 1].X /
              MainController.photoSceneModel.scale
          ),
          y1 = Math.floor(
            touchPointArray[touchPointArray.length - 1].Y /
              MainController.photoSceneModel.scale
          ),
          x2 = Math.floor(ex / MainController.photoSceneModel.scale),
          y2 = Math.floor(ey / MainController.photoSceneModel.scale);
        //将两点之间的整数点加入到seeds中
        MyFA.CommonFunction.getAllPointsOfLine(x1, y1, x2, y2, seeds);
        break;
    }

    //添加鼠标的滑动痕迹
    touchPointArray.push(new cvv.mypix(ex, ey));
  };

  //开始进行地板铺设时的事件处理
  p.floorBeginEvent = function () {
    //铺设地板状态下，canvas移除双指旋转的touch事件
    MainController.resultPic.canvas.removeEventListener(
      "touchstart",
      p.TouchStartEvent,
      false
    );
    //MainController.resultPic.canvas.removeEventListener("touchmove", p.TouchMoveEvent, false);
    MainController.resultPic.canvas.removeEventListener(
      "touchend",
      p.TouchEndEvent,
      false
    );

    //铺设地板状态下，canvas添加地板铺设的touch事件
    MainController.resultPic.canvas.addEventListener(
      "touchstart",
      p.judgeWallLocation,
      false
    );
    MainController.resultPic.canvas.addEventListener(
      "touchend",
      p.canvasPressup,
      false
    );
    MainController.resultPic.canvas.addEventListener(
      "touchmove",
      p.canvasPressmove,
      false
    );

    // 铺设地板状态下，canvas添加地板铺设的鼠标事件
    MainController.resultPic.canvas.addEventListener(
      "mousedown",
      p.judgeWallLocationmouse,
      false
    );
    MainController.resultPic.canvas.addEventListener(
      "mouseup",
      p.canvasPressupmouse,
      false
    );
    // MainController.resultPic.canvas.addEventListener(
    //   "mousemove",
    //   p.canvasPressmovemouse,
    //   false
    // );

    //在地板铺设完成前，隐藏舞台上其他家具
    for (var i = 0; i < MainController.resultPic.numChildren; i++) {
      if (MyFA.MainController.resultPic.getChildAt(i).name == "furniture") {
        MyFA.MainController.resultPic.getChildAt(i).visible = false;
      }
    }

    //设置一个全局的标志位，表示当前处于地板铺设状态
    MainController.photoSceneView.isEditFloor = true;
    //设置一个全局的标志位，表示当前不处于添加家具状态
    //MainController.photoSceneView.isEditFurniture = false;

    //缩小画布的缩小比例(自行注释掉)
    // MainController.photoSceneModel.setPhotoSceneScaleWhenFloor();
    MyFA.MainController.resultPic.update();
  };

  //地板铺设完成后后的事件处理
  p.floorEndEvent = function () {
    //canvas移除地板铺设的touch事件
    MainController.resultPic.canvas.removeEventListener(
      "touchstart",
      p.judgeWallLocation,
      false
    );
    MainController.resultPic.canvas.removeEventListener(
      "touchend",
      p.canvasPressup,
      false
    );
    MainController.resultPic.canvas.removeEventListener(
      "touchmove",
      p.canvasPressmove,
      false
    );

    //canvas添加双指旋转的touch事件
    MainController.resultPic.canvas.addEventListener(
      "touchstart",
      p.TouchStartEvent,
      false
    );
    //MainController.resultPic.canvas.addEventListener("touchmove", p.TouchMoveEvent, false);
    MainController.resultPic.canvas.addEventListener(
      "touchend",
      p.TouchEndEvent,
      false
    );

    //在地板铺设完成后，恢复舞台上其他家具的显示
    for (var i = 0; i < MainController.resultPic.numChildren; i++) {
      if (MainController.resultPic.getChildAt(i).name == "furniture") {
        var furnitureView =
          MainController.resultPic.getChildAt(i).furnitureView;
        furnitureView.ShowFurniture(MainController.resultPic.getChildAt(i));
      }
    }
    //扩大画布的缩放比例
    MainController.photoSceneModel.setPhotoSceneScale();
    p.updateFurnitures();
    MainController.resultPic.update();

    //表示当前退出地板铺设状态
    MainController.photoSceneView.isEditFloor = false;
    //MainController.photoSceneView.isEditFurniture = true;
  };

  //地板撤销功能
  p.removeFloorResult = function () {
    //场景model更新OriginalMat
    MainController.photoSceneModel.restoreOriginalMat();
    //场景view更新
    MainController.resultPic.update();
  };

  //存盘功能
  p.saveDesignHandle = function (designName) {
    window.ionicLoading.show({
      template:
        '<ion-spinner class="spinner-energized"></ion-spinner><br/>正在保存...',
    });

    setTimeout(save(designName), 300);
  };

  //存盘的具体操作
  function save(designName) {
    cancleSelectFur();
    MainController.resultPic.update();
    var saveObject = {};
    saveObject.name = designName;
    saveObject.photoScene = MainController.photoSceneModel.SaveFile();
    var retCanvas = document.getElementById("resultPic");
    //场景缩略图
    var _image = retCanvas.toDataURL("image/jpeg");
    _image = _image.replace(/data:image\/jpeg;base64,/, "");
    saveObject._image = _image;

    //将设计内容转化为json字符串
    var svae_data = JSON.stringify(saveObject);
    if (localStorage.isweixinbro == "yes") {
      //消费者使用推荐设计
      if (window.consumer == "yes") {
        window.currentDesignIndex = -1;
      }
    }

    //如果是覆盖已有设计
    if (window.currentDesignIndex != -1) {
      var post_data = {
        consumerID:
          localStorage.isweixinbro == "yes" ? localStorage.ConsumerID : "",
        clerkID: localStorage.isweixinbro == "yes" ? "" : localStorage.clerkid,
        designID: window.currentDesignIndex,
        designName: saveObject.name,
        dataJson: svae_data,
      };
      var up_data = {
        method: "POST",
        url: localStorage.BASEURL + "/UpdataDecorationDesign.aspx",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
        data: post_data,
      };
      window.ionicLoading.show();
      window
        .http_(up_data)
        .success(function (data) {
          window.ionicLoading.hide();
          if (data.success == true) {
            window.ionicPopup.alert({
              template: "修改成功",
            });
          } else {
            window.ionicPopup.alert({
              template: data.message,
            });
          }
        })
        .error(function () {
          window.ionicLoading.hide();
          window.ionicPopup.alert({
            template: "网络异常",
          });
        });
    }

    //如果是另存设计
    else {
      var postdata = {
        consumerID:
          localStorage.isweixinbro == "yes" ? localStorage.ConsumerID : "",
        clerkID: localStorage.isweixinbro == "yes" ? "" : localStorage.clerkid,
        designName: saveObject.name,
        dataJson: svae_data,
      };
      var req = {
        method: "POST",
        url: localStorage.BASEURL + "/AddDecorationDesign.aspx",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
        data: postdata,
      };
      window.ionicLoading.show();
      window
        .http_(req)
        .success(function (data) {
          window.ionicLoading.hide();
          if (data.success == true) {
            window.ionicPopup.alert({
              template: "保存成功",
            });
            //如果新建成功，将currentDesignIndex值改为新建的设计ID,
            //若重新保存设计时就变成了编辑设计
            window.currentDesignIndex = data.message;
          } else {
            window.ionicPopup.alert({
              template: data.message,
            });
          }
        })
        .error(function () {
          window.ionicLoading.hide();
          window.ionicPopup.alert({
            template: "网络异常",
          });
        });
    }
  }

  //将设计以图片的形式保存至手机(原比例)
  p.saveDesignToPhone = function (callBackFunc) {
    //临时将场景比例改为1
    MainController.photoSceneModel.scale = 1;
    cancleSelectFur();
    //根据场景缩放比例更改家具的缩放比例
    MainController.photoSceneView.putFloorResultToCanvas(
      MainController.photoSceneModel
    );
    p.updateFurnitures();
    //定义回调函数 该函数将在所有壁挂商品伸拉完后被调用。
    var c = function () {
      var retCanvas = MainController.resultPic.canvas;
      var photoPath = retCanvas.toDataURL("image/png");
      callBackFunc(photoPath);
    };
    //等待所有壁挂商品伸拉完
    setTimeout(function () {
      waitAllWallFurnituresFinished(c);
    }, 200);
  };

  //取消家具的选中状态
  function cancleSelectFur() {
    //取消家具的选中状态
    var stage = MainController.resultPic;
    for (var i = 0; i < stage.numChildren; i++) {
      if (stage.getChildAt(i).name == "furniture") {
        var furnitureModel = stage.getChildAt(i).furnitureModel;
        //如果家具当前处于被选中的状态
        if (furnitureModel.isSelected) {
          var furnitureView = stage.getChildAt(i).furnitureView;
          //去除家具上的黄色阴影
          furnitureView.CancelSelected(stage.getChildAt(i));
          //将家具的“isSelected（是否被选中）”标识设为false
          furnitureModel.isSelected = false;
          //去除家具上的拖动事件，使之在未选中的情况下不能拖动
          stage
            .getChildAt(i)
            .removeEventListener(
              "pressmove",
              furnitureView.furnitureMove,
              false
            );

          //移除详情面板按钮
          //如果家具的安装类型是地面，且目前处于被选中状态，则removeChildAt(2)，因为上面有还有一层阴影
          if (
            furnitureModel.installedType == 0 ||
            furnitureModel.installedType == 1 ||
            furnitureModel.installedType == 5
          ) {
            furnitureView.RemovePanelButton(stage.getChildAt(i), 2);
          }
          //如果家具的安装类型是墙面，且目前处于被选中状态，则removeChildAt(1)
          if (
            furnitureModel.installedType == 2 ||
            furnitureModel.installedType == 6 ||
            furnitureModel.installedType == 7
          ) {
            furnitureView.RemovePanelButton(stage.getChildAt(i), 1);
          }
          //如果找到了一个选中的家具，则跳出循环，因为只能同时选中一个家具
          break;
        }
      }
    }
  }

  //等待所有的壁挂都加载（伸拉）完成，调用回调函数
  //callBackFunc:回调函数
  function waitAllWallFurnituresFinished(callBackFunc) {
    //判断所有的壁挂是否都加载（伸拉）完成
    var isSuccess = p.isAllWallFurnituresFinished();
    //如果==true
    if (isSuccess) {
      //调用回调函数
      callBackFunc();
    }
    //如果==false
    else {
      //继续等待
      setTimeout(function () {
        waitAllWallFurnituresFinished(callBackFunc);
      }, 200);
    }
  }

  //判断所有的壁挂是否都加载（伸拉）完成，在保存至手机时/转屏/打开设计时要使用
  p.isAllWallFurnituresFinished = function () {
    var isFinished = true;
    var stage = MainController.resultPic;
    for (var i = 0; i < stage.numChildren; i++) {
      if (stage.getChildAt(i).name == "furniture") {
        var furnitureModel = stage.getChildAt(i).furnitureModel;
        var furnitureView = stage.getChildAt(i).furnitureView;
        //如果家具的安装类型是墙面
        if (
          furnitureModel.installedType == 2 ||
          furnitureModel.installedType == 6 ||
          furnitureModel.installedType == 7
        ) {
          if (furnitureView.isStretchFinished != true) {
            isFinished = false;
            break;
          }
        }
      }
    }
    return isFinished;
  };

  // //将设计以图片的形式保存至手机后，恢复场景和家具的缩放比例
  // p.restoreDesignAfterToPhone = function () {
  //   //恢复场景和家具的缩放比例
  //   MainController.photoSceneModel.setPhotoSceneScale();
  //   //根据场景缩放比例更改家具的缩放比例
  //   MainController.photoSceneView.putFloorResultToCanvas(
  //     MainController.photoSceneModel
  //   );
  //   p.updateFurnitures();
  // };

  p.openDesign = function (callBack) {
    //try {

    // 何路： /////////////////////////////
    //canvas添加Click监听事件
    //点击空白处不选中任何家具
    MyFA.MainController.resultPic.canvas.addEventListener(
      "click",
      p.stageClick,
      false
    );
    //canvas上添加touch监听事件
    MyFA.MainController.resultPic.canvas.addEventListener(
      "touchstart",
      p.TouchStartEvent,
      false
    );
    MyFA.MainController.resultPic.canvas.addEventListener(
      "touchend",
      p.TouchEndEvent,
      false
    );
    //////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////

    //实例化一个新的场景model
    MainController.photoSceneModel = new MyFA.PhotoSceneModel();
    MainController.photoSceneModel.OpenFile();
    //添加事件订阅
    MainController.resultPic.addSubscriber(
      MainController.photoSceneView.updateCanvas,
      MainController.photoSceneView,
      MainController.photoSceneModel
    );
    setTimeout(function () {
      waitingMolelFinished(callBack);
    }, 100);

    //} catch (e) {
    //    alert(e);
    //}
  };

  //等待PhotoSceneModel实例化完毕
  function waitingMolelFinished(callBack) {
    //如果场景Model打开完毕
    if (MainController.photoSceneModel.isOpenFinished) {
      // 何路：以下是根据model更新PhotoSceneView////////////////
      //      挪到PhotoSceneView.update
      MainController.photoSceneView.drawCanvas();
      /////////////////////////////////////////////////////

      //恢复设计上原有的家具
      var furModels = MainController.photoSceneModel.furModels;
      var leng = furModels.length;
      for (var i = 0; i < furModels.length; i++) {
        // 何路：View和Model的工作应该分清楚，不能写在一起
        var furniture = new MyFA.FurnitureModel();
        furniture = MyFA.CommonFunction.deepCopy(furniture, furModels[i]);
        furniture.hasBeenSaved = true;
        p.addFurniture(furniture);
      }
      //防止设计里的家具数量加倍
      MainController.photoSceneModel.furModels.splice(0, leng);
      //如果有从商城直接添加的家具，则将这些家具也加入到设计中
      if (window.selectFurnitureFromMall != undefined) {
        p.addFurniture(window.selectFurnitureFromMall);
      }

      //判断所有的壁挂是否都加载（伸拉）完成
      var isSuccess = p.isAllWallFurnituresFinished();

      var c = function () {
        window.ionicLoading.hide();
        callBack();
      };
      setTimeout(function () {
        waitAllWallFurnituresFinished(c);
      }, 200);
    }
    //如果场景还未加载完毕，则继续等待，则继续等待
    else {
      setTimeout(function () {
        waitingMolelFinished(callBack);
      }, 100);
    }
  }

  MyFA.MainController = MainController;
  // console.log(MyFA);
})();
