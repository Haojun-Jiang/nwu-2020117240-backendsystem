﻿this.MyFurnitureAssistant = this.MyFurnitureAssistant || {};
// 定义别名(快捷名)：
if (typeof this.MyFA === "undefined") {
  this.MyFA = this.MyFurnitureAssistant;
}
//家具View
(function () {
  //构造函数
  function FurnitureView() {
    //事件订阅者数组置为空
    this.subscribers = [];
  }

  var p = FurnitureView.prototype;

  //添加家具到场景中来
  p.AddFurnitureToStage = function (furniture, stage) {
    var _this = this;
    //实例化一个用来盛放家具的Container
    var fc = this.AddFurnitureContainer(furniture, stage);
    var img = new Image();
    //解决图片的跨域问题
    img.crossOrigin = "Anonymous";
    img.src = furniture.imgSrc;
    img.onload = handleImageLoad;
    //furniture.image = img;
    var bitmap;

    //图片的加载事件
    function handleImageLoad(event) {
      var photoSceneModel = furniture.parent;
      stage.addChild(fc);
      bitmap = new createjs.Bitmap(event.target);
      //设置bitmap的比例
      _this.UpdateFurScale(
        bitmap,
        furniture.scaleY * photoSceneModel.scale,
        furniture.scaleY * photoSceneModel.scale
      );

      //如果是第一次加入到设计，即以前未被保存过，则需要确定家具的初始放置位置
      if (!furniture.hasBeenSaved) {
        //确定家具的初始放置位置

        var arr = photoSceneModel.WallLineModel.arr;
        //正对矩形墙面的情况（8点8线）
        if (arr.length == 8) {
          //根据家具图片的八个像素点确定家具的初始放置位置
          //bbl与灭点平齐
          var bblX = arr[5].Px + furniture.scaleX * furniture.pixWidth;
          var bblY = (arr[5].Py + arr[6].Py) * 0.5;

          //用bbl的坐标分别推算出家具图片四角的舞台坐标
          furniture.setFurLocationBybbl(
            bblX,
            bblY,
            furniture.scaleX,
            furniture.scaleY
          );
          fc.x = furniture.leftUpPointX * photoSceneModel.scale;
          fc.y = furniture.leftUpPointY * photoSceneModel.scale;

          //如果家具太宽，则放在arr[5]处，防止家具上右墙
          if (
            fc.x + bitmap.scaleX * furniture.pixWidth >
            arr[6].Px * photoSceneModel.scale
          ) {
            bblX = arr[5].Px + 20;
            //用bbl的坐标分别推算出家具图片四角的舞台坐标
            furniture.setFurLocationBybbl(
              bblX,
              bblY,
              furniture.scaleX,
              furniture.scaleY
            );
            fc.x = furniture.leftUpPointX * photoSceneModel.scale;
            fc.y = furniture.leftUpPointY * photoSceneModel.scale;
          }
        }
        //TODO:正对墙角的情况（6点5线）
        else {
          //如果放在左墙
          if (furniture.picAngle <= 0) {
            //bbr与灭点平齐
            var bbrX = arr[4].Px;
            var bbrY = arr[4].Py;

            //用bbr的坐标分别推算出家具图片四角的舞台坐标
            furniture.setFurLocationBybbr(
              bbrX,
              bbrY,
              furniture.scaleX,
              furniture.scaleY
            );

            _this.calPointsBybbr(
              bbrX,
              bbrY,
              furniture.scaleX,
              furniture.scaleY,
              furniture
            );
          } else {
            //如果放在右墙，bbl与灭点平齐
            var bblX = arr[4].Px;
            var bblY = arr[4].Py;

            //用bbl的坐标分别推算出家具图片四角的舞台坐标
            furniture.setFurLocationBybbl(
              bblX,
              bblY,
              furniture.scaleX,
              furniture.scaleY
            );

            _this.calPointsBybbl(
              bblX,
              bblY,
              furniture.scaleX,
              furniture.scaleY,
              furniture
            );
          }
        }

        //if (furniture.installedType == 0) {//进行位置矫正
        //    _this.regionRestrictWhenPressup(furniture);
        //}

        //将家具推到照片下沿
        if (photoSceneModel.imageHeight / 2 - furniture.leftDownPointY > 0) {
          _this.pushFurniture(
            fc,
            0,
            photoSceneModel.imageHeight / 2 - furniture.leftDownPointY
          );

          //保证家具能完全显示在画布内
          if (furniture.leftUpPointX < 0) {
            var offsetX = 0 - furniture.leftUpPointX;
            furniture.leftUpPointX += offsetX;
            furniture.rightUpPointX += offsetX;
            furniture.leftDownPointX += offsetX;
            furniture.rightDownPointX += offsetX;
          } else if (furniture.rightUpPointX > photoSceneModel.imageWidth / 2) {
            var offsetX =
              photoSceneModel.imageWidth / 2 - furniture.rightUpPointX;
            furniture.leftUpPointX += offsetX;
            furniture.rightUpPointX += offsetX;
            furniture.leftDownPointX += offsetX;
            furniture.rightDownPointX += offsetX;
          }
        }

        //地面家具：家具y最大的顶点的y值作为z轴顺序。
        if (furniture.installedType == 0) {
          var zIndexFloor = furniture.leftDownPointY * photoSceneModel.scale;
          fc.sy = zIndexFloor;
        }
        //房顶家具 z取200000，按添加的顺序递增
        else if (furniture.installedType == 1) {
          fc.sy = MyFA.MainController.photoSceneView.zIndexLight;
          MyFA.MainController.photoSceneView.zIndexLight++;
        }
        //家装饰品 z取300000，按添加的顺序递增
        else if (furniture.installedType == 5) {
          fc.sy = MyFA.MainController.photoSceneView.zIndexOrnament;
          MyFA.MainController.photoSceneView.zIndexOrnament++;
        }
      }
      //如果是打开已有设计，则记录家具的z轴顺序
      else {
        fc.sy = furniture.sy;
      }

      var scaleX =
        (furniture.rightUpPointX - furniture.leftUpPointX) / furniture.pixWidth;
      var scaleY =
        (furniture.leftDownPointY - furniture.leftUpPointY) /
        furniture.pixHeight;

      furniture.updateRealTimeScale(scaleX, scaleY);

      //alert(furniture.scaleY);

      //将家具图片的像素坐标转换为舞台坐标,定位container的放置位置
      _this.UpdateFurPosition(
        fc,
        furniture.leftUpPointX * photoSceneModel.scale,
        furniture.leftUpPointY * photoSceneModel.scale
      );

      //设置bitmap的比例
      _this.UpdateFurScale(
        bitmap,
        furniture.scaleY * photoSceneModel.scale,
        furniture.scaleY * photoSceneModel.scale
      );
      fc.addChild(bitmap);
      //家具上面覆盖一层透明层，以此扩大触摸的感应范围
      _this.DrawAlphaShadow(fc);
      stage.sortChildren(_this.sortFurnituresByZ);
      //如果是打开已有设计，保持家具的亮度
      if (furniture.hasBeenSaved && furniture.furnitureBrightness != 50)
        _this.ChangeFurBrightness(fc, furniture.furnitureBrightness);
      stage.update();

      window.ionicLoading.hide();
    }
  };

  //实例化一个家具Container
  //返回一个新实例化的Container
  p.AddFurnitureContainer = function (furniture, stage) {
    //如果是第一次加入到设计，即以前未被保存过，则需要确定家具的初始放置比例

    if (!furniture.hasBeenSaved) {
      //计算家具初始放入场景时应该呈现的角度
      ////报错
      furniture.calInitDisplayAngle();
      //根据确定好的角度图片来计算家具初始放置比例
      //furnitureScaleX：家具图片的X缩放比例（未乘场景比例）
      var furnitureScaleX = furniture.InitScalerY() * 1;

      //furnitureScaleY：家具图片的Y缩放比例（未乘场景比例）
      var furnitureScaleY = furniture.InitScalerY() * 1;

      //记录家具的初始放置比例（初次进入场景时，未经过任何角度替换），在进行区域限制时要使用
      furniture.updateInitScale(furnitureScaleX, furnitureScaleY);
      furniture.updateRealTimeScale(furnitureScaleX, furnitureScaleY);
    }

    //实例化一个用来盛放家具的Container
    var fc = new createjs.Container();
    fc.name = "furniture";
    //给家具container绑定Model和View,方便以后使用
    fc.furnitureView = this;
    fc.furnitureModel = furniture;

    //添加家具的mousedown事件
    fc.addEventListener("mousedown", this.MouseDownHandle, false);
    //添加家具的pressup事件
    fc.addEventListener("pressup", this.PressupHandler, false);
    stage.update();
    return fc;
  };

  //删除家具
  p.RemoveFurFromStage = function (fc, stage) {
    stage.removeChild(fc);
    stage.update();
  };

  //修改家具的位置
  //fc:container
  //x:x坐标  y:y坐标
  p.UpdateFurPosition = function (fc, x, y) {
    //alert(x);
    //alert(y);
    fc.x = x;
    fc.y = y;
  };

  //更新家具的缩放比例
  //furBitmap:放置图片的bitmap
  //scaleX:x方向缩放比例  scaleY:y方向缩放比例
  p.UpdateFurScale = function (furBitmap, scaleX, scaleY) {
    furBitmap.scaleX = scaleX;
    furBitmap.scaleY = scaleY;
  };

  //选中某个家具
  p.ShowSelected = function (fc) {
    // //调用新手帮助
    // if (localStorage.timeis == 1) {
    //   toshowbluepoint();
    // }
    var fIndex = fc.parent.getChildIndex(fc);
    //遍历所有家具(确保只有一个处于选中状态)
    for (var i = 0; i < fc.parent.numChildren; i++) {
      var targetFur = fc.parent.getChildAt(i);
      if (targetFur.name == "furniture") {
        var furnitureModel = targetFur.furnitureModel;
        var furnitureView = targetFur.furnitureView;
        if (i == fIndex) {
          targetFur.shadow = new createjs.Shadow("yellow", 3, 3, 6);
          //furnitureView.RedrawAlphaShadow(targetFur);
          continue;
        }
        //找到之前被选中的家具
        furnitureView.CancelSelected(targetFur);
        furnitureModel.isSelected = false;
        //targetFur.removeEventListener("pressmove", window.funMove[targetFur.id], false);
        targetFur.removeEventListener(
          "pressmove",
          furnitureView.furnitureMove,
          false
        );
        //如果家具的安装类型是地面，则removeChildAt(2)，因为上面有还有一层阴影
        if (
          furnitureModel.installedType == 0 ||
          furnitureModel.installedType == 1 ||
          furnitureModel.installedType == 5
        ) {
          furnitureView.RemovePanelButton(targetFur, 2);
        }
        //如果家具的安装类型是墙面，则removeChildAt(1)
        if (
          furnitureModel.installedType == 2 ||
          furnitureModel.installedType == 6 ||
          furnitureModel.installedType == 7
        ) {
          furnitureView.RemovePanelButton(targetFur, 1);
        }
      }
    }
  };

  //取消显示选中状态
  p.CancelSelected = function (fc) {
    fc.shadow = null;
  };

  //隐藏某个家具
  p.HideFurniture = function (fc) {
    fc.visible = false;
  };

  //显示某个家具
  p.ShowFurniture = function (fc) {
    fc.visible = true;
  };

  //绘制家具左上角的详情面板按钮
  p.DrawPanelButton = function (fc) {
    var img = new Image();
    img.src = "img/images/detail.png";
    img.onload = function (event) {
      var bitmap = new createjs.Bitmap(event.target);
      bitmap.name = "detailButton";
      bitmap.scaleX = 0.45;
      bitmap.scaleY = 0.45;
      var furniture = fc.furnitureModel;
      var photoSceneModel = furniture.parent;
      //将舞台坐标转换为局部坐标，以此来确定该按钮在Container中的位置
      var LocalPosition = fc.globalToLocal(
        furniture.leftUpPointX * photoSceneModel.scale,
        furniture.leftUpPointY * photoSceneModel.scale
      );

      if (furniture.leftUpPointX * photoSceneModel.scale > 40) {
        LocalPosition = fc.globalToLocal(
          furniture.leftUpPointX * photoSceneModel.scale,
          furniture.leftUpPointY * photoSceneModel.scale
        );
        LocalPosition.x = LocalPosition.x - 40;
        LocalPosition.y = LocalPosition.y - 30;
      } else if (
        furniture.rightUpPointX * photoSceneModel.scale <
        fc.parent.canvas.width - 40
      ) {
        LocalPosition = fc.globalToLocal(
          furniture.rightUpPointX * photoSceneModel.scale,
          furniture.rightUpPointY * photoSceneModel.scale
        );
        LocalPosition.y = LocalPosition.y - 30;
      } else {
        LocalPosition = fc.globalToLocal(
          ((furniture.leftUpPointX + furniture.rightUpPointX) / 2) *
            photoSceneModel.scale,
          furniture.leftUpPointY * photoSceneModel.scale
        );
        LocalPosition.y = LocalPosition.y - 30;
      }
      bitmap.x = LocalPosition.x;
      bitmap.y = LocalPosition.y;
      bitmap.addEventListener("click", FurnitureView.openFurDetailPanel, false);
      fc.addChild(bitmap);
      fc.parent.update();
    };
  };

  //重新绘制家具详情按钮的位置
  p.RedrawPanelButton = function (fc) {
    var furniture = fc.furnitureModel;
    var photoSceneModel = furniture.parent;
    var bitmap;
    //如果家具的安装类型是地面，且目前处于被选中状态，则removeChildAt(2)，因为上面有还有一层阴影
    if (
      furniture.installedType == 0 ||
      furniture.installedType == 1 ||
      furniture.installedType == 5
    ) {
      bitmap = fc.getChildAt(2);
    }
    //如果家具的安装类型是墙面，且目前处于被选中状态，则removeChildAt(1)
    if (
      furniture.installedType == 2 ||
      furniture.installedType == 6 ||
      furniture.installedType == 7
    ) {
      bitmap = fc.getChildAt(1);
    }

    //将舞台坐标转换为局部坐标，以此来确定该按钮在Container中的位置
    var LocalPosition = fc.globalToLocal(
      furniture.leftUpPointX * photoSceneModel.scale,
      furniture.leftUpPointY * photoSceneModel.scale
    );

    if (furniture.leftUpPointX * photoSceneModel.scale > 40) {
      LocalPosition = fc.globalToLocal(
        furniture.leftUpPointX * photoSceneModel.scale,
        furniture.leftUpPointY * photoSceneModel.scale
      );
      LocalPosition.x = LocalPosition.x - 40;
      LocalPosition.y = LocalPosition.y - 30;
    } else if (
      furniture.rightUpPointX * photoSceneModel.scale <
      fc.parent.canvas.width - 40
    ) {
      LocalPosition = fc.globalToLocal(
        furniture.rightUpPointX * photoSceneModel.scale,
        furniture.rightUpPointY * photoSceneModel.scale
      );
      LocalPosition.y = LocalPosition.y - 30;
    } else {
      LocalPosition = fc.globalToLocal(
        ((furniture.leftUpPointX + furniture.rightUpPointX) / 2) *
          photoSceneModel.scale,
        furniture.leftUpPointY * photoSceneModel.scale
      );
      LocalPosition.y = LocalPosition.y - 30;
    }
    if (bitmap != undefined) {
      bitmap.x = LocalPosition.x;
      bitmap.y = LocalPosition.y;
      //fc.parent.update();
    }
  };

  //移除家具上的详情面板按钮
  //fc:container
  //index:详情按钮在container中的索引
  p.RemovePanelButton = function (fc, index) {
    fc.removeChildAt(index);
  };

  //给container上涂上一层透明的阴影，目的：扩大感应范围，避免家具选不中的问题
  p.DrawAlphaShadow = function (fc) {
    var furniture = fc.furnitureModel;
    var photoSceneModel = furniture.parent;
    var shape = new createjs.Shape();
    if (furniture.isNeedShadow) {
      var shadowWidth = Math.floor(
        furniture.scaleX * furniture.pixWidth * photoSceneModel.scale
      );
      var shadowHeight = Math.floor(
        furniture.scaleY * furniture.pixHeight * photoSceneModel.scale
      );

      shape.graphics
        .setStrokeStyle(shadowHeight)
        .beginStroke("rgba(255,255,255,0.01)");
      shape.graphics.moveTo(0, shadowHeight * 0.5);
      shape.graphics.lineTo(0 + shadowWidth, shadowHeight * 0.5);
      shape.graphics.endStroke();
    }
    fc.addChild(shape);
  };

  //（移动过程中)重新绘制家具上面的透明阴影
  p.RedrawAlphaShadow = function (fc) {
    var furniture = fc.furnitureModel;
    var photoSceneModel = furniture.parent;
    var shadowWidth = Math.floor(
      furniture.scaleX * furniture.pixWidth * photoSceneModel.scale
    );
    var shadowHeight = Math.floor(
      furniture.scaleY * furniture.pixHeight * photoSceneModel.scale
    );
    var shape = fc.getChildAt(1);
    if (furniture.isNeedShadow) {
      shape.graphics.clear();
      shape.graphics
        .setStrokeStyle(shadowHeight)
        .beginStroke("rgba(255,255,255,0.01)");
      shape.graphics.moveTo(0, shadowHeight * 0.5);
      shape.graphics.lineTo(0 + shadowWidth, shadowHeight * 0.5);
    }
  };

  //调节家具亮度
  p.ChangeFurBrightness = function (fc, brightness) {
    var stage = fc.parent;
    //获取所选中家具照片bitmap
    var bitmap = fc.getChildAt(0);

    var matrix = new createjs.ColorMatrix().adjustBrightness(brightness);
    bitmap.filters = [new createjs.ColorMatrixFilter(matrix)];
    //必须调用cache方法，否则过滤器不生效
    bitmap.cache(0, 0, bitmap.image.width, bitmap.image.height); //参数说明：X坐标，Y坐标，宽度，高度
    //stage.update();
  };

  //点击家具详情按钮的事件处理
  p.DetailHandle = function () {};

  //鼠标按下事件
  p.MouseDownHandle = function (event) {
    var fc = event.target.parent;
    var furnitureModel = fc.furnitureModel;
    var furnitureView = fc.furnitureView;

    // //辅助变量。
    //sx, sy为手指移动时的实时位置
    furnitureView.sx = event.stageX;
    furnitureView.sy = event.stageY;
    //sx1, sy1为按下时的位置
    furnitureView.sx1 = event.stageX;
    furnitureView.sy1 = event.stageY;

    leftUpPointX1 = furnitureModel.leftUpPointX;
    leftUpPointY1 = furnitureModel.leftUpPointY;
    rightUpPointX1 = furnitureModel.rightUpPointX;
    rightUpPointY1 = furnitureModel.rightUpPointY;
    leftDownPointX1 = furnitureModel.leftDownPointX;
    leftDownPointY1 = furnitureModel.leftDownPointY;
    rightDownPointX1 = furnitureModel.rightDownPointX;
    rightDownPointY1 = furnitureModel.rightDownPointY;

    //按下瞬间，选中家具，添加移动事件
    if (!furnitureModel.isSelected) {
      furnitureModel.isSelected = !furnitureModel.isSelected;
      //选中家具时添加黄边
      furnitureView.ShowSelected(fc);
      //绘制详情面板按钮
      furnitureView.DrawPanelButton(fc);

      //添加Move监听事件
      fc.addEventListener("pressmove", furnitureView.furnitureMove, false);

      //发布“选中家具事件”
      var args = [];
      args[0] = fc;
      args[1] = furnitureModel.furnitureID;
      furnitureView.publish("selectFurniture", args);
    }
  };

  //鼠标松开事件
  p.PressupHandler = function (event) {};

  //移动事件
  p.furnitureMove = function (event) {};

  //鼠标移动事件
  p.PressmoveHandler = function () {};

  //区域限制
  p.regionRestrict = function () {};

  //移动时将家具限制在canvas之内（各种类型的家具都适用）
  p.restrictFurInCanvas = function (fc) {
    var furniture = fc.furnitureModel;
    var photoSceneModel = furniture.parent;
    var stage = document.getElementById("resultPic");
    //判断是否超过canvas左边界
    if (furniture.leftUpPointX < 0 || furniture.leftDownPointX < 0) {
      var luX = furniture.leftUpPointX;
      furniture.leftUpPointX = 0;
      furniture.leftDownPointX = 0;
      furniture.rightUpPointX =
        furniture.rightUpPointX - luX + furniture.leftUpPointX;
      furniture.rightDownPointX =
        furniture.rightDownPointX - luX + furniture.leftUpPointX;
    }
    //判断是否超过canvas右边界
    else if (
      furniture.rightUpPointX > stage.width / photoSceneModel.scale ||
      furniture.rightDownPointX > stage.width / photoSceneModel.scale
    ) {
      var ruX = furniture.rightUpPointX;
      furniture.rightUpPointX = stage.width / photoSceneModel.scale;
      furniture.rightDownPointX = stage.width / photoSceneModel.scale;

      furniture.leftUpPointX =
        furniture.leftUpPointX - ruX + furniture.rightUpPointX;
      furniture.leftDownPointX =
        furniture.leftDownPointX - ruX + furniture.rightUpPointX;
    }

    if (
      furniture.installedType != 2 &&
      furniture.installedType != 6 &&
      furniture.installedType != 7
    ) {
      //判断是否超过canvas上边界
      if (furniture.leftUpPointY < 0 || furniture.rightUpPointY < 0) {
        var luY = furniture.leftUpPointY;
        furniture.leftUpPointY = 0;
        furniture.rightUpPointY = 0;
        furniture.leftDownPointY =
          furniture.leftDownPointY - luY + furniture.leftUpPointY;
        furniture.rightDownPointY =
          furniture.rightDownPointY - luY + furniture.leftUpPointY;
      }
      //判断是否超过canvas下边界
      else if (
        furniture.leftDownPointY > stage.height / photoSceneModel.scale ||
        furniture.rightDownPointY > stage.height / photoSceneModel.scale
      ) {
        var ruY = furniture.leftDownPointY;
        furniture.leftDownPointY = stage.height / photoSceneModel.scale;
        furniture.rightDownPointY = stage.height / photoSceneModel.scale;
        furniture.rightUpPointY =
          furniture.rightUpPointY - ruY + furniture.leftDownPointY;
        furniture.leftUpPointY =
          furniture.leftUpPointY - ruY + furniture.leftDownPointY;
      }
    }
  };

  //用bbl计算其他7个点的坐标
  p.calPointsBybbl = function (bblX, bblY, scaleX, scaleY, furniture) {
    //后缀为“2”的是家具（内接长方体）背面四个点的舞台坐标
    leftUpPointX2 = (furniture.btlX - furniture.bblX) * scaleX + bblX;
    leftUpPointY2 = (furniture.btlY - furniture.bblY) * scaleY + bblY;
    rightUpPointX2 = (furniture.btrX - furniture.bblX) * scaleX + bblX;
    rightUpPointY2 = (furniture.btrY - furniture.bblY) * scaleY + bblY;
    leftDownPointX2 = (furniture.bblX - furniture.bblX) * scaleX + bblX;
    leftDownPointY2 = (furniture.bblY - furniture.bblY) * scaleY + bblY;
    rightDownPointX2 = (furniture.bbrX - furniture.bblX) * scaleX + bblX;
    rightDownPointY2 = (furniture.bbrY - furniture.bblY) * scaleY + bblY;

    //后缀为“3”的是家具（内接长方体）前面四个点的舞台坐标
    leftUpPointX3 = (furniture.ftlX - furniture.bblX) * scaleX + bblX;
    leftUpPointY3 = (furniture.ftlY - furniture.bblY) * scaleY + bblY;
    rightUpPointX3 = (furniture.ftrX - furniture.bblX) * scaleX + bblX;
    rightUpPointY3 = (furniture.ftrY - furniture.bblY) * scaleY + bblY;
    leftDownPointX3 = (furniture.fblX - furniture.bblX) * scaleX + bblX;
    leftDownPointY3 = (furniture.fblY - furniture.bblY) * scaleY + bblY;
    rightDownPointX3 = (furniture.fbrX - furniture.bblX) * scaleX + bblX;
    rightDownPointY3 = (furniture.fbrY - furniture.bblY) * scaleY + bblY;
  };

  //用bbr计算其他7个点的坐标
  p.calPointsBybbr = function (bbrX, bbrY, scaleX, scaleY, furniture) {
    //后缀为“2”的是家具（内接长方体）背面四个点的舞台坐标
    leftUpPointX2 = (furniture.btlX - furniture.bbrX) * scaleX + bbrX;
    leftUpPointY2 = (furniture.btlY - furniture.bbrY) * scaleY + bbrY;
    rightUpPointX2 = (furniture.btrX - furniture.bbrX) * scaleX + bbrX;
    rightUpPointY2 = (furniture.btrY - furniture.bbrY) * scaleY + bbrY;
    leftDownPointX2 = (furniture.bblX - furniture.bbrX) * scaleX + bbrX;
    leftDownPointY2 = (furniture.bblY - furniture.bbrY) * scaleY + bbrY;
    rightDownPointX2 = (furniture.bbrX - furniture.bbrX) * scaleX + bbrX;
    rightDownPointY2 = (furniture.bbrY - furniture.bbrY) * scaleY + bbrY;

    //后缀为“3”的是家具（内接长方体）前面四个点的舞台坐标
    leftUpPointX3 = (furniture.ftlX - furniture.bbrX) * scaleX + bbrX;
    leftUpPointY3 = (furniture.ftlY - furniture.bbrY) * scaleY + bbrY;
    rightUpPointX3 = (furniture.ftrX - furniture.bbrX) * scaleX + bbrX;
    rightUpPointY3 = (furniture.ftrY - furniture.bbrY) * scaleY + bbrY;
    leftDownPointX3 = (furniture.fblX - furniture.bbrX) * scaleX + bbrX;
    leftDownPointY3 = (furniture.fblY - furniture.bbrY) * scaleY + bbrY;
    rightDownPointX3 = (furniture.fbrX - furniture.bbrX) * scaleX + bbrX;
    rightDownPointY3 = (furniture.fbrY - furniture.bbrY) * scaleY + bbrY;
  };

  //用fbl计算其他7个点的坐标
  p.calPointsByfbl = function (fblX, fblY, scaleX, scaleY, furniture) {
    //后缀为“2”的是家具（内接长方体）背面四个点的舞台坐标
    //leftUpPointX2 = (furniture.btlX - furniture.fblX) * scaleX + fblX;
    //leftUpPointY2 = (furniture.btlY - furniture.fblY) * scaleY + fblY;
    //rightUpPointX2 = (furniture.btrX - furniture.fblX) * scaleX + fblX;
    //rightUpPointY2 = (furniture.btrY - furniture.fblY) * scaleY + fblY;
    leftDownPointX2 = (furniture.bblX - furniture.fblX) * scaleX + fblX;
    leftDownPointY2 = (furniture.bblY - furniture.fblY) * scaleY + fblY;
    rightDownPointX2 = (furniture.bbrX - furniture.fblX) * scaleX + fblX;
    rightDownPointY2 = (furniture.bbrY - furniture.fblY) * scaleY + fblY;

    //后缀为“3”的是家具（内接长方体）前面四个点的舞台坐标
    //leftUpPointX3 = (furniture.ftlX - furniture.fblX) * scaleX + fblX;
    //leftUpPointY3 = (furniture.ftlY - furniture.fblY) * scaleY + fblY;
    //rightUpPointX3 = (furniture.ftrX - furniture.fblX) * scaleX + fblX;
    //rightUpPointY3 = (furniture.ftrY - furniture.fblY) * scaleY + fblY;
    leftDownPointX3 = (furniture.fblX - furniture.fblX) * scaleX + fblX;
    leftDownPointY3 = (furniture.fblY - furniture.fblY) * scaleY + fblY;
    rightDownPointX3 = (furniture.fbrX - furniture.fblX) * scaleX + fblX;
    rightDownPointY3 = (furniture.fbrY - furniture.fblY) * scaleY + fblY;
  };

  //用fbr计算其他7个点的坐标
  p.calPointsByfbr = function (fbrX, fbrY, scaleX, scaleY, furniture) {
    //后缀为“2”的是家具（内接长方体）背面四个点的舞台坐标
    //leftUpPointX2 = (furniture.btlX - furniture.fbrX) * scaleX + fbrX;
    //leftUpPointY2 = (furniture.btlY - furniture.fbrY) * scaleY + fbrY;
    //rightUpPointX2 = (furniture.btrX - furniture.fbrX) * scaleX + fbrX;
    //rightUpPointY2 = (furniture.btrY - furniture.fbrY) * scaleY + fbrY;
    leftDownPointX2 = (furniture.bblX - furniture.fbrX) * scaleX + fbrX;
    leftDownPointY2 = (furniture.bblY - furniture.fbrY) * scaleY + fbrY;
    rightDownPointX2 = (furniture.bbrX - furniture.fbrX) * scaleX + fbrX;
    rightDownPointY2 = (furniture.bbrY - furniture.fbrY) * scaleY + fbrY;

    //后缀为“3”的是家具（内接长方体）前面四个点的舞台坐标
    //leftUpPointX3 = (furniture.ftlX - furniture.fbrX) * scaleX + fbrX;
    //leftUpPointY3 = (furniture.ftlY - furniture.fbrY) * scaleY + fbrY;
    //rightUpPointX3 = (furniture.ftrX - furniture.fbrX) * scaleX + fbrX;
    //rightUpPointY3 = (furniture.ftrY - furniture.fbrY) * scaleY + fbrY;
    leftDownPointX3 = (furniture.fblX - furniture.fbrX) * scaleX + fbrX;
    leftDownPointY3 = (furniture.fblY - furniture.fbrY) * scaleY + fbrY;
    rightDownPointX3 = (furniture.fbrX - furniture.fbrX) * scaleX + fbrX;
    rightDownPointY3 = (furniture.fbrY - furniture.fbrY) * scaleY + fbrY;
  };

  //设置家具的Z轴（设置家具的前后顺序）
  p.sortFurnituresByZ = function (a, b) {
    //a和b分别为Parent的两个Child
    //Display children with a higher y in front
    return a.sy - b.sy;
  };

  //添加订阅
  p.addSubscriber = function (callback, caller, args, name) {
    //保证每个订阅者只添加一次
    var isSubscriberAdded = false;
    var subscriberIndex = 0;
    for (var i = 0; i < this.subscribers.length; i++) {
      if (this.subscribers[i].name == name) {
        isSubscriberAdded = true;
        subscriberIndex = i;
      }
    }

    if (!isSubscriberAdded) {
      this.subscribers[this.subscribers.length] = {
        func: callback,
        caller: caller,
        args: args,
        name: name,
      };
    }
    //如果添加过该订阅者，替换该订阅者的caller和args,
    //即修改apply(thisObj,array)中的thisObj和array
    else {
      this.subscribers[subscriberIndex].caller = caller;
      this.subscribers[subscriberIndex].args = args;
    }
  };
  //删除订阅者
  p.removeSubscriber = function (callback) {
    for (var i = 0; i < this.subscribers.length; i++) {
      if (this.subscribers[i].func === callback) {
        delete this.subscribers[i];
      }
    }
  };
  //授受并传递参数给订阅者
  //name:订阅者名称
  //args:参数
  p.publish = function (name, args) {
    for (var i = 0; i < this.subscribers.length; i++) {
      if (this.subscribers[i].name == name) {
        args.push(this.subscribers[i].args);
        this.subscribers[i].func.apply(this.subscribers[i].caller, args);
      }
    }
  };
  //发布“绘制警示线事件”
  p.pubDrawAlertLine = function (P1, P2) {
    var args = [];
    args[0] = P1;
    args[1] = P2;
    this.publish("drawAlertLine", args);
  };
  MyFA.FurnitureView = FurnitureView;
})();
