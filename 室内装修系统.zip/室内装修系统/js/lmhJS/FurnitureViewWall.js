﻿this.MyFurnitureAssistant = this.MyFurnitureAssistant || {};
// 定义别名(快捷名)：
if (typeof this.MyFA === "undefined") {
  this.MyFA = this.MyFurnitureAssistant;
}
//壁挂类型家具View
(function () {
  var zIndex = -300000; //用以设置壁挂商品的z轴顺序。初始值为-300000
  //furniture：家具model
  //stage：舞台
  function FurnitureViewWall(furniture, stage) {
    //this.subscribers = [];
    ////实例化后直接添加家具到场景中  将家具添加到画布
    this.AddFurnitureToStage(furniture, stage);
  }

  //继承家具基类
  FurnitureViewWall.prototype = new MyFA.FurnitureView();
  var p = FurnitureViewWall.prototype;
  //初始伸拉家具

  //添加家具到场景中来
  p.AddFurnitureToStage = function (furniture, stage) {
    var fc = this.AddFurnitureContainer(furniture, stage);
    var _this = this;
    var img = new Image();
    //解决图片的跨域问题
    img.crossOrigin = "Anonymous";
    img.src = furniture.imgSrc;
    img.onload = handleImageLoad;

    //图片的加载事件
    function handleImageLoad(event) {
      //提前保存家具图片矩阵，防止在移动过程中需要不断伸拉计算
      _this.mat = cv.imread(img);

      var photoSceneModel = furniture.parent;
      stage.addChild(fc);
      ////如果是第一次加入到设计，即以前未被保存过，则需要确定家具的初始放置位置
      if (!furniture.hasBeenSaved) {
        var arr = photoSceneModel.WallLineModel.arr;
        //正对矩形墙面的情况（8点8线）
        if (arr.length == 8) {
          // //水平墙上拉伸家具(函数里边的家具图片的四角坐标都无)
          furniture.StretchFurnitureInMiddleWall(
            //DisappearedPoint 场景灭点
            (arr[5].Px + arr[6].Px) / 2,
            photoSceneModel.DisappearedPoint.Py -
              furniture.scaleY * furniture.pixHeight * 0.5
          );
        } else {
          //如果放在左墙
          if (furniture.picAngle <= 0) {
            var locationX = (arr[3].Px + arr[4].Px) / 2;
            var locationY =
              (arr[1].Py + arr[4].Py) / 2 -
              furniture.scaleY * furniture.pixHeight;
            var equationUp = MyFA.CommonFunction.calLinearEquationByPoints(
              arr[0],
              arr[1]
            );
            var yOfLocationXInEquationUp =
              (equationUp.c * -1 - equationUp.a * locationX) / equationUp.b;
            if (locationY < yOfLocationXInEquationUp) {
              locationY = yOfLocationXInEquationUp;
            }
            furniture.StretchFurnitureInLeftWall(locationX, locationY);
          }
          //如果放在右墙
          else {
            var locationX = arr[4].Px + furniture.pixWidth * furniture.scaleX;
            var locationY =
              (arr[1].Py + arr[4].Py) / 2 -
              (furniture.scaleY * furniture.pixHeight) / 2;
            var equationUp = MyFA.CommonFunction.calLinearEquationByPoints(
              arr[1],
              arr[2]
            );
            var yOfLocationXInEquationUp =
              (equationUp.c * -1 - equationUp.a * locationX) / equationUp.b;
            if (locationY < yOfLocationXInEquationUp) {
              locationY = yOfLocationXInEquationUp;
            }
            furniture.StretchFurnitureInRightWall(locationX, locationY);
          }
        }
        fc.sy = MyFA.MainController.photoSceneView.zIndexWall;
        MyFA.MainController.photoSceneView.zIndexWall++;
      }
      //如果是从已有设计打开的，则将家具恢复到原来的位置即可
      else {
        //确定家具应该在哪堵墙上
        switch (furniture.location) {
          case 0:
            furniture.StretchFurnitureInLeftWall(
              furniture.leftUpPointX,
              furniture.leftUpPointY
            );
            break;
          case 1:
            furniture.StretchFurnitureInMiddleWall(
              furniture.leftUpPointX,
              furniture.leftUpPointY
            );
            break;
          case 2:
            furniture.StretchFurnitureInRightWall(
              furniture.rightUpPointX,
              furniture.rightUpPointY
            );
            break;
        }
        fc.sy = furniture.sy;
      }

      //确定container的坐标
      _this.UpdateFurPosition(
        fc,
        furniture.leftUpPointX * photoSceneModel.scale,
        furniture.leftUpPointY * photoSceneModel.scale
      );
      //对图片进行伸拉
      _this.PutStretchResult(fc);
    }
  };

  //鼠标松开事件
  p.PressupHandler = function (event) {
    //try {
    var fc = event.target.parent;
    var furnitureModel = fc.furnitureModel;
    var furnitureView = fc.furnitureView;
    //如果是单击家具松开事件
    if (
      Math.abs(event.stageX - furnitureView.sx1) < 3 &&
      Math.abs(event.stageY - furnitureView.sy1) < 3
    ) {
      MyFA.FurnitureView.isTriggerPressupHandle = true;
    } else {
      //如果处于选中的状态下，则计算水平移动的角度
      if (furnitureModel.isSelected) {
        //移动松开时记录container的stageY,将其放置家具Model中
        //（目的：在详情面板出现之前再次进行z轴排序，防止点击详情面板按钮时触发move事件，修改container的stageY,从而干扰家具的前后顺序）
        furnitureModel.sy = fc.sy;
        furnitureView.stretchFurniture(fc);
      }
    }
    fc.parent.update();
    //} catch (e) {
    //    alert(e);
    //}
  };

  //移动事件
  p.furnitureMove = function (event) {
    try {
      if (event.target.name != "detailButton") {
        var self = event.target.parent; //放置图片的Container
        var stage = self.parent;
        var furnitureModel = self.furnitureModel;
        var photoSceneModel = furnitureModel.parent;
        var furview = self.furnitureView;

        furnitureModel.leftUpPointX =
          furnitureModel.leftUpPointX +
          (event.stageX - furview.sx) / photoSceneModel.scale;
        furnitureModel.rightUpPointX =
          furnitureModel.rightUpPointX +
          (event.stageX - furview.sx) / photoSceneModel.scale;
        furnitureModel.leftDownPointX =
          furnitureModel.leftDownPointX +
          (event.stageX - furview.sx) / photoSceneModel.scale;
        furnitureModel.rightDownPointX =
          furnitureModel.rightDownPointX +
          (event.stageX - furview.sx) / photoSceneModel.scale;
        furnitureModel.leftUpPointY =
          furnitureModel.leftUpPointY +
          (event.stageY - furview.sy) / photoSceneModel.scale;
        furnitureModel.rightUpPointY =
          furnitureModel.rightUpPointY +
          (event.stageY - furview.sy) / photoSceneModel.scale;
        furnitureModel.leftDownPointY =
          furnitureModel.leftDownPointY +
          (event.stageY - furview.sy) / photoSceneModel.scale;
        furnitureModel.rightDownPointY =
          furnitureModel.rightDownPointY +
          (event.stageY - furview.sy) / photoSceneModel.scale;

        //如若需要伸拉家具，则伸拉家具
        furview.stretchFurniture(self);

        //区域限制
        furview.regionRestrict(self);

        //根据四角坐标进行伸拉
        furview.PutStretchResult(self);

        furview.sx = event.stageX;
        furview.sy = event.stageY;
      }
    } catch (e) {
      //var txt = document.getElementById("txtResult");
      //txt.textContent = "";
      //txt.textContent += ("\n异常：" + e + ";");
    }
  };

  //家具伸拉变形的具体操作
  p.PutStretchResult = function (fc) {
    //try {
    var _this = this;
    var furniture = fc.furnitureModel;
    var furnitureView = fc.furnitureView;
    var photoSceneModel = furniture.parent;
    var vertex = []; //目标图片的四个顶点
    //存在
    vertex[0] = { X: furniture.leftUpPointX, Y: furniture.leftUpPointY };
    vertex[1] = { X: furniture.rightUpPointX, Y: furniture.rightUpPointY };
    vertex[2] = { X: furniture.rightDownPointX, Y: furniture.rightDownPointY };
    vertex[3] = { X: furniture.leftDownPointX, Y: furniture.leftDownPointY };

    var xmin = vertex[0].X,
      ymin = vertex[0].Y;
    //为数

    for (var i = 0; i < 4; i++) {
      //因为目标图片被伸拉变形了，不再是矩形了，所以需要找出最小的外接矩形
      xmin = Math.min(xmin, vertex[i].X);
      ymin = Math.min(ymin, vertex[i].Y);
    }

    var upleft = new cvv.Vector(
      Math.floor((furniture.leftUpPointX - xmin) * photoSceneModel.scale),
      Math.floor((furniture.leftUpPointY - ymin) * photoSceneModel.scale)
    );

    var upright = new cvv.Vector(
      Math.floor((furniture.rightUpPointX - xmin) * photoSceneModel.scale),
      Math.floor((furniture.rightUpPointY - ymin) * photoSceneModel.scale)
    );
    var downright = new cvv.Vector(
      Math.floor((furniture.rightDownPointX - xmin) * photoSceneModel.scale),
      Math.floor((furniture.rightDownPointY - ymin) * photoSceneModel.scale)
    );
    var downleft = new cvv.Vector(
      Math.floor((furniture.leftDownPointX - xmin) * photoSceneModel.scale),
      Math.floor((furniture.leftDownPointY - ymin) * photoSceneModel.scale)
    );

    var mat = furnitureView.mat;
    ///没报错 和

    //根据计算出来的四点，对图片进行伸拉
    var mat1 = cv.getTransformedBitmap(
      mat,
      mat.col,
      mat.row,
      upleft,
      upright,
      downright,
      downleft
    );

    //将伸拉的结果先放到一个临时的canvas上
    var resultCanvas = document.createElement("canvas"),
      result = resultCanvas.getContext("2d");
    resultCanvas.width = mat1.col;
    resultCanvas.height = mat1.row;
    result.putImageData(cv.RGBA2ImageData(mat1), 0, 0);

    var image = new Image();
    //将canvas上的内容以图片形式保存
    image.src = resultCanvas.toDataURL("image/png");

    image.onload = function () {
      furnitureView.UpdateFurPosition(
        fc,
        xmin * photoSceneModel.scale,
        ymin * photoSceneModel.scale
      );

      //如果是初次放置时拉伸
      if (fc.getChildAt(0) == undefined) {
        var bitmap = new createjs.Bitmap();
        bitmap.image = image;
        //设置bitmap的比例
        furnitureView.UpdateFurScale(bitmap, 1, 1);
        //则先将bitmap加入Container中
        fc.addChild(bitmap);
        // window.ionicLoading.hide();
        fc.parent.sortChildren(furnitureView.sortFurnituresByZ);
      } else {
        var bitmap = fc.getChildAt(0);
        bitmap.image = image;
        if (bitmap.cacheID != 0) {
          bitmap.updateCache();
        }
        if (furniture.isSelected) {
          furnitureView.RedrawPanelButton(fc);
        }
      }
      fc.parent.update();
      _this.isStretchFinished = true;
    };
    //} catch (e) {
    //    alert(e);
    //}
  };

  //伸拉（壁挂）家具
  p.stretchFurniture = function (fc) {
    var furniture = fc.furnitureModel;
    var photoSceneModel = furniture.parent;
    var furnitureView = fc.furnitureView;
    var arr = photoSceneModel.WallLineModel.arr;
    //左边两点的中点
    var poLeft = {
      Px: (furniture.leftUpPointX + furniture.leftDownPointX) / 2,
      Py: (furniture.leftUpPointY + furniture.leftDownPointY) / 2,
    };
    //右边两点的中点
    var poRight = {
      Px: (furniture.rightUpPointX + furniture.rightDownPointX) / 2,
      Py: (furniture.rightUpPointY + furniture.rightDownPointY) / 2,
    };

    //正对墙角的情况下
    if (arr.length == 8) {
      //如果poLeft和poRight的中点已经在左边墙上
      if ((poLeft.Px + poRight.Px) * 0.5 <= (arr[1].Px + arr[5].Px) / 2) {
        //则在左墙上对家具进行伸拉
        furniture.StretchFurnitureInLeftWall(
          furniture.leftUpPointX,
          furniture.leftUpPointY
        );
        //furnitureView.PutStretchResult(fc);
      }

      //如果poLeft和poRight的中点已经在水平墙上
      if (
        (poLeft.Px + poRight.Px) * 0.5 >= (arr[1].Px + arr[5].Px) / 2 &&
        (poLeft.Px + poRight.Px) * 0.5 <= (arr[2].Px + arr[6].Px) / 2
      ) {
        //如果此时家具不是水平墙伸拉的状态
        //if (furniture.location != 1)
        {
          //则在水平墙上对家具进行伸拉
          furniture.StretchFurnitureInMiddleWall(
            furniture.leftUpPointX,
            furniture.leftUpPointY
          );
          //furnitureView.PutStretchResult(fc);
        }
      }
      //如果poLeft和poRight的中点已经在右边墙上
      if ((poLeft.Px + poRight.Px) * 0.5 >= (arr[2].Px + arr[6].Px) / 2) {
        //则在右墙上对家具进行伸拉
        furniture.StretchFurnitureInRightWall(
          furniture.rightUpPointX,
          furniture.rightUpPointY
        );
        //furnitureView.PutStretchResult(fc);
      }
    } else {
      //如果poLeft和poRight的中点在左边墙上
      if ((poLeft.Px + poRight.Px) * 0.5 <= (arr[1].Px + arr[4].Px) / 2) {
        //则在左墙上对家具进行伸拉
        furniture.StretchFurnitureInLeftWall(
          furniture.leftUpPointX,
          furniture.leftUpPointY
        );
      }
      //如果poLeft和poRight都在的中点在右边墙上
      if ((poLeft.Px + poRight.Px) * 0.5 >= (arr[1].Px + arr[4].Px) / 2) {
        //则在右墙上对家具进行伸拉
        furniture.StretchFurnitureInRightWall(
          furniture.rightUpPointX,
          furniture.rightUpPointY
        );
      }
    }
  };

  //壁挂商品区域限制时，根据上下两条墙线来限制和推算商品的四个点坐标
  //upLinePt1, upLinePt2 上墙线的两个点
  //downLinePt1, downLinePt2 下墙线的两个点
  p.locationFurnitureBaseLines = function (
    furniture,
    upLinePt1,
    upLinePt2,
    downLinePt1,
    downLinePt2
  ) {
    var equationUp = MyFA.CommonFunction.calLinearEquationByPoints(
      upLinePt1,
      upLinePt2
    );

    if (equationUp.b == 0) {
      return;
    }

    //解出家具移动时在右墙上的临界X值
    var luYInEquationUp =
      (equationUp.c * -1 - equationUp.a * furniture.leftUpPointX) /
      equationUp.b;
    var ruYInEquationUp =
      (equationUp.c * -1 - equationUp.a * furniture.rightUpPointX) /
      equationUp.b;

    if (furniture.leftUpPointY < luYInEquationUp) {
      //用左上角Y推断其他3个Y
      var luY = furniture.leftUpPointY;
      furniture.leftUpPointY = luYInEquationUp;
      furniture.rightUpPointY =
        furniture.rightUpPointY - luY + furniture.leftUpPointY;
      furniture.rightDownPointY =
        furniture.rightDownPointY - luY + furniture.leftUpPointY;
      furniture.leftDownPointY =
        furniture.leftDownPointY - luY + furniture.leftUpPointY;

      this.pubDrawAlertLine(upLinePt1, upLinePt2);
    }

    if (furniture.rightUpPointY < ruYInEquationUp) {
      //用左上角Y推断其他3个Y
      var ruY = furniture.rightUpPointY;
      furniture.rightUpPointY = ruYInEquationUp;
      furniture.leftUpPointY =
        furniture.leftUpPointY - ruY + furniture.rightUpPointY;
      furniture.rightDownPointY =
        furniture.rightDownPointY - ruY + furniture.rightUpPointY;
      furniture.leftDownPointY =
        furniture.leftDownPointY - ruY + furniture.rightUpPointY;
      this.pubDrawAlertLine(upLinePt1, upLinePt2);
    }

    var equationDown = MyFA.CommonFunction.calLinearEquationByPoints(
      downLinePt1,
      downLinePt2
    );

    if (equationDown.b == 0) {
      return;
    }

    //解出家具移动时在右墙上的临界X值
    var luYInEquationDown =
      (equationDown.c * -1 - equationDown.a * furniture.leftDownPointX) /
      equationDown.b;
    var ruYInEquationDown =
      (equationDown.c * -1 - equationDown.a * furniture.rightDownPointX) /
      equationDown.b;

    if (furniture.leftDownPointY > luYInEquationDown) {
      var luY = furniture.leftDownPointY;
      furniture.leftDownPointY = luYInEquationDown;
      furniture.rightDownPointY =
        furniture.rightDownPointY - luY + furniture.leftDownPointY;
      furniture.leftUpPointY =
        furniture.leftUpPointY - luY + furniture.leftDownPointY;
      furniture.rightUpPointY =
        furniture.rightUpPointY - luY + furniture.leftDownPointY;
      this.pubDrawAlertLine(downLinePt1, downLinePt2);
    }

    if (furniture.rightDownPointY > ruYInEquationDown) {
      var ruY = furniture.rightDownPointY;
      furniture.rightDownPointY = ruYInEquationDown;
      furniture.leftDownPointY =
        furniture.leftDownPointY - ruY + furniture.rightDownPointY;
      furniture.leftUpPointY =
        furniture.leftUpPointY - ruY + furniture.rightDownPointY;
      furniture.rightUpPointY =
        furniture.rightUpPointY - ruY + furniture.rightDownPointY;
      this.pubDrawAlertLine(downLinePt1, downLinePt2);
    }
  };

  //移动过程中将家具限制在画布内（只针对壁挂商品）
  p.regionRestrict = function (fc) {
    var furniture = fc.furnitureModel;
    var photoSceneModel = furniture.parent;
    var furnitureView = fc.furnitureView;
    furnitureView.restrictFurInCanvas(fc);

    var arr = photoSceneModel.WallLineModel.arr;
    var dpOfLeftWall, dpOfRightWall;
    //左边两点的中点
    var poLeft = {
      Px: (furniture.leftUpPointX + furniture.leftDownPointX) / 2,
      Py: (furniture.leftUpPointY + furniture.leftDownPointY) / 2,
    };
    //右边两点的中点
    var poRight = {
      Px: (furniture.rightUpPointX + furniture.rightDownPointX) / 2,
      Py: (furniture.rightUpPointY + furniture.rightDownPointY) / 2,
    };

    if (arr.length == 8) {
      //左墙灭点
      dpOfLeftWall = MyFA.CommonFunction.segmentsIntr(
        arr[2],
        arr[3],
        arr[6],
        arr[7]
      );
      //右边墙灭点
      dpOfRightWall = MyFA.CommonFunction.segmentsIntr(
        arr[0],
        arr[1],
        arr[4],
        arr[5]
      );
    } else {
      //左墙灭点
      dpOfLeftWall = MyFA.CommonFunction.segmentsIntr(
        arr[1],
        arr[2],
        arr[4],
        arr[5]
      );
      //右边墙灭点
      dpOfRightWall = MyFA.CommonFunction.segmentsIntr(
        arr[0],
        arr[1],
        arr[3],
        arr[4]
      );
    }
    //正对墙面模型下
    if (arr.length == 8) {
      //如果在左墙
      if ((poLeft.Px + poRight.Px) * 0.5 < (arr[1].Px + arr[5].Px) / 2) {
        furnitureView.locationFurnitureBaseLines(
          furniture,
          arr[0],
          arr[1],
          arr[4],
          arr[5]
        );
      }
      //如果在右墙
      else if ((poLeft.Px + poRight.Px) * 0.5 > (arr[2].Px + arr[6].Px) / 2) {
        furnitureView.locationFurnitureBaseLines(
          furniture,
          arr[2],
          arr[3],
          arr[6],
          arr[7]
        );
      }
      //如果在水平墙
      else {
        furnitureView.locationFurnitureBaseLines(
          furniture,
          arr[1],
          arr[2],
          arr[5],
          arr[6]
        );
      }
    }
    //正对墙角模型下
    else {
      //如果在左墙
      if ((poLeft.Px + poRight.Px) * 0.5 < (arr[1].Px + arr[4].Px) / 2) {
        furnitureView.locationFurnitureBaseLines(
          furniture,
          arr[0],
          arr[1],
          arr[3],
          arr[4]
        );
      }
      //如果在右墙
      else {
        furnitureView.locationFurnitureBaseLines(
          furniture,
          arr[1],
          arr[2],
          arr[4],
          arr[5]
        );
      }
    }
  };

  MyFA.FurnitureViewWall = FurnitureViewWall;
})();
