this.cvv = this.cvv || {};
(function () {
    "user strict"
    function PointF(x, y) {
        this.X, this.Y;
        this.X = x; this.Y = y;
    }
    cvv.PointF = PointF;

    //��������
    function mypix(x, y) {
        this.X = x, this.Y = y;
    }
    cvv.mypix = mypix;

    function Vector(x, y) {
        this.X, this.Y;
        if (arguments.length == 1) {
            this.X = x.X; this.Y = y.Y;
        }
        if (arguments.length == 2) {
            if (typeof (arguments[0]) == "number") {
                this.X = x; this.Y = y;
            }
            if (typeof (arguments[0]) == "PointF" || typeof (arguments[0]) == "Vector" || typeof (arguments[0]) == "object") {
                this.X = y.X - x.X;
                this.Y = y.Y - x.Y;
            }
        }
    }
    var p = Vector.prototype;

    //�����ĸ���*
    p.Magnitude = function () {
        return Math.sqrt(this.X * this.X + this.Y * this.Y);
    }

    //��������֮��
    //Vector v1
    //Vector v2
    p.add = function (v1, v2) {
        return new Vector(v1.X + v2.X, v1.Y + v2.Y);
    }

    //��������֮��
    //Vector v1
    //Vector v2
    p.minus = function (v1, v2) {
        return new Vector(v1.X - v2.X, v1.Y - v2.Y);
    }

    //����ȡ��
    p.negative = function () {
        this.X=-this.X, this.Y=-this.Y;
    }

    //����������
    //Nunber c
    p.multiple = function (c) {
        this.X *= c, this.Y *= c;
    }

    //��������������*
    //Number c����������
    p.division = function (c) {
        this.X /= c, this.Y /= c;
    }

    //�������*
    // A * B =|A|.|B|.sin(angle AOB)
    //Vector v
    p.CrossProduct = function (v) {
        return this.X * v.Y - v.X * this.Y;
    }

    //�������
    // A. B=|A|.|B|.cos(angle AOB)
    //Vector v
    p.DotProduct = function (v) {
        return this.X * v.X + this.Y * v.Y;
    }

    //PointF pt1, PointF pt2, PointF pt3
    //��������bool
    p.IsClockwise = function (pt1, pt2, pt3) {
        V21 = new Vector(pt2, pt1);
        v23 = new Vector(pt2, pt3);
        return V21.CrossProduct(v23) < 0; // sin(angle pt1 pt2 pt3) > 0, 0<angle pt1 pt2 pt3 <180
    }

    // pt1�Ƿ���pt2->pt3�������ұ�*
    //PointF pt1, PointF pt2, PointF pt3
    //��������bool
    Vector.IsCCW = function (pt1, pt2, pt3) {
        V21 = new Vector(pt2, pt1);
        v23 = new Vector(pt2, pt3);
        return V21.CrossProduct(v23) >0;  // sin(angle pt2 pt1 pt3) < 0, 180<angle pt2 pt1 pt3 <360
    }

    //PointF pt, PointF lnA, PointF lnB        
    //��������double
    p.DistancePointLine = function (pt, lnA, lnB) {
        v1 = new Vector(lnA, lnB);
        v2 = new Vector(lnA, pt);
        v1.division(v1.Magnitude());
        return Math.abs(v2.CrossProduct(v1));
    }

    //Degree����ת�Ķ�������λ�Ƕȡ�
    //�޷���
    p.Rotate = function (Degree) {
        var radian = Degree * Math.PI / 180.0;
        var sin = Math.sin(radian);
        var cos = Math.cos(radian);
        var nx = this.X * cos - this.Y * sin;
        var ny = this.X * sin + this.Y * cos;
        this.X = nx;
        this.Y = ny;
    }

    cvv.Vector = Vector;
})();
