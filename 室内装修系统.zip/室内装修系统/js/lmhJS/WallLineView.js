this.MyFurnitureAssistant = this.MyFurnitureAssistant || {};
// 定义别名(快捷名)：
if (typeof this.MyFA === 'undefined') {
    this.MyFA = this.MyFurnitureAssistant;
}
//墙体线View
(function () {
    var arr = [], mx1, mx2, my1, my2; //mx1,my1,mx2,my2分别为边上按下是距以x轴方向的左边点和右边点的[x向量距离和y向量距离]

    function WallLineView(stage, wallLineModel, scale, isEnableMove) { //scale:场景缩放比例  

        //ar:未缩放的识别结果数组（处理后）
        this.stage = stage;
        //缩放比例
        _scale = scale;
        _wallLineModel = wallLineModel;
        //是否允许线条和点移动
        _isEnableMove = isEnableMove;
        var lineContainer = stage.getChildByName("line");
        if (typeof (lineContainer) != "undefined") {
            stage.removeChild(lineContainer);
        }
        lineContainer = new createjs.Container();
        lineContainer.name = "line";
        this.container = lineContainer;
        this.stage.addChild(lineContainer);
        var ar = wallLineModel.arr;
        arr = MyFA.CommonFunction.clone(ar);
       
        //alert(_scale);
        for (var i = 0; i < arr.length; i++) {
            arr[i].Px = arr[i].Px * _scale;
            arr[i].Py = arr[i].Py * _scale;
        }
        this.InitView();
    }

    var p = WallLineView.prototype;
    p.InitView = function () {
        for (var i = 0; i < arr.length; i++) {
            var con = new createjs.Container();
            con.name = i;
            con.x = con.y = 0;
            this.container.addChild(con);
        }
        lstage = this.stage;
        lcontainer = this.container;
        this.locationLine(arr);
        //描点线
        if (_isEnableMove) {
            for (var i = 0; i < arr.length; i++) {
                this.container.getChildByName(i).getChildAt(1).addEventListener('mousedown', p.mouseDown, false);

            }
            var tR = (arr.length == 6) ? [2] : (_wallLineModel.wallType == 2 ? [1, 6] : [1, 3, 4, 6]);
            for (var i = 0; i < tR.length; i++) {
                this.container.getChildByName(tR[i]).getChildAt(0).addEventListener('mousedown', p.mouseDown, false);

            }
        }
        lstage.update();
        //正对墙面情况下，调整0,1,5,4点的索引，目的：解决左边点移动不方便的问题
        if (arr.length == 8) {
            for (var i = 0; i < arr.length; i++) {
                var con = this.container.getChildByName(i);
                if (i == 0 || i == 4) {
                    this.container.setChildIndex(con, i + 1);
                }
                else if (i == 1 || i == 5) {
                    this.container.setChildIndex(con, i - 1);
                }
                else {
                    this.container.setChildIndex(con, i);
                }
            }
            lstage.update();
        }

    }

    p.mouseDown = function (event) {
        var self = event.target;
        if (lcontainer.getChildByName(self.parent.name).getChildIndex(self) == 0)        //记录关键线段
        {
            var index = self.parent.name;
            my1 = (index == 1 || index == 6) ? ((index == 1) ? event.stageY - 0 - arr[1].Py : event.stageY - 0 - arr[5].Py) : 0;
            my2 = (index == 1 || index == 6) ? ((index == 1) ? arr[2].Py - (event.stageY - 0) : arr[6].Py - (event.stageY - 0)) : 0;
            mx1 = (index == 2 || index == 3 || index == 4) ? ((index == 4) ? event.stageX - 0 - arr[2].Px : event.stageX - 0 - arr[1].Px) : 0;
            mx2 = (index == 2 || index == 3 || index == 4) ? ((index == 2) ? arr[4].Px - (event.stageX - 0) : ((index == 3) ? arr[5].Px - (event.stageX - 0) : arr[6].Px - (event.stageX - 0))) : 0;

        }
        self.addEventListener('pressmove', p.MoveLine, false);
    }
    p.MoveLine = function (event) {

        //event.preventDefault();
        var con = event.target.parent;
        //判断是线条还是点
        if (lcontainer.getChildByName(con.name).getChildIndex(event.target))  // 边为1,点为0
            p.updatePoint(con.name, event);
        else
            p.updateLine(con.name, event);
        p.clearShape(lcontainer);
        p.locationLine(arr);
        lstage.update();

    }
    //移动某个点
    p.updatePoint = function (id, e) {

        //如果是只有一面墙，则只允许墙点延y轴移动
        if (_wallLineModel.wallType == 2) {
         
            arr[id] = { Px: arr[id].Px, Py: e.stageY };
        }
        else {
            arr[id] = { Px: e.stageX, Py: e.stageY };
        }
   
        //if (e.stageX > lstage.canvas.width) {
        //    arr[id].Px = lstage.canvas.width;
        //}
        //else if (e.stageX < 0) {
        //    arr[id].Px = 0;
        //}
        //if (e.stageY > lstage.canvas.height) {
        //    arr[id].Py = lstage.canvas.height;
        //}
        //else if (e.stageY < 0) {
        //    arr[id].Py = 0;
        //}

        var a = MyFA.CommonFunction.clone(arr);
        for (var i = 0; i < a.length; i++) {
            a[i].Px = a[i].Px / _scale;
            a[i].Py = a[i].Py / _scale;
        }
        _wallLineModel.arr = a;
        //重新确定标尺的位置   改变MyFA.WallLineModel.walls
        if (arr.length == 8) {
            //确定是否为标尺所标线的两端
            if (id == 1 || id == 5) {
                var c = _wallLineModel.walls;
                c[0] = a[1].Px;
                c[1] = a[1].Py;
                c[2] = a[5].Px;
                c[3] = a[5].Py;
            }
        }
        else {
            //确定是否为标尺所标线的两端
            if (id == 1 || id == 4) {
                var c = _wallLineModel.walls;
                c[0] = a[1].Px;
                c[1] = a[1].Py;
                c[2] = a[4].Px;
                c[3] = a[4].Py;
            }
        }
    }
    //移动某条线
    p.updateLine = function (id, e) {
        if (id == 2 || id == 3 || id == 4)                //如果是竖线，只能左右移动
            (id == 2) ? (arr[1].Px = e.stageX - 0 - mx1, arr[4].Px = e.stageX - 0 + mx2) : (arr[id - 2].Px = e.stageX - 0 - mx1, arr[id + 2].Px = e.stageX - 0 + mx2);
        else 
            (id == 1) ? (arr[1].Py = e.stageY - 0 - my1, arr[2].Py = e.stageY - 0 + my2) : (arr[5].Py = e.stageY - 0 - my1, arr[6].Py = e.stageY - 0 + my2);
        //移动时确保点线不能超过照片边沿
        if (id == 2) {
            if (arr[1].Px > lstage.canvas.width) {
                arr[1].Px = lstage.canvas.width;
            }
            if (arr[1].Px < 0) {
                arr[1].Px = 0;
            }
            if (arr[4].Px > lstage.canvas.width) {
                arr[4].Px = lstage.canvas.width;
            }
            if (arr[4].Px < 0) {
                arr[4].Px = 0;
            }
        }
        if (id == 3) {
            if (arr[1].Px > lstage.canvas.width) {
                arr[1].Px = lstage.canvas.width;
            }
            if (arr[1].Px < 0) {
                arr[1].Px = 0;
            }
            if (arr[5].Px > lstage.canvas.width) {
                arr[5].Px = lstage.canvas.width;
            }
            if (arr[5].Px < 0) {
                arr[5].Px = 0;
            }
        }
        if (id == 4) {
            if (arr[2].Px > lstage.canvas.width) {
                arr[2].Px = lstage.canvas.width;
            }
            if (arr[2].Px < 0) {
                arr[2].Px = 0;
            }
            if (arr[6].Px > lstage.canvas.width) {
                arr[6].Px = lstage.canvas.width;
            }
            if (arr[6].Px < 0) {
                arr[6].Px = 0;
            }
        }

        if (id == 1) {
            if (arr[1].Py > lstage.canvas.height) {
                arr[1].Py = lstage.canvas.height;
            }
            if (arr[1].Py < 0) {
                arr[1].Py = 0;
            }
            if (arr[2].Py > lstage.canvas.height) {
                arr[2].Py = lstage.canvas.height;
            }
            if (arr[2].Py < 0) {
                arr[2].Py = 0;
            }

        }
        if (id == 6) {
            if (arr[5].Py > lstage.canvas.height) {
                arr[5].Py = lstage.canvas.height;
            }
            if (arr[5].Py < 0) {
                arr[5].Py = 0;
            }
            if (arr[6].Py > lstage.canvas.height) {
                arr[6].Py = lstage.canvas.height;
            }
            if (arr[6].Py < 0) {
                arr[6].Py = 0;
            }
        }

        var a = MyFA.CommonFunction.clone(arr);
        for (var i = 0; i < a.length; i++) {
            a[i].Px = a[i].Px / _scale;
            a[i].Py = a[i].Py / _scale;
        }
        _wallLineModel.arr = a;
        var c = _wallLineModel.walls;
        //重新确定标尺的位置   改变MyFA.WallLineModel.walls
        if (arr.length == 8) {
            //如果是标尺所标线移动（水平移动）
            if (id == 3) {
                //分别改变上下点的x坐标
                if (c[1] <= c[3]) {
                    c[0] = a[1].Px;
                    c[2] = a[5].Px;
                }
                else {
                    c[0] = a[5].Px;
                    c[2] = a[1].Px;
                }
            }
            //如果为上水平线移动
            if (id == 1) {
                //改变墙线上方点的y坐标
                if (c[1] <= c[3]) {
                    c[1] = a[1].Py;
                }
                else {
                    c[3] = a[1].Py;
                }
            }
            //如果为下水平线移动
            if (id == 6) {
                //改变墙线下方点的y坐标
                if (c[1] <= c[3]) {
                    c[3] = a[5].Py;
                }
                else {
                    c[1] = a[5].Py;
                }
            }
        }
        else {
            //确定是否为标尺所标线
            if (id == 2) {
                //var c = _wallLineModel.walls.walls;
                if (c[1] <= c[3]) {
                    c[0] = a[1].Px;
                    c[2] = a[4].Px;
                }
                else {
                    c[2] = a[1].Px;
                    c[4] = a[4].Px;
                }
            }
        }
    }
    //描点画线
    p.locationLine = function (arr) {
        var shape;
        if (arr.length == 6) {
            for (var i = 0; i < arr.length; i++) {
                shape = (lcontainer.getChildByName(i).children[0] == null || lcontainer.getChildByName(i).children[0] == undefined) ? new createjs.Shape() : lcontainer.getChildByName(i).children[0];
                if (_isEnableMove) {
                    shape.graphics.setStrokeStyle(Math.floor(5)).beginStroke("rgba(0,255,0,.5)");
                }
                else {
                    shape.graphics.setStrokeStyle(Math.floor(3)).beginStroke("rgba(0,255,0,.5)");
                }
                if (i == 2) {
                    //可以的移动的线条上添加一层宽的线，以便扩大线条的感应范围，从而使移动功能更灵敏
                    if (_isEnableMove) {
                        shape.graphics.setStrokeStyle(Math.floor(50)).beginStroke("rgba(255,255,255,0.01)");
                        shape.graphics.moveTo(arr[1].Px, arr[1].Py + 30);
                        shape.graphics.lineTo(arr[4].Px, arr[4].Py - 30);
                        shape.graphics.setStrokeStyle(Math.floor(5)).beginStroke("rgba(0,255,0,.5)");
                    }
                    shape.graphics.moveTo(arr[1].Px, arr[1].Py);
                    shape.graphics.lineTo(arr[4].Px, arr[4].Py);
                }
                else if (arr.length == i + 1) {
                    shape.graphics.moveTo(arr[i].Px, arr[i].Py);
                }
                else {
                    shape.graphics.moveTo(arr[i].Px, arr[i].Py);
                    shape.graphics.lineTo(arr[i + 1].Px, arr[i + 1].Py);
                }
                shape.graphics.endStroke();
                if (!lcontainer.getChildByName(i).children[0])
                    lcontainer.getChildByName(i).addChild(shape);
            }
        }
        else {
            for (var i = 0; i < arr.length; i++) {
                shape = (lcontainer.getChildByName(i).children[0] == null || lcontainer.getChildByName(i).children[0] == undefined) ? new createjs.Shape() : lcontainer.getChildByName(i).children[0];
                if (_isEnableMove) {
                    shape.graphics.setStrokeStyle(Math.floor(5)).beginStroke("rgba(0,255,0,.5)");
                }
                else {
                    shape.graphics.setStrokeStyle(Math.floor(3)).beginStroke("rgba(0,255,0,.5)");
                }
                if (i == 3 || i == 4) {
                    //可以的移动的线条上添加一层宽的线，以便扩大线条的感应范围，从而使移动功能更灵敏
                    if (_isEnableMove) {
                        shape.graphics.setStrokeStyle(Math.floor(50)).beginStroke("rgba(255,255,255,0.01)");
                        shape.graphics.moveTo(arr[i - 2].Px, arr[i - 2].Py + 30);
                        shape.graphics.lineTo(arr[i + 2].Px, arr[i + 2].Py - 30);
                        shape.graphics.setStrokeStyle(Math.floor(5)).beginStroke("rgba(0,255,0,.5)");
                    }

                    shape.graphics.moveTo(arr[i - 2].Px, arr[i - 2].Py);
                    shape.graphics.lineTo(arr[i + 2].Px, arr[i + 2].Py);
                }
                else if (i == 5 || i == 6 || i == 7) {
                    //可以的移动的线条上添加一层宽的线，以便扩大线条的感应范围，从而使移动功能更灵敏
                    if (i == 6 && _isEnableMove) {
                        shape.graphics.setStrokeStyle(Math.floor(50)).beginStroke("rgba(255,255,255,0.01)");
                        shape.graphics.moveTo(arr[i].Px - 30, arr[i].Py);
                        shape.graphics.lineTo(arr[i - 1].Px + 30, arr[i - 1].Py);
                        shape.graphics.setStrokeStyle(Math.floor(5)).beginStroke("rgba(0,255,0,.5)");
                    }

                    shape.graphics.moveTo(arr[i].Px, arr[i].Py);
                    shape.graphics.lineTo(arr[i - 1].Px, arr[i - 1].Py);
                }
                else if (i == arr.length - 1) {
                    shape.graphics.moveTo(arr[i].Px, arr[i].Py);
                }
                else {
                    //可以的移动的线条上添加一层宽的线，以便扩大线条的感应范围，从而使移动功能更灵敏
                    if (i == 1 && _isEnableMove) {
                        shape.graphics.setStrokeStyle(Math.floor(50)).beginStroke("rgba(255,255,255,0.01)");
                        shape.graphics.moveTo(arr[i].Px + 30, arr[i].Py);
                        shape.graphics.lineTo(arr[i + 1].Px - 30, arr[i + 1].Py);
                        shape.graphics.setStrokeStyle(Math.floor(5)).beginStroke("rgba(0,255,0,.5)");
                    }
                    shape.graphics.moveTo(arr[i].Px, arr[i].Py);
                    shape.graphics.lineTo(arr[i + 1].Px, arr[i + 1].Py);
                }
                shape.graphics.endStroke();
                if (!lcontainer.getChildByName(i).children[0])
                    lcontainer.getChildByName(i).addChild(shape);
            }
        }
        if (_isEnableMove) {
            p.setPoint(arr);
        }
    }
    p.clearShape = function (container) {
        for (var i = 0; i < container.numChildren; i++) {
            container.getChildAt(i).getChildAt(0).graphics.clear();
            container.getChildAt(i).getChildAt(1).graphics.clear();
        }
    }
    //描点
    p.setPoint = function (arr) {
        var shape;
        for (var i in arr) {
            shape = (lcontainer.getChildByName(i).children[1] == null || lcontainer.getChildByName(i).children[1] == undefined) ? new createjs.Shape() : lcontainer.getChildByName(i).children[1];

            shape.graphics.beginFill("yellow");
            shape.graphics.drawCircle(arr[i].Px, arr[i].Py, Math.floor(5));

            //扩大点的感应范围
            shape.graphics.beginFill("rgba(255,255,255,0.01)");
            shape.graphics.drawCircle(arr[i].Px, arr[i].Py, Math.floor(30));

            shape.graphics.endStroke();
            if (!lcontainer.getChildByName(i).children[1])
                lcontainer.getChildByName(i).addChild(shape);
        }
    }

    //去除点和线上的移动功能（第三步）
    p.clearPressmove = function (container) {
        for (var i in container.children) {
            if (container.getChildAt(i).getChildAt(1) != null && container.getChildAt(i).getChildAt(1).hasEventListener('mousedown')) {
                container.getChildAt(i).getChildAt(1).removeEventListener('mousedown', p.mouseDown, false);
            }
            if (container.getChildAt(i).getChildAt(1) != null && container.getChildAt(i).getChildAt(1).hasEventListener('pressmove')) {
                container.getChildAt(i).getChildAt(1).removeEventListener('pressmove', p.MoveLine, false);
            }
        }
        var tR = (arr.length == 6) ? [2] : [1, 3, 4, 6];
        for (var i = 0; i < tR.length; i++) {
            if (container.getChildByName(tR[i]).getChildAt(0).hasEventListener('mousedown')) {
                container.getChildByName(tR[i]).getChildAt(0).removeEventListener('mousedown', p.mouseDown, false);
            }
            if (container.getChildByName(tR[i]).getChildAt(0).hasEventListener('pressmove')) {
                container.getChildByName(tR[i]).getChildAt(0).removeEventListener('pressmove', p.MoveLine, false);
            }
        }
    }
    MyFA.WallLineView = WallLineView;
})();