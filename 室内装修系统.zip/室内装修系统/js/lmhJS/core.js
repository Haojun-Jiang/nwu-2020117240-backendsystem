﻿/*!
 * JsCV JavaScript Library
 *
 * Core Module v0.2
 *
 * Copyright 2012 WhiteSnow
 * Released under the MIT license
 *
 */
//	Supported Chrome 10+ , IE 10+ , Firefox 4+ , Maxthon 3.4.5+ , Opera 11.64+ , Safari 5.1+
/***********************************************
 *	<h2>CV_DATATYPE</h2>
 *	It just can be CV_8I, CV_8U, CV_RGBA, CV_GRAY, CV_16I, CV_16U, CV_32I, CV_32U, CV_32F or CV_64F.
 */
function CV_8I(__row, __col, __channel, __buffer) {
  this.buffer = __buffer || new ArrayBuffer(__row * __col * __channel);
  this.bytes = 1;
  this.data = new Int8Array(this.buffer);
  this.type = "CV_8I";
}
function CV_8U(__row, __col, __channel, __buffer) {
  this.buffer = __buffer || new ArrayBuffer(__row * __col * __channel);
  this.bytes = 1;
  this.data = new Uint8Array(this.buffer);
  this.type = "CV_8U";
}
function CV_RGBA(__row, __col, __data, __buffer) {
  this.channel = 4;
  this.buffer = __buffer || new ArrayBuffer(__row * __col * 4);
  this.bytes = 1;
  this.data = new Uint8ClampedArray(this.buffer);
  __data && this.data.set(__data);
  this.type = "CV_RGBA";
}
function CV_GRAY(__row, __col, __data, __buffer) {
  this.channel = 1;
  this.buffer = __buffer || new ArrayBuffer(__row * __col);
  this.bytes = 1;
  this.data = new Uint8ClampedArray(this.buffer);
  __data && this.data.set(__data);
  this.type = "CV_GRAY";
}
function CV_16I(__row, __col, __channel, __buffer) {
  this.buffer = __buffer || new ArrayBuffer(__row * __col * __channel * 2);
  this.bytes = 2;
  this.data = new Int16Array(this.buffer);
  this.type = "CV_16I";
}
function CV_16U(__row, __col, __channel, __buffer) {
  this.buffer = __buffer || new ArrayBuffer(__row * __col * __channel * 2);
  this.bytes = 2;
  this.data = new Uint16Array(this.buffer);
  this.type = "CV_16U";
}
function CV_32I(__row, __col, __channel, __buffer) {
  this.buffer = __buffer || new ArrayBuffer(__row * __col * __channel * 4);
  this.bytes = 4;
  this.data = new Int32Array(this.buffer);
  this.type = "CV_32I";
}
function CV_32U(__row, __col, __channel, __buffer) {
  this.buffer = __buffer || new ArrayBuffer(__row * __col * __channel * 4);
  this.bytes = 4;
  this.data = new Uint32Array(this.buffer);
  this.type = "CV_32U";
}
function CV_32F(__row, __col, __channel, __buffer) {
  this.buffer = __buffer || new ArrayBuffer(__row * __col * __channel * 4);
  this.bytes = 4;
  this.data = new Float32Array(this.buffer);
  this.type = "CV_32F";
}
function CV_64F(__row, __col, __channel, __buffer) {
  this.buffer = __buffer || new ArrayBuffer(__row * __col * __channel * 8);
  this.bytes = 8;
  this.data = new Float64Array(this.buffer);
  this.type = "CV_64F";
}

/***********************************************
 *	<h2>CV_CvtCode</h2>
 *	It just can be CV_RGB2GRAY.
 */
var CV_RGBA2GRAY = 0x01,
  CV_GRAY2RGBA = 0x02,
  CV_RGBA2GRAY_DUFF = 0x03;

/***********************************************
 *	<h2>CV_BORDER_TYPE</h2>
 *	It just can be CV_BORDER_REPLICATE, CV_BORDER_REFLECT, CV_BORDER_REFLECT_101, CV_BORDER_WRAP, CV_BORDER_CONSTANT.
 */
var CV_BORDER_REPLICATE = 0x01,
  CV_BORDER_REFLECT = 0x02,
  CV_BORDER_REFLECT_101 = 0x03,
  CV_BORDER_WRAP = 0x04,
  CV_BORDER_CONSTANT = 0x05;

/***********************************************
 *	<h2>CV_THRESH_TYPE</h2>
 *	It just can be CV_THRESH_BINARY, CV_THRESH_BINARY_INV, CV_THRESH_TRUNC, CV_THRESH_TOZERO, CV_THRESH_TOZERO_INV.
 */
var CV_THRESH_BINARY = function (__value, __thresh, __maxVal) {
    return __value > __thresh ? __maxVal : 0;
  },
  CV_THRESH_BINARY_INV = function (__value, __thresh, __maxVal) {
    return __value > __thresh ? 0 : __maxVal;
  },
  CV_THRESH_TRUNC = function (__value, __thresh, __maxVal) {
    return __value > __thresh ? __thresh : 0;
  },
  CV_THRESH_TOZERO = function (__value, __thresh, __maxVal) {
    return __value > __thresh ? __value : 0;
  },
  CV_THRESH_TOZERO_INV = function (__value, __thresh, __maxVal) {
    return __value > __thresh ? 0 : __value;
  };

(function (__host) {
  /***********************************************
   *	<h2>Common Tool</h2>
   */
  var host = __host,
    cv = {};

  var iCanvas = document.createElement("canvas"),
    iCtx = iCanvas.getContext("2d");

  function iResize(__width, __height) {
    iCanvas.width = __width;
    iCanvas.height = __height;
  }

  var JsCV_MODULE = "CORE",
    JsCV_MODULE_VERSION = "0.2";
  /***********************************************
   *	<h2>JsCV LOG System</h2>
   */
  var JsCV_ERROR_ON = __host.console && true,
    JsCV_LOG_ON = __host.console && true;

  var UNSPPORT_DATA_TYPE = "Unknown/unsupported data type.",
    UNSPPORT_BORDER_TYPE = "Unknown/unsupported border type.",
    UNSPPORT_SIZE = "The kernel size must be odd nor larger than 7.",
    IS_UNDEFINED_OR_NULL = "This value shouldn't be undefined, Null or 0",
    MAT_SIZE_ERROR = "Mat's size is not equal to data size.";

  function JsCV_ERROR(__callee, __msg, __line) {
    this.funciton = __callee.toString();
    this.line = __line;
    this.module_verision = JsCV_MODULE_VERSION;
    this.module = JsCV_MODULE;
    this.error = "[JsCV_ERROR] " + __msg;
  }

  function log(__msg) {
    JsCV_LOG_ON && console.log("[JsCV_LOG] " + __msg);
  }
  cv.log = log;

  function error(__callee, __msg, __line) {
    JsCV_ERROR_ON && console.dir(new JsCV_ERROR(__callee, __msg, __line));
  }
  cv.error = error;

  /***********************************************
   *	<h2>extend</h2>
   *	Extend the cv object.
   *	<b>Method</b>
   *	Object extend(Object options)
   *	<b>Parameters</b>
   *	options –
   */
  var extend = function (__options) {
    __options || error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    var target = this,
      name = null;

    for (name in __options) {
      if (!target[name]) {
        target[name] = __options[name];
      } else {
        log("cv." + name + " is already existed!");
      }
    }

    return target;
  };
  cv.extend = extend;

  /***********************************************
   *	<h2>Mat</h2>
   *	<b>Constructors</b>
   *	Mat()
   *	Mat(int row, int col, Function type, int channel)
   *	Mat(int row, int col, CV_RGBA, TypedArray data)
   *	Mat(int row, int col, Function type, int channel, ArrayBuffer buffer)
   *	Mat(int row, int col, CV_RGBA, TypedArray data, ArrayBuffer buffer)
   *	<b>Parameters</b>
   *	row - Number of rows in a 2D array
   *	col - Number of columns in a 2D array
   *	type - Array type. Use CV_8U, ..., CV_64F to create matrices.
   *	channel - Number of channels in a 2D array
   *	buffer - An ArrayBuffer.
   */
  var Mat = function (__row, __col, __type, __channel, __buffer) {
    this.row =
      __row || error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    this.col =
      __col || error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    this.channel = __channel;
    __type
      ? __type.call(this, __row, __col, __channel, __buffer)
      : error(arguments.callee, UNSPPORT_DATA_TYPE /* {line} */);
    this.data.length === this.row * this.col * this.channel ||
      error(arguments.callee, MAT_SIZE_ERROR /* {line} */);
  };
  cv.Mat = Mat;
  /***********************************************
   *	<h3>Mat.getType</h3>
   *	Gets the type of the data.
   *	<b>Method</b>
   *	String Mat.getType()
   */
  Mat.prototype.getType = function () {
    if (this.type.match(/CV\_[0-9]/)) {
      return this.type + this.channel + "C";
    } else {
      return this.type;
    }
  };
  /***********************************************
   *	<h3>Mat.toString</h3>
   *	Gets a String representing the value of the Mat.
   *	<b>Method</b>
   *	String Mat.toString()
   */
  Mat.prototype.toString = function () {
    var tempData = this.data,
      text = "Mat(" + this.type + ") = {\n",
      num = this.col * this.channel;
    for (var i = 0; i < this.row; i++) {
      text += "[";
      for (var j = 0; j < num; j++) {
        text += tempData[i * num + j] + ",";
      }
      text += "]\n";
    }
    text += "}";
    return text;
  };
  /***********************************************
   *	<h3>Mat.depth</h3>
   *	Returns the depth of a matrix element.
   *	<b>Method</b>
   *	Function Mat.depth()
   */
  Mat.prototype.depth = function () {
    return eval(this.type);
  };
  /***********************************************
   *	<h3>Mat.clone</h3>
   *	Creates a full copy of the array and the underlying data.
   *	<b>Method</b>
   *	Mat Mat.clone()
   */
  Mat.prototype.clone = function () {
    var tempMat;
    if (this.type === "CV_RGBA") {
      tempMat = new Mat(this.row, this.col, this.depth(), this.data);
    } else {
      tempMat = new Mat(this.row, this.col, this.depth(), this.channel);
      tempMat.data = this.data.subarray(0);
    }
    return tempMat;
  };
  /***********************************************
   *	<h3>Mat.getRow</h3>
   *	Returns a reference to the specified array element.
   *	<b>Method</b>
   *	Rect Mat.getRow(int y)
   *	y – A 0-based row index.
   */
  Mat.prototype.getRow = function (__i) {
    var len = this.col * this.channel,
      rowLen = len * this.bytes,
      i = __i || 0;

    var array = new this.data.constructor(this.buffer, i * rowLen, len);
    return new Rect(array, this.channel);
  };
  /***********************************************
   *	<h3>Mat.getRow</h3>
   *	Returns a reference to the specified array element.
   *	<b>Method</b>
   *	Rect Mat.getCol(int x)
   *	x – A 0-based column index.
   */
  Mat.prototype.getCol = function (__i) {
    var len = this.col * this.channel,
      rowLen = len * this.bytes,
      array = [],
      i = __i || 0;

    function getAllElement(__constructor) {
      var row = this.row,
        channel = this.channel;
      for (var j = 0; j < row; j++) {
        array.push(new __constructor(this.buffer, j * rowLen + i, 1 * channel));
      }
    }

    getAllElement(this.data.constructor);

    return new Rect(array, this.channel);
  };
  /***********************************************
   *	<h3>Mat.rowRange</h3>
   *	Creates a matrix header for the specified row span.
   *	<b>Method</b>
   *	Rect Mat.rowRange(int startrow, int endrow)
   *	startrow – An inclusive 0-based start index of the row span.
   *	endrow – An exclusive 0-based ending index of the row span.
   */
  Mat.prototype.rowRange = function (__i, __j) {
    var len = this.col * this.channel,
      rowLen = len * this.bytes,
      array = [],
      i = __i || 0,
      j = __j || this.row;

    function getAllElement(__constructor) {
      var row = this.row;
      for (var k = i; k <= j; k++) {
        array.push(new __constructor(this.buffer, k * rowLen, len));
      }
    }

    getAllElement(this.data.constructor);

    return new Rect(array, this.channel);
  };
  /***********************************************
   *	<h3>Mat.colRange</h3>
   *	Creates a matrix header for the specified row span.
   *	<b>Method</b>
   *	Rect Mat.colRange(int startcol, int endcol)
   *	startcol – An inclusive 0-based start index of the column span.
   *	endcol – An exclusive 0-based ending index of the column span.
   */
  Mat.prototype.colRange = function (__i, __j) {
    var len = this.col * this.channel,
      rowLen = len * this.bytes,
      array = [],
      i = __i || 0,
      j = __j || this.col;

    function getAllElement(__constructor) {
      var row = this.row;
      channel = this.channel;
      for (var k = 0; k < row; k++) {
        array.push(
          new __constructor(
            this.buffer,
            k * rowLen + __i,
            (__j - __i + 1) * channel
          )
        );
      }
    }

    getAllElement(Float64Array);

    return new Rect(array, this.channel);
  };
  /***********************************************
   *	<h3>Mat.convertTo</h3>
   *	Creates a matrix header for the specified row span.
   *	<b>Method</b>
   *	Array Mat.convertTo(Function type, Mat dst)
   *	type - Array type. Use CV_8U, ..., CV_64F to create new matrices.
   *	dst – output Mat.
   */
  Mat.prototype.convertTo = function (__type, __dst) {
    var dst = __dst || new Mat(this.row, this.col, __type),
      dBuffer = dst.buffer;
    switch (__type.toString().match(/function\s+(CV_[0-9A-Z]+)/)[1]) {
      case "CV_8I":
        new Int8Array(dBuffer).set(this.data);
        break;
      case "CV_8U":
        new Uint8Array(dBuffer).set(this.data);
        break;
      case "CV_RGBA":
      case "CV_GRAY":
        new Uint8ClampedArray(dBuffer).set(this.data);
        break;
      case "CV_16I":
        new Int16Array(dBuffer).set(this.data);
        break;
      case "CV_16U":
        new Uint16Array(dBuffer).set(this.data);
        break;
      case "CV_32I":
        new Int32Array(dBuffer).set(this.data);
        break;
      case "CV_32U":
        new Uint32Array(dBuffer).set(this.data);
        break;
      case "CV_32F":
        new Float32Array(dBuffer).set(this.data);
        break;
      case "CV_64F":
        new Float64Array(dBuffer).set(this.data);
        break;
    }

    return dst;
  };
  /***********************************************
   *	<h3>Mat.at</h3>
   *	Returns a reference to the specified array element.
   *	<b>Method</b>
   *	TypedArray Mat.at(String type, int i)
   *	TypedArray Mat.at(String type, int i, int j)
   *	type - the returned TypedArray type.
   *	i – Index along the dimension 0.
   *	j – Index along the dimension 1.
   */
  Mat.prototype.at = function (__type, __x, __y) {
    var type =
      __type || error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    var x = __x || 0,
      y = __y || 0,
      rowLen = this.col * this.channel * this.bytes,
      len = 1;

    if (type.indexOf("Vec") > -1) {
      var temp = __type.match(/Vec(\d+)([a-z])/);
      len = parseInt(temp[1]);
      switch (temp[2]) {
        case "b":
          type = "uchar";
          break;
        case "s":
          type = "short";
          break;
        case "i":
          type = "int";
          break;
        case "f":
          type = "float";
          break;
        case "d":
          type = "double";
          break;
      }
    }

    switch (type) {
      case "uchar":
        return new Uint8Array(this.buffer, y * rowLen + x, len);
        break;
      case "short":
        return new Int16Array(this.buffer, y * rowLen + x * 2, len);
        break;
      case "int":
        return new Int32Array(this.buffer, y * rowLen + x * 4, len);
        break;
      case "float":
        return new Float32Array(this.buffer, y * rowLen + x * 4, len);
        break;
      case "doulble":
        return new Float64Array(this.buffer, y * rowLen + x * 8, len);
        break;
      default:
        error(arguments.callee, UNSPPORT_DATA_TYPE /* {line} */);
    }
  };

  /***********************************************
   *	<h2>Rect</h2>
   *	<b>Constructors</b>
   *	Rect()
   *	Mat(Array<TrypeArray> data, int channel)
   *	<b>Parameters</b>
   *	data - a Rect data.
   *	channel - Number of channels in a 2D Rect.
   */
  var Rect = function (__array, __channel) {
    this.data = __array || [];
    this.channel =
      __channel || error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
  };
  cv.Rect = Rect;

  /***********************************************
   *	<h2>imread</h2>
   *	Loads an image from a file.
   *	<b>Method</b>
   *	Mat imread(Image in)
   *	<b>Parameters</b>
   *	in - The input Image.
   */
  var imread = function (__image) {
    __image || error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    var width = __image.width,
      height = __image.height;
    iResize(width, height);
    iCtx.drawImage(__image, 0, 0);
    var imageData = iCtx.getImageData(0, 0, width, height),
      tempMat = new Mat(height, width, CV_RGBA, imageData.data);
    imageData = null;
    iCtx.clearRect(0, 0, width, height);
    return tempMat;
  };
  cv.imread = imread;

  /***********************************************
   *	<h2>imwrite</h2>
   *	Saves an image to a specified file.
   *	<b>Method</b>
   *	bool imwrite(Mat in)
   *	<b>Parameters</b>
   *	in - The input Mat.
   *	flag - if output the image or just show the image.
   */
  var imwrite = function (__imgMat, __flag) {
    __imgMat || error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    if (__imgMat.type === "CV_GRAY") {
      __imgMat = cvtColor(__imgMat, CV_GRAY2RGBA);
    }
    if (__imgMat.type === "CV_RGBA") {
      var width = __imgMat.col,
        height = __imgMat.row,
        imageData = iCtx.createImageData(width, height);
      imageData.data.set(__imgMat.data);
      iResize(width, height);
      iCtx.putImageData(imageData, 0, 0);
      var data = iCanvas.toDataURL();

      iCtx.clearRect(0, 0, width, height);
      var storage = window.localStorage;
      storage.imUrl = data;
      //location.href = __flag ? data.replace("image/png", "image/octet-stream") : data;
      return true;
    } else {
      error(arguments.callee, UNSPPORT_DATA_TYPE /* {line} */);
      return false;
    }
  };
  cv.imwrite = imwrite;

  function RGBA2ImageData(__imgMat) {
    __imgMat || error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    if (__imgMat.type === "CV_GRAY") {
      __imgMat = cvtColor(__imgMat, CV_GRAY2RGBA);
    }
    //保证传递的参数为整数？？？
    var width = parseInt(__imgMat.col);
    var height = parseInt(__imgMat.row);
    imageData = iCtx.createImageData(width, height);
    imageData.data.set(__imgMat.data);
    return imageData;
  }
  cv.RGBA2ImageData = RGBA2ImageData;

  /***********************************************
   *	<h2>convertScaleAbs</h2>
   *	Calculates the first, second, third, or mixed image derivatives using an extended Sobel operator.
   *	<b>Method</b>
   *	Mat convertScaleAbs(Mat src, Mat dst )
   *	<b>Parameters</b>
   *	src – input image.
   *	dst – output Mat.
   */
  var convertScaleAbs = function (__src, __dst) {
    __src || error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    var height = __src.row,
      width = __src.col,
      channel = __src.channel,
      sData = __src.data;

    if (!__dst) {
      if (channel === 1) dst = new Mat(height, width, CV_GRAY);
      else if (channel === 4) dst = new Mat(height, width, CV_RGBA);
      else dst = new Mat(height, width, CV_8I, channel);
    } else {
      dst = __dst;
    }

    var dData = dst.data;

    var i, j, c;

    for (i = height; i--; ) {
      for (j = width * channel; j--; ) {
        dData[i * width * channel + j] = Math.abs(
          sData[i * width * channel + j]
        );
      }
    }

    return dst;
  };
  cv.convertScaleAbs = convertScaleAbs;

  /***********************************************
   *	<h2>addWeighted</h2>
   *	Calculates the weighted sum of two arrays.
   *	<b>Method</b>
   *	Mat addWeighted(Mat src1, double alpha, Mat src2, double beta, double gamma, Mat dst)
   *	<b>Parameters</b>
   *	src1 – first input array.
   *	alpha – weight of the first array elements.
   *	src2 – second input array of the same size and channel number as src1.
   *	beta – weight of the second array elements.
   *	gamma – scalar added to each sum.
   *	dst – output Mat.
   */
  var addWeighted = function (__src1, __alpha, __src2, __beta, __gamma, __dst) {
    (__src1 && __src2) ||
      error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    var height = __src1.row,
      width = __src1.col,
      alpha = __alpha || 0,
      beta = __beta || 0,
      channel = __src1.channel,
      gamma = __gamma || 0;
    if (
      height !== __src2.row ||
      width !== __src2.col ||
      channel !== __src2.channel
    ) {
      error(
        arguments.callee,
        "Src2 must be the same size and channel number as src1!" /* {line} */
      );
      return null;
    }

    if (!__dst) {
      if (__src1.type.match(/CV\_\d+/))
        dst = new Mat(height, width, __src1.depth(), channel);
      else dst = new Mat(height, width, __src1.depth());
    } else {
      dst = __dst;
    }

    var dData = dst.data,
      s1Data = __src1.data,
      s2Data = __src2.data;

    var i;

    for (i = height * width * channel; i--; )
      dData[i] = __alpha * s1Data[i] + __beta * s2Data[i] + gamma;

    return dst;
  };
  cv.addWeighted = addWeighted;

  /***********************************************
   *	<h2>cvtColor</h2>
   *	Converts an image from one color space to another.
   *	<b>Method</b>
   *	Mat cvtColor(Mat src, int code)
   *	Mat cvtColor(Mat src, int code, Mat dst)
   *	<b>Parameters</b>
   *	src – input image: 8-bit unsigned, 16-bit unsigned ( CV_16U ), or single-precision floating-point.
   *	code – color space conversion code.
   *	<b>Explain</b>
   *	CV_RGBA2GRAY -
   *		RGB[A] to Gray: Y <- 0.299 * R + 0.587 * G + 0.114 * B
   *	CV_GRAY2RGBA -
   *		Gray to RGB[A]: R <- Y, G <- Y, B <- Y, A <- 255
   */
  var cvtColor = function (__src, __code) {
    __src || error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    if (__src.type && __src.type.indexOf("CV_") > -1) {
      var row = __src.row,
        col = __src.col;
      switch (__code) {
        case CV_RGBA2GRAY:
          var dst = new Mat(row, col, CV_GRAY),
            data = dst.data,
            data2 = __src.data;
          var pix = row * col;
          while (pix) {
            // 960 / 32768 = 0.29901123046875
            // 19235 / 32768 = 0.587005615234375
            // 3736 / 32768 = 0.114013671875
            data[--pix] =
              (data2[4 * pix] * 960 +
                data2[4 * pix + 1] * 19235 +
                data2[4 * pix + 2] * 3736) >>
              15;
          }
          break;
        case CV_RGBA2GRAY_DUFF:
          var dst = new Mat(row, col, CV_GRAY),
            data = dst.data,
            data2 = __src.data;
          var total = row * col,
            length = total >> 3,
            i = length,
            rStartAt,
            gStartAt;
          for (; i--; ) {
            gStartAt = i << 3;
            rStartAt = gStartAt << 2;
            data[gStartAt] =
              (data2[rStartAt] * 960 +
                data2[++rStartAt] * 19235 +
                data2[++rStartAt] * 3736) >>
              15;
            rStartAt++;
            data[++gStartAt] =
              (data2[++rStartAt] * 960 +
                data2[++rStartAt] * 19235 +
                data2[++rStartAt] * 3736) >>
              15;
            rStartAt++;
            data[++gStartAt] =
              (data2[++rStartAt] * 960 +
                data2[++rStartAt] * 19235 +
                data2[++rStartAt] * 3736) >>
              15;
            rStartAt++;
            data[++gStartAt] =
              (data2[++rStartAt] * 960 +
                data2[++rStartAt] * 19235 +
                data2[++rStartAt] * 3736) >>
              15;
            rStartAt++;
            data[++gStartAt] =
              (data2[++rStartAt] * 960 +
                data2[++rStartAt] * 19235 +
                data2[++rStartAt] * 3736) >>
              15;
            rStartAt++;
            data[++gStartAt] =
              (data2[++rStartAt] * 960 +
                data2[++rStartAt] * 19235 +
                data2[++rStartAt] * 3736) >>
              15;
            rStartAt++;
            data[++gStartAt] =
              (data2[++rStartAt] * 960 +
                data2[++rStartAt] * 19235 +
                data2[++rStartAt] * 3736) >>
              15;
            rStartAt++;
            data[++gStartAt] =
              (data2[++rStartAt] * 960 +
                data2[++rStartAt] * 19235 +
                data2[++rStartAt] * 3736) >>
              15;
          }
          gStartAt = length << 3;
          rStartAt = gStartAt << 2;
          for (; gStartAt < total; ) {
            data[gStartAt++] =
              (data2[rStartAt++] * 960 +
                data2[rStartAt++] * 19235 +
                data2[rStartAt++] * 3736) >>
              15;
            rStartAt++;
          }
          break;
        case CV_GRAY2RGBA:
          var dst = new Mat(row, col, CV_RGBA),
            data = dst.data,
            data2 = __src.data;
          var pix1,
            pix2,
            pix3,
            pix = (__src.row * __src.col) << 2;
          while (pix) {
            data[(pix -= 4)] = data[pix + 1] = data[pix + 2] = data2[pix >> 2];
            data[(pix3 = pix + 3)] = 255;
          }
          break;
      }
    } else {
      error(arguments.callee, UNSPPORT_DATA_TYPE /* {line} */);
    }
    return dst;
  };
  cv.cvtColor = cvtColor;

  /***********************************************
   *	<h3>brightnessContrast</h3>
   *	Changes the contrast and brightness of an image
   *	<b>Method</b>
   *	Mat brightnessContrast(Mat src, int brightness, int contrast)
   *	<b>Parameters</b>
   *	src – Source image.
   *	brightness – brightness control value, it should be range in [-255, 255];
   *	contrast – contrast control value, it should be range in [-255, 255];
   */
  var brightnessContrast = function (__src, __brightness, __contrast) {
    __src || error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    if (__src.type === "CV_RGBA") {
      var sData = __src.data,
        width = __src.col,
        height = __src.row,
        dst = new Mat(height, width, CV_RGBA),
        dData = dst.data,
        brightness = Math.max(-255, Math.min(255, __brightness || 0)),
        contrast = Math.max(-255, Math.min(255, __contrast || 0));

      var gray = cvtColor(__src, CV_RGBA2GRAY),
        allValue = 0,
        gData = gray.data;
      var y, x, c;

      for (y = height; y--; ) {
        for (x = width; x--; ) {
          allValue += gData[y * width + x];
        }
      }

      var r,
        g,
        b,
        offset,
        gAverage = (allValue / (height * width)) | 0;

      for (y = height; y--; ) {
        for (x = width; x--; ) {
          offset = (y * width + x) * 4;
          dData[offset] = sData[offset] + brightness;
          dData[offset + 1] = sData[offset + 1] + brightness;
          dData[offset + 2] = sData[offset + 2] + brightness;

          if (contrast >= 0) {
            for (c = 3; c--; ) {
              if (dData[offset + c] >= gAverage) {
                dData[offset + c] =
                  dData[offset + c] + ((255 - gAverage) * contrast) / 255;
              } else {
                dData[offset + c] =
                  dData[offset + c] - (gAverage * contrast) / 255;
              }
            }
          } else {
            dData[offset] =
              dData[offset] + ((dData[offset] - gAverage) * contrast) / 255;
            dData[offset + 1] =
              dData[offset + 1] +
              ((dData[offset + 1] - gAverage) * contrast) / 255;
            dData[offset + 2] =
              dData[offset + 2] +
              ((dData[offset + 2] - gAverage) * contrast) / 255;
          }

          dData[offset + 3] = 255;
        }
      }
    } else {
      error(arguments.callee, UNSPPORT_DATA_TYPE /* {line} */);
    }
    return dst;
  };
  cv.brightnessContrast = brightnessContrast;

  /*
     Various border types, image boundaries are denoted with '|'
    
     * BORDER_REPLICATE:     aaaaaa|abcdefgh|hhhhhhh
     * BORDER_REFLECT:       fedcba|abcdefgh|hgfedcb
     * BORDER_REFLECT_101:   gfedcb|abcdefgh|gfedcba
     * BORDER_WRAP:          cdefgh|abcdefgh|abcdefg
     * BORDER_CONSTANT:      iiiiii|abcdefgh|iiiiiii  with some specified 'i'
     */
  /***********************************************
   *	<h2>borderInterpolate</h2>
   *	Computes the source location of an extrapolated pixel.
   *	<b>Method</b>
   *	int borderInterpolate(int p, int len, int borderType)
   *	<b>Parameters</b>
   *	p – 0-based coordinate of the extrapolated pixel along one of the axes, likely <0 or >= len .
   *	len – Length of the array along the corresponding axis.
   *	borderType – Border type. When borderType==CV_BORDER_CONSTANT , the function always returns -1, regardless of p and len .
   */
  function borderInterpolate(__p, __len, __borderType) {
    if (__p < 0 || __p >= __len) {
      switch (__borderType) {
        case CV_BORDER_REPLICATE:
          __p = __p < 0 ? 0 : __len - 1;
          break;
        case CV_BORDER_REFLECT:
        case CV_BORDER_REFLECT_101:
          var delta = __borderType == CV_BORDER_REFLECT_101;
          if (__len == 1) return 0;
          do {
            if (__p < 0) __p = -__p - 1 + delta;
            else __p = __len - 1 - (__p - __len) - delta;
          } while (__p < 0 || __p >= __len);
          break;
        case CV_BORDER_WRAP:
          if (__p < 0) __p -= (((__p - __len + 1) / __len) | 0) * __len;
          if (__p >= __len) __p %= __len;
          break;
        case CV_BORDER_CONSTANT:
          __p = -1;
        default:
          error(arguments.callee, UNSPPORT_BORDER_TYPE /* {line} */);
      }
    }
    return __p;
  }

  /***********************************************
   *	<h2>copyMakeBorder</h2>
   *	Forms a border around an image.
   *	<b>Method</b>
   *	Mat copyMakeBorder(Mat src)
   *	Mat copyMakeBorder(Mat src, int top, int left = top, int bottom = top, int right = left, int borderType = CV_BORDER_REFLECT, Array value = [0, 0, 0, 255])
   *	<b>Parameters</b>
   *	src – Source image.
   *	top -
   *	left -
   *	bottom -
   *	right – Parameter specifying how many pixels in each direction from the source image rectangle to extrapolate. For example, top=1, bottom=1, left=1, right=1 mean that 1 pixel-wide border needs to be built.
   *	borderType – Border type. When borderType==CV_BORDER_CONSTANT , the function always returns -1, regardless of p and len .
   *	value – Border value if borderType==BORDER_CONSTANT .
   */
  var copyMakeBorder = function (
    __src,
    __top,
    __left,
    __bottom,
    __right,
    __borderType,
    __value
  ) {
    if (__src.type !== "CV_RGBA" && __src.type !== "CV_GRAY") {
      error(arguments.callee, UNSPPORT_DATA_TYPE /* {line} */);
    }
    if (__borderType === CV_BORDER_CONSTANT) {
      return copyMakeConstBorder_8U(
        __src,
        __top,
        __left,
        __bottom,
        __right,
        __value
      );
    } else {
      return copyMakeBorder_8U(
        __src,
        __top,
        __left,
        __bottom,
        __right,
        __borderType
      );
    }
  };
  cv.copyMakeBorder = copyMakeBorder;
  //NOT CV_BORDER_CONSTANT
  function copyMakeBorder_8U(
    __src,
    __top,
    __left,
    __bottom,
    __right,
    __borderType
  ) {
    var i, j, k;
    var width = __src.col,
      height = __src.row,
      channel = __src.channel;
    var top = __top,
      left = __left || __top,
      right = __right || left,
      bottom = __bottom || top;

    top === -1 && (top = 0);
    left === -1 && (left = 0);
    right === -1 && (right = 0);
    bottom === -1 && (bottom = 0);

    var dstWidth = width + left + right,
      dstHeight = height + top + bottom,
      borderType = __borderType || CV_BORDER_REFLECT;

    var buffer = new ArrayBuffer(dstHeight * dstWidth * channel),
      tab,
      TypedArray,
      c;

    if (false) {
      //This way is slower in FireFox 17.0.1.
      tab = new Uint32Array(left + right);
      for (i = left; i--; ) {
        tab[i] = borderInterpolate(i - left, width, borderType);
      }
      for (i = right; i--; ) {
        tab[i + left] = borderInterpolate(width + i, width, borderType);
      }
      TypedArray = Uint32Array;
      c = 1;
    } else {
      tab = new Uint32Array((left + right) * channel);
      for (i = left; i--; ) {
        j = borderInterpolate(i - left, width, borderType) * channel;
        for (k = channel; k--; ) tab[i * channel + k] = j + k;
      }
      for (i = right; i--; ) {
        j = borderInterpolate(width + i, width, borderType) * channel;
        for (k = channel; k--; ) tab[(i + left) * channel + k] = j + k;
      }
      TypedArray = Uint8Array;
      c = channel;
      left *= c;
      right *= c;
    }

    var tempArray,
      data,
      dLen = dstWidth * c,
      sLen = width * c;

    //Reading TypedArray sequentially is faster.
    for (i = 0; i < height; i++) {
      tempArray = new TypedArray(buffer, (i + top) * dstWidth * channel, dLen);
      data = new TypedArray(__src.buffer, i * width * channel, sLen);
      for (j = 0; j < left; j++) tempArray[j] = data[tab[j]];
      for (j = 0; j < right; j++)
        tempArray[j + sLen + left] = data[tab[j + left]];
      tempArray.set(data, left);
    }

    var allArray = new TypedArray(buffer);
    for (i = 0; i < top; i++) {
      j = borderInterpolate(i - top, height, borderType);
      tempArray = new TypedArray(buffer, i * dstWidth * channel, dLen);
      tempArray.set(allArray.subarray((j + top) * dLen, (j + top + 1) * dLen));
    }
    for (i = 0; i < bottom; i++) {
      j = borderInterpolate(i + height, height, borderType);
      tempArray = new TypedArray(
        buffer,
        (i + top + height) * dstWidth * channel,
        dLen
      );
      tempArray.set(allArray.subarray((j + top) * dLen, (j + top + 1) * dLen));
    }

    return new Mat(dstHeight, dstWidth, __src.depth(), null, buffer);
  }
  //CV_BORDER_CONSTANT
  function copyMakeConstBorder_8U(
    __src,
    __top,
    __left,
    __bottom,
    __right,
    __value
  ) {
    var i, j;
    var width = __src.col,
      height = __src.row,
      channel = __src.channel;
    var top = __top,
      left = __left || __top,
      right = __right || left,
      bottom = __bottom || top;

    top === -1 && (top = 0);
    left === -1 && (left = 0);
    right === -1 && (right = 0);
    bottom === -1 && (bottom = 0);

    var dstWidth = width + left + right,
      dstHeight = height + top + bottom,
      value = __value || [0, 0, 0, 255];
    var constBuf = new ArrayBuffer(dstWidth * channel),
      constArray = new Uint8Array(constBuf),
      buffer = new ArrayBuffer(dstHeight * dstWidth * channel);

    for (i = 0; i < dstWidth; i++) {
      for (j = 0; j < channel; j++) {
        constArray[i * channel + j] = value[j];
      }
    }

    var TypedArray, c;

    if (channel === 4) {
      TypedArray = Uint32Array;
      c = 1;
    } else {
      TypedArray = Uint8Array;
      c = channel;
    }

    constArray = new TypedArray(constBuf);
    var tempArray,
      rLeft = c * left,
      rRight = c * right,
      sLen = c * width,
      dLen = c * dstWidth;

    for (i = 0; i < height; i++) {
      tempArray = new TypedArray(buffer, (i + top) * dstWidth * channel, rLeft);
      tempArray.set(constArray.subarray(0, rLeft));
      tempArray = new TypedArray(
        buffer,
        ((i + top + 1) * dstWidth - right) * channel,
        rRight
      );
      tempArray.set(constArray.subarray(0, rRight));
      tempArray = new TypedArray(
        buffer,
        ((i + top) * dstWidth + left) * channel,
        sLen
      );
      tempArray.set(new TypedArray(__src.buffer, i * width * channel, sLen));
    }

    for (i = 0; i < top; i++) {
      tempArray = new TypedArray(buffer, i * dstWidth * channel, dLen);
      tempArray.set(constArray);
    }

    for (i = 0; i < bottom; i++) {
      tempArray = new TypedArray(
        buffer,
        (i + top + height) * dstWidth * channel,
        dLen
      );
      tempArray.set(constArray);
    }

    return new Mat(dstHeight, dstWidth, __src.depth(), null, buffer);
  }

  /***********************************************
   *	<h2>blur</h2>
   *	Blurs an image using the normalized box filter.
   *	<b>Method</b>
   *	Mat blur(Mat src, int size1 = 3, int size2 = size1)
   *	Mat blur(Mat src, int size1, int size2 = size1, int borderType = CV_BORDER_REFLECT)
   *	Mat blur(Mat src, int size1, int size2 = size1, int borderType = CV_BORDER_REFLECT, Mat dst)
   *	<b>Parameters</b>
   *	src – Source image.
   *	size1 – The first parameter of the blur operation, the aperture width. Must be a positive odd number (1, 3, 5, ...).
   *	size2 – The second parameter of the blur operation, the aperture height. If size2 is zero, it is set to size1 . Otherwise it must be a positive odd number.
   *	borderType – Border type. When borderType==CV_BORDER_CONSTANT , the function always returns -1, regardless of p and len .
   *	dst – output image of the same size and type as src.
   */

  var blur = function (__src, __size1, __size2, __borderType, __dst) {
    __src || error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    if (__src.type && __src.type == "CV_RGBA") {
      var height = __src.row,
        width = __src.col,
        dst = __dst || new Mat(height, width, CV_RGBA),
        dstData = dst.data;
      var size1 = __size1 || 3,
        size2 = __size2 || size1;
      if (size1 & (1 === 0) || size2 & (1 === 0)) {
        error(arguments.callee, UNSPPORT_SIZE /* {line} */);
        return __src;
      }
      var startX = size1 >> 1,
        startY = size2 >> 1;
      var withBorderMat = copyMakeBorder(__src, -1, startX, 0, 0, __borderType),
        mData = withBorderMat.data,
        mWidth = withBorderMat.col;

      var newValue, offset, offsetI;
      var i, j, c, y, x;

      for (i = height; i--; ) {
        offsetI = i * width;
        for (j = width; j--; ) {
          for (c = 3; c--; ) {
            newValue = 0;
            for (x = size1; x--; ) {
              offset = i * mWidth * 4 + (x + j) * 4 + c;
              newValue += mData[offset];
            }
            dstData[(j + offsetI) * 4 + c] = newValue / size1;
          }
          dstData[(j + offsetI) * 4 + 3] =
            mData[(i + startY) * mWidth * 4 + (j + startX) * 4 + 3];
        }
      }

      withBorderMat = copyMakeBorder(dst, startY, -1, 0, 0, __borderType);
      mData = withBorderMat.data;
      mWidth = withBorderMat.col;

      for (i = height; i--; ) {
        offsetI = i * width;
        for (j = width; j--; ) {
          for (c = 3; c--; ) {
            newValue = 0;
            for (y = size2; y--; ) {
              offset = (y + i) * mWidth * 4 + j * 4 + c;
              newValue += mData[offset];
            }
            dstData[(j + offsetI) * 4 + c] = newValue / size2;
          }
        }
      }
    } else {
      error(arguments.callee, UNSPPORT_DATA_TYPE /* {line} */);
    }
    return dst;
  };
  cv.blur = blur;
  //old verision
  var blurOld = function (__src, __size1, __size2, __borderType, __dst) {
    __src || error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    if (__src.type && __src.type == "CV_RGBA") {
      var height = __src.row,
        width = __src.col,
        dst = __dst || new Mat(height, width, CV_RGBA),
        dstData = dst.data;
      var size1 = __size1 || 3,
        size2 = __size2 || size1,
        size = size1 * size2;
      if (size1 & (1 === 0) || size2 & (1 === 0)) {
        error(arguments.callee, UNSPPORT_SIZE /* {line} */);
        return __src;
      }
      var startX = size1 >> 1,
        startY = size2 >> 1;
      var withBorderMat = copyMakeBorder(
          __src,
          startY,
          startX,
          0,
          0,
          __borderType
        ),
        mData = withBorderMat.data,
        mWidth = withBorderMat.col;

      var newValue, nowX, offsetY, offsetI;
      var i, j, c, y, x;

      for (i = height; i--; ) {
        offsetI = i * width;
        for (j = width; j--; ) {
          for (c = 3; c--; ) {
            newValue = 0;
            for (y = size2; y--; ) {
              offsetY = (y + i) * mWidth * 4;
              for (x = size1; x--; ) {
                nowX = (x + j) * 4 + c;
                newValue += mData[offsetY + nowX];
              }
            }
            dstData[(j + offsetI) * 4 + c] = newValue / size;
          }
          dstData[(j + offsetI) * 4 + 3] =
            mData[offsetY + startY * mWidth * 4 + (j + startX) * 4 + 3];
        }
      }
    } else {
      error(arguments.callee, UNSPPORT_DATA_TYPE /* {line} */);
    }
    return dst;
  };
  cv.blurOld = blurOld;

  /***********************************************
   *	<h2>GaussianBlur</h2>
   *	Blurs an image using the normalized box filter.
   *	<b>Method</b>
   *	Mat GaussianBlur(Mat src, int ksize1, int ksize2 = 0, double sigmaX, double sigmaY = 0, int borderType=CV_BORDER_REFLECT )
   *	<b>Parameters</b>
   *	src – Source image.
   *	size1 – The first parameter of the blur operation, the aperture width. Must be a positive odd number (1, 3, 5, ...).
   *	size2 – The second parameter of the blur operation, the aperture height. If size2 is zero, it is set to size1 . Otherwise it must be a positive odd number.
   *	sigmaX – Gaussian kernel standard deviation in X direction.
   *	sigmaY – Gaussian kernel standard deviation in Y direction; if sigmaY is zero, it is set to be equal to sigmaX, if both sigmas are zeros, they are computed from ksize.width and ksize.height.
   *	borderType – Border type. When borderType==CV_BORDER_CONSTANT , the function always returns -1, regardless of p and len .
   *	dst – output image of the same size and type as src.
   */
  var GaussianBlur = function (
    __src,
    __size1,
    __size2,
    __sigma1,
    __sigma2,
    __borderType,
    __dst
  ) {
    __src || error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    if (__src.type && __src.type == "CV_RGBA") {
      var height = __src.row,
        width = __src.col,
        dst = __dst || new Mat(height, width, CV_RGBA),
        dstData = dst.data;
      var sigma1 = __sigma1 || 0,
        sigma2 = __sigma2 || __sigma1;
      var size1 = __size1 || Math.round(sigma1 * 6 + 1) | 1,
        size2 = __size2 || Math.round(sigma2 * 6 + 1) | 1;
      if (size1 & (1 === 0) || size2 & (1 === 0)) {
        error(arguments.callee, UNSPPORT_SIZE /* {line} */);
        return __src;
      }
      var startX = size1 >> 1,
        startY = size2 >> 1;
      var withBorderMat = copyMakeBorder(__src, -1, startX, 0, 0, __borderType),
        mData = withBorderMat.data,
        mWidth = withBorderMat.col;

      var kernel1 = getGaussianKernel(size1, sigma1),
        kernel2;

      if (size1 === size2 && sigma1 === sigma2) kernel2 = kernel1;
      else kernel2 = getGaussianKernel(size2, sigma2);

      var i, j, c, y, x;

      var newValue, offset, offsetI;

      for (i = height; i--; ) {
        offsetI = i * width;
        for (j = width; j--; ) {
          for (c = 3; c--; ) {
            newValue = 0;
            for (x = size1; x--; ) {
              offset = i * mWidth * 4 + (x + j) * 4 + c;
              newValue += mData[offset] * kernel1[x];
            }
            dstData[(j + offsetI) * 4 + c] = newValue;
          }
          dstData[(j + offsetI) * 4 + 3] =
            mData[(i + startY) * mWidth * 4 + (j + startX) * 4 + 3];
        }
      }

      withBorderMat = copyMakeBorder(dst, startY, -1, 0, 0, __borderType);
      mData = withBorderMat.data;
      mWidth = withBorderMat.col;

      for (i = height; i--; ) {
        offsetI = i * width;
        for (j = width; j--; ) {
          for (c = 3; c--; ) {
            newValue = 0;
            for (y = size2; y--; ) {
              offset = (y + i) * mWidth * 4 + j * 4 + c;
              newValue += mData[offset] * kernel2[y];
            }
            dstData[(j + offsetI) * 4 + c] = newValue;
          }
        }
      }
    } else {
      error(arguments.callee, UNSPPORT_DATA_TYPE /* {line} */);
    }
    return dst;
  };
  cv.GaussianBlur = GaussianBlur;
  //old verision
  var GaussianBlurOld = function (
    __src,
    __size1,
    __size2,
    __sigma1,
    __sigma2,
    __borderType,
    __dst
  ) {
    __src || error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    if (__src.type && __src.type == "CV_RGBA") {
      var height = __src.row,
        width = __src.col,
        dst = __dst || new Mat(height, width, CV_RGBA),
        dstData = dst.data;
      var sigma1 = __sigma1 || 0,
        sigma2 = __sigma2 || __sigma1;
      var size1 = __size1 || Math.round(sigma1 * 6 + 1) | 1,
        size2 = __size2 || Math.round(sigma2 * 6 + 1) | 1,
        size = size1 * size2;
      if (size1 & (1 === 0) || size2 & (1 === 0)) {
        error(arguments.callee, UNSPPORT_SIZE /* {line} */);
        return __src;
      }
      var startX = size1 >> 1,
        startY = size2 >> 1;
      var withBorderMat = copyMakeBorder(
          __src,
          startY,
          startX,
          0,
          0,
          __borderType
        ),
        mData = withBorderMat.data,
        mWidth = withBorderMat.col;

      var kernel1 = getGaussianKernel(size1, sigma1),
        kernel2,
        kernel = new Array(size1 * size2);

      if (size1 === size2 && sigma1 === sigma2) kernel2 = kernel1;
      else kernel2 = getGaussianKernel(size2, sigma2);

      var i, j, c, y, x;

      for (i = kernel2.length; i--; ) {
        for (j = kernel1.length; j--; ) {
          kernel[i * size1 + j] = kernel2[i] * kernel1[j];
        }
      }

      var newValue, nowX, offsetY, offsetI;

      for (i = height; i--; ) {
        offsetI = i * width;
        for (j = width; j--; ) {
          for (c = 3; c--; ) {
            newValue = 0;
            for (y = size2; y--; ) {
              offsetY = (y + i) * mWidth * 4;
              for (x = size1; x--; ) {
                nowX = (x + j) * 4 + c;
                newValue += mData[offsetY + nowX] * kernel[y * size1 + x];
              }
            }
            dstData[(j + offsetI) * 4 + c] = newValue;
          }
          dstData[(j + offsetI) * 4 + 3] =
            mData[offsetY + startY * mWidth * 4 + (j + startX) * 4 + 3];
        }
      }
    } else {
      error(arguments.callee, UNSPPORT_DATA_TYPE /* {line} */);
    }
    return dst;
  };
  cv.GaussianBlurOld = GaussianBlurOld;

  /***********************************************
   *	<h2>getGaussianKernel</h2>
   *	Returns Gaussian filter coefficients.
   *	<b>Method</b>
   *	Array getGaussianKernel(int ksize, double sigma)
   *	<b>Parameters</b>
   *	ksize – Aperture size. It should be odd and positive.
   *	sigma – Gaussian standard deviation. If it is non-positive, it is computed from ksize as sigma = 0.3*((ksize-1)*0.5 - 1) + 0.8 .
   */
  function getGaussianKernel(__n, __sigma) {
    var SMALL_GAUSSIAN_SIZE = 7,
      smallGaussianTab = [
        [1],
        [0.25, 0.5, 0.25],
        [0.0625, 0.25, 0.375, 0.25, 0.0625],
        [0.03125, 0.109375, 0.21875, 0.28125, 0.21875, 0.109375, 0.03125],
      ];

    var fixedKernel =
      __n & (1 == 1) && __n <= SMALL_GAUSSIAN_SIZE && __sigma <= 0
        ? smallGaussianTab[__n >> 1]
        : 0;

    var sigmaX = __sigma > 0 ? __sigma : ((__n - 1) * 0.5 - 1) * 0.3 + 0.8,
      scale2X = -0.5 / (sigmaX * sigmaX),
      sum = 0;

    var i,
      x,
      t,
      kernel = [];

    for (i = 0; i < __n; i++) {
      x = i - (__n - 1) * 0.5;
      t = fixedKernel ? fixedKernel[i] : Math.exp(scale2X * x * x);
      kernel[i] = t;
      sum += t;
    }

    sum = 1 / sum;

    for (i = __n; i--; ) {
      kernel[i] *= sum;
    }

    return kernel;
  }

  /***********************************************
   *	<h2>medianBlur</h2>
   *	Blurs an image using the normalized box filter.
   *	<b>Method</b>
   *	Mat blur(Mat src, int size1 = 3, int size2 = size1)
   *	Mat blur(Mat src, int size1, int size2 = size1, int borderType = CV_BORDER_REFLECT)
   *	Mat blur(Mat src, int size1, int size2 = size1, int borderType = CV_BORDER_REFLECT, Mat dst)
   *	<b>Parameters</b>
   *	src – Source image.
   *	size1 – The first parameter of the blur operation, the aperture width. Must be a positive odd number (1, 3, 5, ...).
   *	size2 – The second parameter of the blur operation, the aperture height. If size2 is zero, it is set to size1 . Otherwise it must be a positive odd number.
   *	borderType – Border type. When borderType==CV_BORDER_CONSTANT , the function always returns -1, regardless of p and len .
   *	dst – output image of the same size and type as src.
   */
  var medianBlur = function (__src, __size1, __size2, __borderType, __dst) {
    __src || error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    if (__src.type && __src.type == "CV_RGBA") {
      var height = __src.row,
        width = __src.col,
        dst = __dst || new Mat(height, width, CV_RGBA),
        dstData = dst.data;
      var size1 = __size1 || 3,
        size2 = __size2 || size1,
        size = size1 * size2;
      if (size1 & (1 === 0) || size2 & (1 === 0)) {
        error(arguments.callee, UNSPPORT_SIZE /* {line} */);
        return __src;
      }
      var startX = size1 >> 1,
        startY = size2 >> 1;
      var withBorderMat = copyMakeBorder(
          __src,
          startY,
          startX,
          0,
          0,
          __borderType
        ),
        mData = withBorderMat.data,
        mWidth = withBorderMat.col;

      var newValue = [],
        nowX,
        offsetY,
        offsetI;
      var i, j, c, y, x;

      var median = (size >> 1) + 1;

      for (i = height; i--; ) {
        offsetI = i * width;
        for (j = width; j--; ) {
          for (c = 3; c--; ) {
            for (y = size2; y--; ) {
              offsetY = (y + i) * mWidth * 4;
              for (x = size1; x--; ) {
                nowX = (x + j) * 4 + c;
                newValue[y * size1 + x] = mData[offsetY + nowX];
              }
            }
            newValue.sort(function (a, b) {
              return a - b;
            });
            dstData[(j + offsetI) * 4 + c] = newValue[median];
          }
          dstData[(j + offsetI) * 4 + 3] =
            mData[offsetY + startY * mWidth * 4 + (j + startX) * 4 + 3];
        }
      }
    } else {
      error(arguments.callee, UNSPPORT_DATA_TYPE /* {line} */);
    }
    return dst;
  };
  cv.medianBlur = medianBlur;

  /***********************************************
   *	<h2>bilateralFilter</h2>
   *	Blurs an image using the normalized box filter.
   *	<b>Method</b>
   *	Mat bilateralFilter(Mat src, int ksize1, int ksize2 = 0, double sigmaX, double sigmaY = 0, int borderType=CV_BORDER_REFLECT )
   *	<b>Parameters</b>
   *	src – Source image.
   *	size – The parameter of the blur operation, the aperture width. Must be a positive odd number (1, 3, 5, ...).
   *	sigmaColor – Filter sigma in the color space. A larger value of the parameter means that farther colors within the pixel neighborhood (see sigmaSpace ) will be mixed together, resulting in larger areas of semi-equal color.
   *	sigmaSpace – Filter sigma in the coordinate space. A larger value of the parameter means that farther pixels will influence each other as long as their colors are close enough (see sigmaColor ). When d>0 , it specifies the neighborhood size regardless of sigmaSpace . Otherwise, d is proportional to sigmaSpace .
   *	borderType – Border type. When borderType==CV_BORDER_CONSTANT , the function always returns -1, regardless of p and len .
   *	dst – output image of the same size and type as src.
   */
  var bilateralFilter = function (
    __src,
    __size,
    __sigmaColor,
    __sigmaSpace,
    __borderType,
    __dst
  ) {
    if (__src.type && __src.type == "CV_RGBA") {
      var height = __src.row,
        width = __src.col,
        dst = __dst || new Mat(height, width, CV_RGBA),
        dstData = dst.data,
        sData = __src.data;
      var sigmaColor = __sigmaColor || 5,
        sigmaSpace = __sigmaSpace || 0.2;
      var __size = __size || Math.round(sigmaSpace * 6 + 1) | 1,
        size = __size * __size;
      if (__size & (1 === 0)) {
        error(arguments.callee, UNSPPORT_SIZE /* {line} */);
        return __src;
      }
      var start = __size >> 1;
      var withBorderMat = copyMakeBorder(
          __src,
          start,
          start,
          0,
          0,
          __borderType
        ),
        mData = withBorderMat.data,
        mWidth = withBorderMat.col;

      var kernel1 = getGaussianKernel(__size, sigmaColor),
        kernel = new Array(size);

      var i, j, c, y, x;

      for (i = kernel1.length; i--; ) {
        for (j = kernel1.length; j--; ) {
          kernel[i * __size + j] = kernel1[i] * kernel1[j];
        }
      }

      var dist, underValue, overValue, anchor, v, nowX, offsetY, offsetI;

      for (i = height; i--; ) {
        offsetI = i * width;
        for (j = width; j--; ) {
          for (c = 3; c--; ) {
            underValue = 0;
            overValue = 0;
            for (y = __size; y--; ) {
              offsetY = (y + i) * mWidth * 4;
              anchor = sData[(i * width + j) * 4 + c];
              for (x = __size; x--; ) {
                nowX = (x + j) * 4 + c;
                dist = anchor - mData[offsetY + nowX];
                v =
                  kernel[y * __size + x] *
                  Math.exp(((-1 * dist * dist) / sigmaColor) * sigmaColor);
                underValue += v;
                overValue += v * mData[offsetY + nowX];
              }
            }
            dstData[(j + offsetI) * 4 + c] = overValue / underValue;
          }
          dstData[(j + offsetI) * 4 + 3] =
            mData[offsetY + start * mWidth * 4 + (j + start) * 4 + 3];
        }
      }
    } else {
      error(arguments.callee, UNSPPORT_DATA_TYPE /* {line} */);
    }
    return dst;
  };
  //cv.bilateralFilter = bilateralFilter;
  //Unfinished

  /***********************************************
   *	<h2>filter2D</h2>
   *	Blurs an image using the normalized box filter.
   *	<b>Method</b>
   *	Mat filter2D(Mat src, Function ddepth, Mat kernel, int borderType=CV_BORDER_REFLECT, Mat dst )
   *	<b>Parameters</b>
   *	src – input image.
   *	ddepth –desired depth of the destination image; if it is negative, it will be the same as src.depth().
   *	kernel – convolution kernel (or rather a correlation kernel), a single-channel floating point matrix; if you want to apply different kernels to different channels, split the image into separate color planes using split() and process them individually.
   *	borderType – Border type. When borderType==CV_BORDER_CONSTANT , the function always returns -1, regardless of p and len .
   *	dst – output image of the same size and type as src.
   */
  var filter2D = function (__src, __depth, __kernel, __borderType, __dst) {
    (__src && __kernel) ||
      error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    var height = __src.row,
      width = __src.col,
      dst = __dst || new Mat(height, width, __depth || __src.depth()),
      dstData = dst.data,
      sData = __src.data,
      channel = __src.channel;
    var size1 = __kernel.col,
      size2 = __kernel.row,
      kData = __kernel.data;

    if (size1 & (1 === 0) || size2 & (1 === 0)) {
      error(arguments.callee, UNSPPORT_SIZE /* {line} */);
      return __src;
    }

    var startX = size1 >> 1,
      startY = size2 >> 1;
    var withBorderMat = copyMakeBorder(
        __src,
        startY,
        startX,
        0,
        0,
        __borderType
      ),
      mData = withBorderMat.data,
      mWidth = withBorderMat.col;

    var newValue, nowX, offsetY, offsetI;

    for (i = height; i--; ) {
      offsetI = i * width;
      for (j = width; j--; ) {
        for (c = channel; c--; ) {
          newValue = 0;
          for (y = size2; y--; ) {
            offsetY = (y + i) * mWidth * channel;
            for (x = size1; x--; ) {
              nowX = (x + j) * channel + c;
              newValue += mData[offsetY + nowX] * kData[y * size1 + x];
            }
          }
          dstData[(j + offsetI) * channel + c] = newValue;
        }
      }
    }

    return dst;
  };
  cv.filter2D = filter2D;

  /***********************************************
   *	<h2>filter2D</h2>
   *	Blurs an image using a separable linear filter.
   *	<b>Method</b>
   *	Mat separableLinearFilter(Mat src, Function ddepth, Array rowKernel, Array colKernel, int borderType=CV_BORDER_REFLECT, Mat dst )
   *	<b>Parameters</b>
   *	src – input image.
   *	ddepth –desired depth of the destination image; if it is negative, it will be the same as src.depth().
   *	rowKernel – Coefficients for filtering each row, a single-channel floating point Array; if you want to apply different kernels to different channels, split the image into separate color planes using split() and process them individually.
   *	colKernel – Coefficients for filtering each col.
   *	borderType – Border type. When borderType==CV_BORDER_CONSTANT , the function always returns -1, regardless of p and len .
   *	dst – output image of the same size and type as src.
   */
  var separableLinearFilter = function (
    __src,
    __depth,
    __rowKernel,
    __colKernel,
    __borderType,
    __dst
  ) {
    (__src && __rowKernel && __colKernel) ||
      error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    var height = __src.row,
      width = __src.col,
      dst = __dst || new Mat(height, width, __depth || __src.depth()),
      dstData = dst.data,
      sData = __src.data,
      channel = __src.channel;
    var size1 = __rowKernel.length,
      size2 = __colKernel.length;

    if (size1 & (1 === 0) || size2 & (1 === 0)) {
      error(arguments.callee, UNSPPORT_SIZE /* {line} */);
      return __src;
    }

    var startX = size1 >> 1,
      startY = size2 >> 1;
    var withBorderMat = copyMakeBorder(__src, -1, startX, 0, 0, __borderType),
      mData = withBorderMat.data,
      mWidth = withBorderMat.col;

    var i, j, c, y, x;

    var newValue, offset, offsetI;

    for (i = height; i--; ) {
      offsetI = i * width;
      for (j = width; j--; ) {
        for (c = 3; c--; ) {
          newValue = 0;
          for (x = size1; x--; ) {
            offset = i * mWidth * 4 + (x + j) * 4 + c;
            newValue += mData[offset] * __rowKernel[x];
          }
          dstData[(j + offsetI) * 4 + c] = newValue;
        }
        dstData[(j + offsetI) * 4 + 3] =
          mData[(i + startY) * mWidth * 4 + (j + startX) * 4 + 3];
      }
    }

    withBorderMat = copyMakeBorder(dst, startY, -1, 0, 0, __borderType);
    mData = withBorderMat.data;
    mWidth = withBorderMat.col;

    for (i = height; i--; ) {
      offsetI = i * width;
      for (j = width; j--; ) {
        for (c = 3; c--; ) {
          newValue = 0;
          for (y = size2; y--; ) {
            offset = (y + i) * mWidth * 4 + j * 4 + c;
            newValue += mData[offset] * __colKernel[y];
          }
          dstData[(j + offsetI) * 4 + c] = newValue;
        }
      }
    }
  };
  cv.separableLinearFilter = separableLinearFilter;

  /***********************************************
   *	<h2>threshold</h2>
   *	Applies a fixed-level threshold to each array element.
   *	<b>Method</b>
   *	Mat threshold(Mat src, Function thresh, uchar maxVal, int threshouldType=CV_THRESH_BINARY, Mat dst )
   *	<b>Parameters</b>
   *	src – Source array.
   *	thresh – Threshold value.
   *	maxVal – Maximum value to use with THRESH_BINARY and THRESH_BINARY_INV thresholding types.
   *	dst – output image of the same size and type as src.
   */
  var threshold = function (__src, __thresh, __maxVal, __thresholdType, __dst) {
    (__src && __thresh) ||
      error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    if (__src.type && __src.type == "CV_GRAY") {
      var width = __src.col,
        height = __src.row,
        sData = __src.data,
        dst = __dst || new Mat(height, width, CV_GRAY),
        dData = dst.data,
        maxVal = __maxVal || 255,
        threshouldType = __thresholdType || CV_THRESH_BINARY;

      var i, j, offset;

      for (i = height; i--; ) {
        for (j = width; j--; ) {
          offset = i * width + j;
          dData[offset] = threshouldType(sData[offset], __thresh, maxVal);
        }
      }
    } else {
      error(arguments.callee, UNSPPORT_DATA_TYPE /* {line} */);
    }

    return dst;
  };
  cv.threshold = threshold;

  /***********************************************
   *	<h2>Sobel</h2>
   *	Calculates the first, second, third, or mixed image derivatives using an extended Sobel operator.
   *	<b>Method</b>
   *	Mat Sobel(Mat src, int dx, int dy, int ksize=3, int borderType=CV_BORDER_REFLECT, Mat dst )
   *	<b>Parameters</b>
   *	src – input image.
   *	xorder – order of the derivative x.
   *	yorder – order of the derivative y.
   *	ksize – size of the extended Sobel kernel; it must be 1, 3, 5.
   *	borderType – Border type. When borderType==CV_BORDER_CONSTANT , the function always returns -1, regardless of p and len .
   *	dst – output Mat.
   */
  var Sobel = function (
    __src,
    __xorder,
    __yorder,
    __size,
    __borderType,
    __dst
  ) {
    (__src && __xorder ^ __yorder) ||
      error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    if (__src.type && __src.type === "CV_GRAY") {
      var kernel1,
        kernel2,
        height = __src.row,
        width = __src.col,
        dst = __dst || new Mat(height, width, CV_16I, 1),
        dstData = dst.data;
      size = __size || 3;
      switch (size) {
        case 1:
          size = 3;
        case 3:
          if (__xorder) {
            kernel = [-1, 0, 1, -2, 0, 2, -1, 0, 1];
          } else if (__yorder) {
            kernel = [-1, -2, -1, 0, 0, 0, 1, 2, 1];
          }
          break;
        case 5:
          if (__xorder) {
            kernel = [
              -1, -2, 0, 2, 1, -4, -8, 0, 8, 4, -6, -12, 0, 12, 6, -4, -8, 0, 8,
              4, -1, -2, 0, 2, 1,
            ];
          } else if (__yorder) {
            kernel = [
              -1, -4, -6, -4, -1, -2, -8, -12, -8, -2, 0, 0, 0, 0, 0, 2, 8, 12,
              8, 2, 1, 4, 6, 4, 1,
            ];
          }
          break;
        default:
          error(arguments.callee, UNSPPORT_SIZE /* {line} */);
      }

      GRAY216IC1Filter(
        __src,
        size,
        height,
        width,
        kernel,
        dstData,
        __borderType
      );
    } else {
      error(arguments.callee, UNSPPORT_DATA_TYPE /* {line} */);
    }
    return dst;
  };
  cv.Sobel = Sobel;

  //CV_GRAY to CV_16IC1 filter
  function GRAY216IC1Filter(
    __src,
    size,
    height,
    width,
    kernel,
    dstData,
    __borderType
  ) {
    var start = size >> 1;

    var withBorderMat = copyMakeBorder(__src, start, start, 0, 0, __borderType);

    var mData = withBorderMat.data,
      mWidth = withBorderMat.col;

    var i, j, y, x, c;
    var newValue, nowX, offsetY, offsetI;

    for (i = height; i--; ) {
      offsetI = i * width;
      for (j = width; j--; ) {
        newValue = 0;
        for (y = size; y--; ) {
          offsetY = (y + i) * mWidth;
          for (x = size; x--; ) {
            nowX = x + j;
            newValue += mData[offsetY + nowX] * kernel[y * size + x];
          }
        }
        dstData[j + offsetI] = newValue;
      }
    }
  }

  /***********************************************
   *	<h2>Laplacian</h2>
   *	Calculates the Laplacian of an image.
   *	<b>Method</b>
   *	Mat Laplacian(Mat src, int ksize=1, int borderType=CV_BORDER_REFLECT, Mat dst )
   *	<b>Parameters</b>
   *	src – input image.
   *	ksize – The aperture size used to compute the second-derivative filters. It must be 1, 3, 5.
   *	borderType – Border type. When borderType==CV_BORDER_CONSTANT , the function always returns -1, regardless of p and len .
   *	dst – output Mat.
   */
  var Laplacian = function (__src, __size, __borderType, __dst) {
    __src || error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    if (__src.type && __src.type === "CV_GRAY") {
      var kernel,
        height = __src.row,
        width = __src.col,
        dst = __dst || new Mat(height, width, CV_16I, 1),
        dstData = dst.data,
        size = __size || 3;
      switch (size) {
        case 1:
          kernel = [0, 1, 0, 1, -4, 1, 0, 1, 0];
          size = 3;
          break;
        case 3:
          kernel = [2, 0, 2, 0, -8, 0, 2, 0, 2];
          break;
        default:
          error(arguments.callee, UNSPPORT_SIZE /* {line} */);
      }

      GRAY216IC1Filter(
        __src,
        size,
        height,
        width,
        kernel,
        dstData,
        __borderType
      );
    } else {
      error(arguments.callee, UNSPPORT_DATA_TYPE /* {line} */);
    }
    return dst;
  };
  cv.Laplacian = Laplacian;

  /***********************************************
   *	<h2>Scharr</h2>
   *	Calculates the first x- or y- image derivative using Scharr operator.
   *	<b>Method</b>
   *	Mat Scharr(Mat src, int dx, int dy, int borderType=CV_BORDER_REFLECT, Mat dst )
   *	<b>Parameters</b>
   *	src – input image.
   *	xorder – order of the derivative x.
   *	yorder – order of the derivative y.
   *	borderType – Border type. When borderType==CV_BORDER_CONSTANT , the function always returns -1, regardless of p and len .
   *	dst – output Mat.
   */
  var Scharr = function (__src, __xorder, __yorder, __borderType, __dst) {
    (__src && __xorder ^ __yorder) ||
      error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    if (__src.type && __src.type === "CV_GRAY") {
      var kernel,
        height = __src.row,
        width = __src.col,
        dst = __dst || new Mat(height, width, CV_16I, 1),
        dstData = dst.data,
        size = 3;

      if (__xorder) {
        kernel = [-3, 0, 3, -10, 0, 10, -3, 0, 3];
      } else if (__yorder) {
        kernel = [-3, -10, -3, 0, 0, 0, 3, 10, 3];
      }

      GRAY216IC1Filter(
        __src,
        size,
        height,
        width,
        kernel,
        dstData,
        __borderType
      );
    } else {
      error(arguments.callee, UNSPPORT_DATA_TYPE /* {line} */);
    }
    return dst;
  };
  cv.Scharr = Scharr;

  /***********************************************
   *	<h2>remap</h2>
   *	Applies a generic geometrical transformation to an image.
   *	<b>Method</b>
   *	Mat remap(Mat src, Int32Array mapX, Int32Array mapY, Mat dst )
   *	Mat remap(Mat src, Function mapX, Function mapY, Mat dst )
   *	<b>Parameters</b>
   *	src – input image.
   *	mapX – The first map of x values.
   *	mapY – The second map of y values.
   *	dst – output Mat.
   */
  var remap = function (__src, __mapX, __mapY, __dst) {
    (__src && __mapX && __mapY) ||
      error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);

    if (__src.type !== "CV_RGBA")
      error(arguments.callee, UNSPPORT_DATA_TYPE /* {line} */);

    if (typeof __mapX === "function" && typeof __mapY === "function") {
      return remap4function(__src, __mapX, __mapY, __dst);
    } else if (__mapX instanceof Int32Arrray || __mapY instanceof Int32Array) {
      return remap4array(__src, __mapX, __mapY, __dst);
    } else {
      error(arguments.callee, UNSPPORT_DATA_TYPE /* {line} */);
      return __dst || __src;
    }
  };
  cv.remap = remap;
  //remap for array
  function remap4array(__src, __mapX, __mapY, __dst) {
    var height = __src.row,
      width = __src.col,
      sData = __src.data,
      dst = __dst || new Mat(height, width, CV_RGBA),
      dData = dst.data;

    var i, j, offset, mapset;

    for (j = height; j--; ) {
      for (i = width; i--; ) {
        offset = (j * width + i) << 2;
        mapset = (__mapY[i][j] * width + __mapX[i][j]) << 2;
        dData[offset] = sData[mapset];
        dData[offset + 1] = sData[mapset + 1];
        dData[offset + 2] = sData[mapset + 2];
        dData[offset + 3] = sData[mapset + 3];
      }
    }
    return dst;
  }
  //remap for function
  function remap4function(__src, __mapX, __mapY, __dst) {
    var height = __src.row,
      width = __src.col,
      sData = __src.data,
      dst = __dst || new Mat(height, width, CV_RGBA),
      dData = dst.data;

    var i, j, offset, mapset;

    for (j = height; j--; ) {
      for (i = width; i--; ) {
        offset = (j * width + i) << 2;
        mapset = (__mapY(i, j) * width + __mapX(i, j)) << 2;
        dData[offset] = sData[mapset];
        dData[offset + 1] = sData[mapset + 1];
        dData[offset + 2] = sData[mapset + 2];
        dData[offset + 3] = sData[mapset + 3];
      }
    }
    return dst;
  }

  /***********************************************
   *	<h2>getRotationArray2D</h2>
   *	Calculates the affine matrix of 2d rotation.
   *	<b>Method</b>
   *	Array getRotationArray2D(double angle)
   *	<b>Parameters</b>
   *	angle – The rotation angle in degrees.
   *	x -
   *	y -
   */
  var getRotationArray2D = function (__angle, __x, __y) {
    var sin = Math.sin(__angle) || 0,
      cos = Math.cos(__angle) || 1,
      x = __x || 0,
      y = __y || 0;

    return [cos, -sin, -x, sin, cos, -y];
  };
  cv.getRotationArray2D = getRotationArray2D;

  /***********************************************
   *	<h2>warpAffine</h2>
   *	Applies a generic geometrical transformation to an image.
   *	<b>Method</b>
   *	Mat warpAffine(Mat src, Array rotArray, Mat dst )
   *	<b>Parameters</b>
   *	src – input image.
   *	rotArray - the transformation matrix.
   *	dst – output Mat.
   */
  var warpAffine = function (__src, __rotArray, __dst) {
    (__src && __rotArray) ||
      error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    if (__src.type && __src.type === "CV_RGBA") {
      var height = __src.row,
        width = __src.col,
        dst = __dst || new Mat(height, width, CV_RGBA),
        sData = new Uint32Array(__src.buffer),
        dData = new Uint32Array(dst.buffer);

      var i, j, xs, ys, x, y, nowPix;

      for (j = 0, nowPix = 0; j < height; j++) {
        xs = __rotArray[1] * j + __rotArray[2];
        ys = __rotArray[4] * j + __rotArray[5];

        for (
          i = 0;
          i < width;
          i++, nowPix++, xs += __rotArray[0], ys += __rotArray[3]
        ) {
          if (xs > 0 && ys > 0 && xs < width && ys < height) {
            y = ys | 0;
            x = xs | 0;

            dData[nowPix] = sData[y * width + x];
          } else {
            dData[nowPix] = 4278190080; //Black
          }
        }
      }
    } else {
      error(arguments.callee, UNSPPORT_DATA_TYPE /* {line} */);
    }
    return dst;
  };
  cv.warpAffine = warpAffine;

  /***********************************************
   *	<h2>pyrDown</h2>
   *	Blurs an image and downsamples it.
   *	<b>Method</b>
   *	Mat pyrDown(Mat src, Mat dst )
   *	<b>Parameters</b>
   *	src – input image.
   *	dst – output Mat.
   */
  var pyrDown = function (__src, __dst) {
    __src || error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    if (__src.type && __src.type == "CV_RGBA") {
      var width = __src.col,
        height = __src.row,
        dWidth = ((width & 1) + width) / 2,
        dHeight = ((height & 1) + height) / 2,
        sData = __src.data,
        dst = __dst || new Mat(dHeight, dWidth, CV_RGBA),
        dstData = dst.data;

      var withBorderMat = copyMakeBorder(__src, 2, 2, 0, 0),
        mData = withBorderMat.data,
        mWidth = withBorderMat.col;

      var newValue, nowX, offsetY, offsetI, dOffsetI, i, j;

      var kernel = [
        1, 4, 6, 4, 1, 4, 16, 24, 16, 4, 6, 24, 36, 24, 6, 4, 16, 24, 16, 4, 1,
        4, 6, 4, 1,
      ];

      for (i = dHeight; i--; ) {
        dOffsetI = i * dWidth;
        for (j = dWidth; j--; ) {
          for (c = 3; c--; ) {
            newValue = 0;
            for (y = 5; y--; ) {
              offsetY = (y + i * 2) * mWidth * 4;
              for (x = 5; x--; ) {
                nowX = (x + j * 2) * 4 + c;
                newValue += mData[offsetY + nowX] * kernel[y * 5 + x];
              }
            }
            dstData[(j + dOffsetI) * 4 + c] = newValue / 256;
          }
          dstData[(j + dOffsetI) * 4 + 3] =
            mData[offsetY + 2 * mWidth * 4 + (j * 2 + 2) * 4 + 3];
        }
      }
    } else {
      error(arguments.callee, UNSPPORT_DATA_TYPE /* {line} */);
    }

    return dst;
  };
  cv.pyrDown = pyrDown;

  /***********************************************
   *	<h2>pyrUp</h2>
   *	Upsamples an image and then blurs it.
   *	<b>Method</b>
   *	Mat pyrUp(Mat src, Mat dst )
   *	<b>Parameters</b>
   *	src – input image.
   *	dst – output Mat.
   */
  var pyrUp = function (__src, __dst) {
    __src || error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    if (__src.type && __src.type == "CV_RGBA") {
      var width = __src.col,
        height = __src.row,
        dWidth = width * 2,
        dHeight = height * 2,
        sData = __src.data,
        dst = __dst || new Mat(dHeight, dWidth, CV_RGBA),
        dstData = dst.data;

      var withBorderMat = copyMakeBorder(__src, 2, 2, 0, 0),
        mData = withBorderMat.data,
        mWidth = withBorderMat.col;

      var newValue, nowX, offsetY, offsetI, dOffsetI, i, j;

      var kernel = [
        1, 4, 6, 4, 1, 4, 16, 24, 16, 4, 6, 24, 36, 24, 6, 4, 16, 24, 16, 4, 1,
        4, 6, 4, 1,
      ];

      for (i = dHeight; i--; ) {
        dOffsetI = i * dWidth;
        for (j = dWidth; j--; ) {
          for (c = 3; c--; ) {
            newValue = 0;
            for (y = 2 + (i & 1); y--; ) {
              offsetY = (y + ((i + 1) >> 1)) * mWidth * 4;
              for (x = 2 + (j & 1); x--; ) {
                nowX = (x + ((j + 1) >> 1)) * 4 + c;
                newValue +=
                  mData[offsetY + nowX] *
                  kernel[(y * 2 + ((i & 1) ^ 1)) * 5 + (x * 2 + ((j & 1) ^ 1))];
              }
            }
            dstData[(j + dOffsetI) * 4 + c] = newValue / 64;
          }
          dstData[(j + dOffsetI) * 4 + 3] =
            mData[offsetY + 2 * mWidth * 4 + (((j + 1) >> 1) + 2) * 4 + 3];
        }
      }
    } else {
      error(arguments.callee, UNSPPORT_DATA_TYPE /* {line} */);
    }

    return dst;
  };
  cv.pyrUp = pyrUp;

  /***********************************************
   *	<h2>dilate</h2>
   *	Dilates an image by using a specific structuring element.
   *	<b>Method</b>
   *	Mat dilate(Mat src, int size, int borderType, Mat dst )
   *	<b>Parameters</b>
   *	src – input image.
   *	size – Size of the structuring element.
   *	borderType – pixel extrapolation method.
   *	dst – output Mat.
   */
  var dilate = function (__src, __size, __borderType, __dst) {
    __src || error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    if (__src.type && __src.type == "CV_RGBA") {
      var width = __src.col,
        height = __src.row,
        size = __size || 3,
        dst = __dst || new Mat(height, width, CV_RGBA),
        dstData = dst.data;

      var start = size >> 1;
      var withBorderMat = copyMakeBorder(__src, -1, start, 0, 0, __borderType),
        mData = withBorderMat.data,
        mWidth = withBorderMat.col;

      var newOffset, total, nowX, offsetY, offsetI, nowOffset, i, j;

      if (size & (1 === 0)) {
        error(arguments.callee, UNSPPORT_SIZE /* {line} */);
        return __src;
      }

      for (i = height; i--; ) {
        offsetI = i * width;
        for (j = width; j--; ) {
          newOffset = 0;
          total = 0;
          offsetY = i * mWidth * 4;
          for (x = size; x--; ) {
            nowOffset = offsetY + (x + j) * 4;
            mData[nowOffset] + mData[nowOffset + 1] + mData[nowOffset + 2] >
              total &&
              (total =
                mData[nowOffset] +
                mData[nowOffset + 1] +
                mData[nowOffset + 2]) &&
              (newOffset = nowOffset);
          }
          dstData[(j + offsetI) * 4] = mData[newOffset];
          dstData[(j + offsetI) * 4 + 1] = mData[newOffset + 1];
          dstData[(j + offsetI) * 4 + 2] = mData[newOffset + 2];
          dstData[(j + offsetI) * 4 + 3] = mData[newOffset + 3];
        }
      }

      withBorderMat = copyMakeBorder(dst, start, -1, 0, 0, __borderType);
      mData = withBorderMat.data;
      mWidth = withBorderMat.col;

      for (i = height; i--; ) {
        offsetI = i * width;
        for (j = width; j--; ) {
          newOffset = 0;
          total = 0;
          for (y = size; y--; ) {
            nowOffset = (y + i) * mWidth * 4 + j * 4;
            mData[nowOffset] + mData[nowOffset + 1] + mData[nowOffset + 2] >
              total &&
              (total =
                mData[nowOffset] +
                mData[nowOffset + 1] +
                mData[nowOffset + 2]) &&
              (newOffset = nowOffset);
          }
          dstData[(j + offsetI) * 4] = mData[newOffset];
          dstData[(j + offsetI) * 4 + 1] = mData[newOffset + 1];
          dstData[(j + offsetI) * 4 + 2] = mData[newOffset + 2];
          dstData[(j + offsetI) * 4 + 3] = mData[newOffset + 3];
        }
      }
    } else {
      error(arguments.callee, UNSPPORT_DATA_TYPE /* {line} */);
    }
    return dst;
  };
  cv.dilate = dilate;

  var dilateGray = function (__src, __size, __dst) {
    __src || error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    var width = __src.col,
      height = __src.row,
      size = __size || 3,
      dst = __dst || new Mat(height, width, CV_GRAY),
      dstData = dst.data,
      srcData = __src.data;
    var newOffset, total, nowX, offsetY, offsetI, nowOffset, i, j;

    if (size & (1 === 0)) {
      error(arguments.callee, UNSPPORT_SIZE /* {line} */);
      return __src;
    }

    for (i = height; i--; ) {
      offsetI = i * width;
      for (j = width - 2; j--; ) {
        newOffset = 0;
        total = 0;
        for (x = size; x--; ) {
          nowOffset = offsetI + (x + j);
          srcData[nowOffset] > total &&
            (total = srcData[nowOffset]) &&
            (newOffset = nowOffset);
        }
        dstData[j + offsetI] = srcData[newOffset];
      }
    }
    return dst;
  };
  cv.dilateGray = dilateGray;

  /***********************************************
   *	<h2>erode</h2>
   *	Erodes an image by using a specific structuring element.
   *	<b>Method</b>
   *	Mat erode(Mat src, int size, int borderType, Mat dst )
   *	<b>Parameters</b>
   *	src – input image.
   *	size – Size of the structuring element.
   *	borderType – pixel extrapolation method.
   *	dst – output Mat.
   */
  var erode = function (__src, __size, __borderType, __dst) {
    __src || error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    if (__src.type && __src.type == "CV_RGBA") {
      var width = __src.col,
        height = __src.row,
        size = __size || 3,
        dst = __dst || new Mat(height, width, CV_RGBA),
        dstData = dst.data;

      var start = size >> 1;
      var withBorderMat = copyMakeBorder(__src, -1, start, 0, 0, __borderType),
        mData = withBorderMat.data,
        mWidth = withBorderMat.col;

      var newOffset, total, nowX, offsetY, offsetI, nowOffset, i, j;

      if (size & (1 === 0)) {
        error(arguments.callee, UNSPPORT_SIZE /* {line} */);
        return __src;
      }

      for (i = height; i--; ) {
        offsetI = i * width;
        for (j = width; j--; ) {
          newOffset = 0;
          total = 765;
          offsetY = i * mWidth * 4;
          for (x = size; x--; ) {
            nowOffset = offsetY + (x + j) * 4;
            mData[nowOffset] + mData[nowOffset + 1] + mData[nowOffset + 2] <
              total &&
              ((total =
                mData[nowOffset] +
                mData[nowOffset + 1] +
                mData[nowOffset + 2]) ||
                true) &&
              (newOffset = nowOffset);
          }
          dstData[(j + offsetI) * 4] = mData[newOffset];
          dstData[(j + offsetI) * 4 + 1] = mData[newOffset + 1];
          dstData[(j + offsetI) * 4 + 2] = mData[newOffset + 2];
          dstData[(j + offsetI) * 4 + 3] = mData[newOffset + 3];
        }
      }

      withBorderMat = copyMakeBorder(dst, start, -1, 0, 0, __borderType);
      mData = withBorderMat.data;
      mWidth = withBorderMat.col;

      for (i = height; i--; ) {
        offsetI = i * width;
        for (j = width; j--; ) {
          newOffset = 0;
          total = 765;
          for (y = size; y--; ) {
            nowOffset = (y + i) * mWidth * 4 + j * 4;
            mData[nowOffset] + mData[nowOffset + 1] + mData[nowOffset + 2] <
              total &&
              ((total =
                mData[nowOffset] +
                mData[nowOffset + 1] +
                mData[nowOffset + 2]) ||
                true) &&
              (newOffset = nowOffset);
          }
          dstData[(j + offsetI) * 4] = mData[newOffset];
          dstData[(j + offsetI) * 4 + 1] = mData[newOffset + 1];
          dstData[(j + offsetI) * 4 + 2] = mData[newOffset + 2];
          dstData[(j + offsetI) * 4 + 3] = mData[newOffset + 3];
        }
      }
    } else {
      error(arguments.callee, UNSPPORT_DATA_TYPE /* {line} */);
    }
    return dst;
  };
  cv.erode = erode;

  // 把图像尺寸缩小到0.5倍大小
  var imageShrink = function (__src, __dst) {
    __src || error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    var width = __src.col,
      height = __src.row,
      iHeight = Math.floor(height / 2), //目标图像高度
      iWidth = Math.floor(width / 2), //目标图像宽度
      srcData = __src.data;
    if (__src.type && __src.type == "CV_RGBA") {
      //CV_GRAY
      var dst = __dst || new Mat(iHeight, iWidth, CV_RGBA),
        dstData = dst.data;

      //彩色图的情况
      for (i = iHeight; i--; ) {
        var offsetId = i * iWidth,
          offsetIs = i * width * 2;
        for (j = iWidth; j--; ) {
          var newoffsetJd = (j + offsetId) * 4,
            newoffsetJs = (offsetIs + j * 2) * 4;
          dstData[newoffsetJd] = srcData[newoffsetJs];
          dstData[newoffsetJd + 1] = srcData[newoffsetJs + 1];
          dstData[newoffsetJd + 2] = srcData[newoffsetJs + 2];
          dstData[newoffsetJd + 3] = srcData[newoffsetJs + 3];
        }
      }
    } else {
      var dst = __dst || new Mat(iHeight, iWidth, CV_GRAY),
        dstData = dst.data;

      //灰度图的情况
      for (i = iHeight; i--; ) {
        var offsetId = i * iWidth,
          offsetIs = i * width * 2;
        for (j = iWidth; j--; )
          dstData[offsetId + j] = srcData[offsetIs + j * 2];
        //dstData[offsetId + j] = Math.max(srcData[offsetIs + j * 2], srcData[offsetIs + j * 2 + 1], srcData[offsetIs + width + j * 2], srcData[offsetIs + width + j * 2 + 1]);
      }
    }
    return dst;
  };
  cv.imageShrink = imageShrink;

  /*
   * 加黑边
   *
   */
  var blackborder = function (__src) {
    __src || error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    if (__src.type && __src.type == "CV_GRAY") {
      var width = __src.col,
        height = __src.row,
        sData = __src.data;
      var i, j, offset;

      for (i = height; i--; ) {
        offset = i * width;
        sData[offset] = 0;
        sData[offset + width - 1] = 0;
      }
      offset = height * width;
      for (i = width; i--; ) {
        sData[i] = 0;
        sData[offset - i - 1] = 0;
      }
    } else {
      error(arguments.callee, UNSPPORT_DATA_TYPE /* {line} */);
    }

    return __src;
  };
  cv.blackborder = blackborder;
  /***********************************************
   *	<h2>denoise</h2>
   *	二值图片中值滤波
   *	<b>Method</b>
   *	把小于指定面积的噪声点抹去
   *	<b>Parameters</b>
   *	src – input image.二值图片
   *	dst – output Mat.
   */
  var denoise = function (__src, __dst) {
    __src || error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    if (__src.type && __src.type == "CV_GRAY") {
      var width = __src.col,
        height = __src.row,
        dst = __dst || new Mat(height, width, CV_GRAY),
        dstData = dst.data,
        sData = __src.data;

      var newOffset, total, nowX, offsetY, offset, nowOffset, i, j;

      for (i = height - 1; i > 1; i--) {
        offset = i * width;
        for (j = width - 1; j > 1; j--) {
          var pixData = __src.at("uchar", j, i);
          if (pixData[0] === 255) {
            // 8邻域中的九个点，如果白点不少于4个则置为白点
            if (
              __src.at("uchar", j + 1, i + 1)[0] +
                __src.at("uchar", j, i + 1)[0] +
                __src.at("uchar", j + 1, i)[0] +
                __src.at("uchar", j - 1, i - 1)[0] +
                __src.at("uchar", j, i - 1)[0] +
                __src.at("uchar", j - 1, i)[0] +
                __src.at("uchar", j - 1, i + 1)[0] +
                __src.at("uchar", j + 1, i - 1)[0] >=
              1020
            )
              dstData[offset + j] = pixData[0];
          }
        }
      }
    } else {
      error(arguments.callee, UNSPPORT_DATA_TYPE /* {line} */);
    }
    return dst;
  };
  cv.denoise = denoise;

  /* 按照像素面积进行腐蚀。以8邻域方式判断联通像素构成的面积，小于areaSize的像素置0 
               x x x x x
               x 1 2 3 x
       8邻域： x 4 5 6 x
               x 7 8 9 x
               x x x x x
    */
  var erodeByArea = function (__src, areaSize, __dst) {
    __src || error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    if (__src.type && __src.type == "CV_GRAY") {
      var width = __src.col,
        height = __src.row,
        dst = __dst || new Mat(height, width, CV_GRAY),
        dstData = dst.data,
        srcData = __src.data;

      var pixDataRight, pixDataRightDown, pixDataDown, pixDataLeftDown;
      var pixDataLeft, pixDataLeftUp, pixDataUp, pixDataRightUp;
      for (i = height; i--; ) {
        var offset = i * width,
          offset1 = (i + 1) * width,
          offset2 = (i - 1) * width;
        for (j = width; j--; ) {
          var pixData = srcData[offset + j];
          // 当前像素是亮点才需判断和生长
          if (pixData === 255 && !dstData[offset + j]) {
            var counter = 1; // 记录生长时的当下面积（生长的像素数既是面积）
            var queuei = new Array(),
              queuej = new Array(), // 用两个队列记录生长的像素路径
              current = 0; // 队列中当前遍历元素的下标
            queuei[0] = i;
            queuej[0] = j;
            do {
              // 判断是否可以继续生长
              pixDataLeft =
                srcData[queuej[current] - 1 + queuei[current] * width];
              pixDataLeftUp =
                srcData[queuej[current] - 1 + (queuei[current] - 1) * width];
              pixDataUp =
                srcData[queuej[current] + (queuei[current] - 1) * width];
              pixDataRightUp =
                srcData[queuej[current] + 1 + (queuei[current] - 1) * width];
              pixDataRight =
                srcData[queuej[current] + 1 + queuei[current] * width];
              pixDataRightDown =
                srcData[queuej[current] + 1 + (queuei[current] + 1) * width];
              pixDataDown =
                srcData[queuej[current] + (queuei[current] + 1) * width];
              pixDataLeftDown =
                srcData[queuej[current] - 1 + (queuei[current] + 1) * width];

              // 如果是遍历到了黑边，读出的像素必然为0
              // 或者是遍历过的像素，则都要跳过
              // 否则表示可以继续生长，在dstData中记录遍历的像素和位置
              if (
                pixDataLeft &&
                !dstData[queuei[current] * width + queuej[current] - 1]
              ) {
                ++counter;
                queuej.push(queuej[current] - 1);
                queuei.push(queuei[current]);
                dstData[queuei[current] * width + queuej[current] - 1] = 1;
              }
              if (
                pixDataLeftUp &&
                !dstData[(queuei[current] - 1) * width + queuej[current] - 1]
              ) {
                ++counter;
                queuej.push(queuej[current] - 1);
                queuei.push(queuei[current] - 1);
                dstData[
                  (queuei[current] - 1) * width + queuej[current] - 1
                ] = 1;
              }
              if (
                pixDataUp &&
                !dstData[(queuei[current] - 1) * width + queuej[current]]
              ) {
                ++counter;
                queuej.push(queuej[current]);
                queuei.push(queuei[current] - 1);
                dstData[(queuei[current] - 1) * width + queuej[current]] = 1;
              }
              if (
                pixDataRightUp &&
                !dstData[(queuei[current] - 1) * width + queuej[current] + 1]
              ) {
                ++counter;
                queuej.push(queuej[current] + 1);
                queuei.push(queuei[current] - 1);
                dstData[
                  (queuei[current] - 1) * width + queuej[current] + 1
                ] = 1;
              }
              if (
                pixDataRight &&
                !dstData[queuei[current] * width + queuej[current] + 1]
              ) {
                ++counter;
                queuej.push(queuej[current] + 1);
                queuei.push(queuei[current]);
                dstData[queuei[current] * width + queuej[current] + 1] = 1;
              }
              if (
                pixDataRightDown &&
                !dstData[(queuei[current] + 1) * width + queuej[current] + 1]
              ) {
                ++counter;
                queuej.push(queuej[current] + 1);
                queuei.push(queuei[current] + 1);
                dstData[
                  (queuei[current] + 1) * width + queuej[current] + 1
                ] = 1;
              }
              if (
                pixDataDown &&
                !dstData[(queuei[current] + 1) * width + queuej[current]]
              ) {
                ++counter;
                queuej.push(queuej[current]);
                queuei.push(queuei[current] + 1);
                dstData[(queuei[current] + 1) * width + queuej[current]] = 1;
              }
              if (
                pixDataLeftDown &&
                !dstData[(queuei[current] + 1) * width + queuej[current] - 1]
              ) {
                ++counter;
                queuej.push(queuej[current] - 1);
                queuei.push(queuei[current] + 1);
                dstData[
                  (queuei[current] + 1) * width + queuej[current] - 1
                ] = 1;
              }
              ++current;
            } while (/*counter <= areaSize &&*/ queuei.length > current);

            if (counter <= areaSize) {
              // 面积小于areaSize，将srcData中遍历的像素全部置0
              for (var idx = 0; idx < queuei.length; ++idx) {
                srcData[queuei[idx] * width + queuej[idx]] = 0;
              }
            }
            //else
            //  面积必定大于areaSize，保留像素
            //}
          }
        }
      }
    } else {
      error(arguments.callee, UNSPPORT_DATA_TYPE /* {line} */);
    }
    return __src;
  };
  cv.erodeByArea = erodeByArea;

  var hough = function (__src, threshold, __dst) {
    __src || error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    if (__src.type && __src.type == "CV_GRAY") {
      var width = __src.col,
        height = __src.row,
        p, // 极坐标的半径
        iRMax = Math.round((width + height) * 2 + 1), // p的最大距离
        //pMax = new Array(180 * iRMax), // 累加器
        //pMax = new Mat(180 + 2, iRMax + 2, CV_GRAY), // 累加器
        //pMaxData = pMax.data,
        pMaxData = Int16Array((180 + 2) * (iRMax + 2)), // 累加器
        dst = __dst || new Mat(height, width, CV_GRAY),
        dstData = dst.data,
        srcData = __src.data;

      //做霍夫变换，填充累加器
      var fRate = Math.PI / 180;
      var offset;
      for (var i = height; i > 0; i--) {
        offset = i * width;
        for (var j = width; j > 0; j--) {
          if (srcData[offset + j]) {
            // 像素是白点，开始计算霍夫变换
            for (var angleStep = 0; angleStep < 180; angleStep++) {
              p =
                j * Math.cos(angleStep * fRate) +
                i * Math.sin(angleStep * fRate);
              p += (iRMax - 1) / 2; // 对p值优化防止为负
              pMaxData[Math.round((angleStep + 1) * (iRMax + 2) + p + 1)]++;
            }
          }
        }
      }
      // 找出大于阈值的局部极大值的直线
      var temp = new Array();
      for (var j = 0; j < iRMax; j++) {
        for (var i = 0; i < 180; i++) {
          offset = (i + 1) * (iRMax + 2) + j + 1;
          if (
            pMaxData[offset] > threshold &&
            pMaxData[offset] > pMaxData[offset - 1] &&
            pMaxData[offset] >= pMaxData[offset + 1] &&
            pMaxData[offset] > pMaxData[offset - (iRMax + 2)] &&
            pMaxData[offset] >= pMaxData[offset + (iRMax + 2)]
          ) {
            temp.push(i, j);
          }
        }
      }
      // 合并距离相近的直线
      //var result = new Array(), counter = 0;
      //for (var m = 0; m < temp.length; m = m + 2) {
      //    if (temp[m] > -1) {
      //        result[counter] = temp[m];
      //        result[counter + 1] = temp[m + 1];
      //        for (var n = m + 2; n < temp.length; n = n + 2) {
      //            if (temp[n] > -1) {
      //                if ((Math.abs(result[counter] - temp[n]) < 1)
      //                    && (Math.abs(result[counter + 1] - temp[n + 1]) < 100)) {
      //                    result[counter] = (result[counter] + temp[n]) / 2;
      //                    result[counter + 1] = (result[counter + 1] + temp[n + 1]) / 2;
      //                    temp[n] = temp[n + 1] = -1;
      //                }
      //            }
      //        }
      //        counter += 2;
      //    }
      //}

      var result = temp; //
      var counter = temp.length; //

      var x, y;
      for (var m = 0; m < counter; m = m + 2) {
        if (result[m] == 90) {
          // 水平线
          y = /*Math.round*/ result[m + 1] - (iRMax - 1) / 2; // / Math.sin(result[m] * fRate); 不用除了，因为sin恒为1
          for (var w = width; w--; ) dstData[y * width + w] = 255;
        } else {
          if (result[m] == 0) {
            // 垂直线
            x = /*Math.round*/ result[m + 1] - (iRMax - 1) / 2; // /Math.cos(result[m]*fRate); 不用除了，因为con恒为1
            for (var h = height; h--; ) dstData[h * width + x] = 255;
          } else {
            var k = Math.tan(result[m] * fRate);
            var b =
              (result[m + 1] - (iRMax - 1) / 2) / Math.sin(result[m] * fRate);
            for (var w = width; w--; ) {
              var idx = Math.round(-w / k + b);
              if (idx < height && idx > 0) dstData[idx * width + w] = 255;
            }
          }
        }
      }
      //与轮廓合并
      for (var i = height; i > 0; i--) {
        offset = i * width;
        for (var j = width; j > 0; j--)
          dstData[offset + j] = srcData[offset + j] && dstData[offset + j];
      }
    } else {
      error(arguments.callee, UNSPPORT_DATA_TYPE /* {line} */);
    }
    return dst;
  };
  cv.hough = hough;
  var hough2 = function (__src, threshold, __dst) {
    __src || error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    if (__src.type && __src.type == "CV_GRAY") {
      var width = __src.col,
        height = __src.row,
        p, // 极坐标的半径
        iRMax = Math.round((width + height) * 2 + 1), // p的最大距离
        pMaxData = new Int16Array((180 + 2) * (iRMax + 2)), // 累加器
        //dst = __dst || new Mat(height, width, CV_GRAY),
        //dstData = dst.data,
        srcData = __src.data;

      var fRate = Math.PI / 180;
      //预计算sin和cos
      var sinTab = new Float32Array(180),
        cosTab = new Float32Array(180);
      for (var angleStep = 0; angleStep < 180; angleStep++) {
        sinTab[angleStep] = Math.sin(angleStep * fRate);
        cosTab[angleStep] = Math.cos(angleStep * fRate);
      }
      //做霍夫变换，填充累加器
      var offset;
      for (var i = height; i > 0; i--) {
        offset = i * width;
        for (var j = width; j > 0; j--) {
          if (srcData[offset + j]) {
            // 像素是白点，开始计算霍夫变换
            for (var angleStep = 0; angleStep < 180; angleStep++) {
              p = j * cosTab[angleStep] + i * sinTab[angleStep];
              //p = j * Math.cos(angleStep * fRate) + i * Math.sin(angleStep * fRate);
              p += (iRMax - 1) / 2; // 对p值优化防止为负    p+=width;pMaxData[Math.round(angleStep*width*2*height+p)]++;
              pMaxData[Math.round((angleStep + 1) * (iRMax + 2) + p + 1)]++;
            }
          }
        }
      }
      // 找出大于阈值的局部极大值的直线
      var temp = new Array();
      for (var j = 0; j < iRMax; j++) {
        for (var i = 0; i < 180; i++) {
          offset = (i + 1) * (iRMax + 2) + j + 1;
          if (
            pMaxData[offset] > threshold &&
            pMaxData[offset] > pMaxData[offset - 1] &&
            pMaxData[offset] >= pMaxData[offset + 1] &&
            pMaxData[offset] > pMaxData[offset - (iRMax + 2)] &&
            pMaxData[offset] >= pMaxData[offset + (iRMax + 2)]
          ) {
            temp.push(i, j);
          }
        }
      }
      var result = temp; //

      //var line = new Array(); // 记录所有找到的直线，直线以两个端点坐标对的形式保存
      //var rho, theta, a, b, x, y;
      //for (var m = 0; m < result.length; m = m + 2) {
      //    if (result[m] == 90) { // 水平线
      //        y = Math.round(result[m + 1] - (iRMax - 1) / 2);// / Math.sin(result[m] * fRate); 不用除了，因为sin恒为1
      //        line.push(0, y, width - 1, y);//记录两点式坐标
      //    }
      //    else {
      //        if (result[m] == 0) { // 垂直线
      //            x = Math.round(result[m + 1] - (iRMax - 1) / 2);// /Math.cos(result[m]*fRate); 不用除了，因为con恒为1
      //            line.push(x, 0, x, height - 1);//记录两点式坐标
      //        }
      //        else {
      //            rho = result[m + 1]; theta = result[m];
      //            a = Math.cos(theta * fRate); b = Math.sin(theta * fRate);
      //            x = 0, y = Math.round(rho / b);
      //            if (y < 0)
      //                y = 0, x = Math.round(rho / a);
      //            if (y > height - 1)
      //                y = height - 1, x = Math.round((rho - y * b) / a);
      //            line.push(x, y);
      //            if (y == 0) {
      //                x = width - 1, y = Math.round((rho - x * a) / b);
      //                if (y < 0)
      //                    x = 0, y = Math.round(rho / b);
      //                if (y > height - 1)
      //                    y = height - 1, x = Math.round((rho - y * b) / a);
      //                line.push(x, y);
      //            }
      //            if (y == height - 1) {
      //                x = width - 1, y = Math.round((rho - x * a) / b);
      //                if (y < 0)
      //                    y = 0, x = Math.round(rho / a);
      //                if (y > height - 1)
      //                    y = 0, x = Math.round(rho / a);
      //                line.push(x, y);
      //            }
      //        }
      //    }
      //}

      var line = new Array(); // 记录所有找到的直线，直线以两个端点坐标对的形式保存
      var x, y;
      for (var m = 0; m < result.length; m = m + 2) {
        if (result[m] == 90) {
          // 水平线
          y = Math.round(result[m + 1] - (iRMax - 1) / 2); // / Math.sin(result[m] * fRate); 不用除了，因为sin恒为1
          line.push(0, y, width - 1, y); //记录两点式坐标
        } else {
          if (result[m] == 0) {
            // 垂直线
            x = Math.round(result[m + 1] - (iRMax - 1) / 2); // /Math.cos(result[m]*fRate); 不用除了，因为cos恒为1
            line.push(x, 0, x, height - 1); //记录两点式坐标
          } else {
            var k = Math.tan(result[m] * fRate);
            var b =
              (result[m + 1] - (iRMax - 1) / 2) / Math.sin(result[m] * fRate);
            var flag = 0,
              miny = 999999,
              minx = 0,
              maxy = 0,
              maxx = 0;
            for (var w = width - 1; w--; ) {
              y = Math.round(-w / k + b);
              if (y < height && y >= 0) {
                if (maxy < y) {
                  maxy = y;
                  maxx = w;
                }
                if (miny > y) {
                  miny = y;
                  minx = w;
                }
              }
            }
            line.push(minx, miny, maxx, maxy); //记录两点式坐标
          }
        }
      }
    } else {
      error(arguments.callee, UNSPPORT_DATA_TYPE /* {line} */);
    }
    return line;
  };
  cv.hough2 = hough2;

  // 根据轮廓图中白点数量自适应霍夫变换的阈值
  var ratio = function (__src) {
    __src || error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    if (__src.type && __src.type == "CV_GRAY") {
      var width = __src.col,
        height = __src.row,
        total = width * height, //图片总像素数
        white = 0, //图片中白点的数量
        i,
        j,
        srcData = __src.data;

      for (i = height; i--; ) {
        var offset = i * width;
        for (j = width; j--; ) if (srcData[offset + j] === 255) ++white;
      }
    } else {
      error(arguments.callee, UNSPPORT_DATA_TYPE /* {line} */);
    }
    return white / total;
  };
  cv.ratio = ratio;

  // 墙体识别，
  // 参数：
  //     lines：
  //     __src：轮廓图
  // 返回墙线图
  var recognizingWall = function (lines, __src) {
    // 先搜索垂直线，如果有2条以上的垂直线，
    //     如果相距最大距离超过图片宽度的1/10，取相距最大的为墙体的宽，
    //     搜索水平线
    //         如果有2条以上的水平线，
    //             如果相距最大距离超过图片宽度的1/10，取相距最大的为墙体的高   @5面墙，对面墙、地、顶、两侧墙
    //         如果有1条水平线或相距最大距离不超过图片宽度的1/10，则合并为1条水平线
    //                 计算水平与图片上下边的距离，取大的为墙体的高             #4面墙，对面墙、地或顶、两侧墙
    //                     搜索水平线上垂直线相交处是否有斜线，找出侧墙
    // 如果只有1条垂直线或相距最大距离不超过图片宽度的1/10，则合并为1条垂直线，
    //     搜索与该垂直相交的斜线
    //         如果有2对以上的对八字斜线，则垂直线为最远的墙角                  ￥4面墙，交点之间的垂直线为墙高，两侧墙、地、顶
    //         只有上/下一对八字斜线，则垂直线为最远的墙角                      %3面墙，墙高未知，两侧墙，地或顶
    //         只有左/右一对八字斜线或上下异侧各一条斜线，则垂直线为最远的墙角  ￥4面墙，交点之间的垂直线为墙高，两侧墙、地、顶
    //         只有一条斜线，则垂直线为最远的墙角                               %3面墙，墙高未知，两侧墙，地或顶
    //     搜索水平线
    //         两条水平线，                                                     @5
    //         一条水平线，                                                     +4面墙，@的变体，对面墙、一侧墙、地或顶
    //         没有，                                                           *2面墙，两侧，墙高未知
    // 没有垂直线，搜索水平线
    //      只有一条水平线，或合并后只有一条水平线，搜索上方或下方相对且斜率相近的一对斜线
    //          如果有4条，则4面墙  #地或顶、接地或顶的对面墙因为拍摄角度而发生畸变（变成梯形）、两侧墙
    //          如果有2条，则4面墙  #同上
    //      两条水平线，搜索斜线
    // 没有垂直线，也没有水平线，搜索斜线
    //     有对角的八字线，推断垂直或水平线位置
    //     只有一条线、或平行线，无解
    var verticalLines = new Array(), //垂直线，两点式，4个坐标，1个分值（分数1-10），即五元组数组
      horizontalLine = new Array(), //水平线
      width = __src.col,
      height = __src.row,
      //dst = __dst || new Mat(height, width, CV_GRAY),
      //dstData = dst.data,
      srcData = __src.data;
    var step = 50;

    ///////////////////////////////////////////////////////////////////////////
    ////////////// 找出所有垂直线和近垂直线（水平线和近水平线）////////////////
    for (var m = 0; m < lines.length; m = m + 4) {
      if (lines[m] - lines[m + 2] == 0) {
        //绝对垂直线
        verticalLines.push(
          lines[m],
          lines[m + 1],
          lines[m + 2],
          lines[m + 3],
          1
        );
        lines[m] = lines[m + 1] = lines[m + 2] = lines[m + 3] = 0;
      } else if (lines[m + 1] - lines[m + 3] == 0) {
        //绝对水平线
        horizontalLine.push(
          lines[m],
          lines[m + 1],
          lines[m + 2],
          lines[m + 3],
          1
        );
        lines[m] = lines[m + 1] = lines[m + 2] = lines[m + 3] = 0;
      } else if (
        Math.abs(lines[m] - lines[m + 2] /* (lines[m + 1] - lines[m + 3])*/) <
        width / 30
      ) {
        //近似垂直
        // TODO: 可以把两点的x坐标取中，变成严格垂直线
        verticalLines.push(
          lines[m],
          lines[m + 1],
          lines[m + 2],
          lines[m + 3],
          1
        );
        lines[m] = lines[m + 1] = lines[m + 2] = lines[m + 3] = 0;
      } else if (
        Math.abs(lines[m + 1] - lines[m + 3] /* (lines[m] - lines[m + 2])*/) <
        height / 30
      ) {
        //近似水平
        // TODO: 可以把两点的y坐标取中，变成严格水平线
        horizontalLine.push(
          lines[m],
          lines[m + 1],
          lines[m + 2],
          lines[m + 3],
          1
        );
        lines[m] = lines[m + 1] = lines[m + 2] = lines[m + 3] = 0;
      }
    }
    //////////////////////////////////////////////////////////////////////////

    var crossPoints = findCrossPoint(lines, width, height);

    ////////////////////////////////////////////////////////////////////////////
    // 遍历所有相交斜线，找出相对的两个八字交叉斜线配一个直线。十拿九稳￥4面墙，交点之间的垂直线为墙高，两侧墙、地、顶
    var resultLines = new Array();
    var flag = false; //是否识别出来了
    for (var i = 0; i < crossPoints.length; i = i + 11) {
      if (flag) break;
      var x1 = crossPoints[i],
        y1 = crossPoints[i + 1]; //交点
      var upPoints = new Array(); //四个点两条线：l1x1、l1y1、l1x2、l1y2、l2x1、l2y1、l2x2、l2y2
      upPoints.push(
        crossPoints[i + 2],
        crossPoints[i + 3],
        crossPoints[i + 4],
        crossPoints[i + 5],
        crossPoints[i + 6],
        crossPoints[i + 7],
        crossPoints[i + 8],
        crossPoints[i + 9]
      );
      for (var j = i + 11; j < crossPoints.length; j = j + 11) {
        var x2 = crossPoints[j],
          y2 = crossPoints[j + 1]; //交点
        if (
          Math.abs(x1 - x2) < width / step &&
          Math.abs(y1 - y2) > height / 3
        ) {
          //是垂直相对的两个八字交叉斜线
          var downPoints = new Array();
          downPoints.push(
            crossPoints[j + 2],
            crossPoints[j + 3],
            crossPoints[j + 4],
            crossPoints[j + 5],
            crossPoints[j + 6],
            crossPoints[j + 7],
            crossPoints[j + 8],
            crossPoints[j + 9]
          );
          flag = true;
          resultLines.push(x1, y1, x2, y2); //记录垂直线
          if (y1 > y2) {
            //需要倒一下个
            var tPoints = new Array();
            tPoints.push(
              upPoints[0],
              upPoints[1],
              upPoints[2],
              upPoints[3],
              upPoints[4],
              upPoints[5],
              upPoints[6],
              upPoints[7]
            );
            for (var m = upPoints.length; m--; ) upPoints[m] = downPoints[m];
            for (var m = downPoints.length; m--; ) downPoints[m] = tPoints[m];
            var tx = x1,
              ty = y1;
            x1 = x2;
            y1 = y2;
            x2 = tx;
            y2 = ty;
          }
          var k1 = (upPoints[3] - upPoints[1]) / (upPoints[2] - upPoints[0]); //(l1y2 - l1y1) / (l1x2 - l1x1);
          //var b1 = l1x1 * (l1y2 - l1y1) / (l1x2 - l1x1) + l1y1;
          if (k1 < 0) {
            //需要倒一下个
            var tPoints = new Array();
            tPoints.push(upPoints[0], upPoints[1], upPoints[2], upPoints[3]);
            upPoints[0] = upPoints[4];
            upPoints[1] = upPoints[5];
            upPoints[2] = upPoints[6];
            upPoints[3] = upPoints[7];
            upPoints[4] = tPoints[0];
            upPoints[5] = tPoints[1];
            upPoints[6] = tPoints[2];
            upPoints[7] = tPoints[3];
            k1 = (upPoints[3] - upPoints[1]) / (upPoints[2] - upPoints[0]);
          }
          //左上斜线
          //斜线的一个点就是交点，根据斜率求斜线的另一个点
          var y = (0 - x1) * k1 + y1; //y=(x-1x)*(2y-1y)/(2x-1x)+1y
          if (y >= 0) resultLines.push(x1, y1, 0, y);
          else resultLines.push(x1, y1, -y1 / k1 + x1, 0); //x=(y-1y)/k1+1x
          //k1>0,k2必然<0，求右上斜线
          var k2 = (upPoints[7] - y1) / (upPoints[6] - x1);
          y = (width - x1) * k2 + y1;
          if (y >= 0) resultLines.push(x1, y1, width, y);
          else resultLines.push(x1, y1, -y1 / k2 + x1, 0);

          var k3 =
            (downPoints[3] - downPoints[1]) / (downPoints[2] - downPoints[0]); //(l3y2 - y2) / (l3x2 - x2);
          if (k3 < 0) {
            //需要倒一下个
            var tPoints = new Array();
            tPoints.push(
              downPoints[0],
              downPoints[1],
              downPoints[2],
              downPoints[3]
            );
            downPoints[0] = downPoints[4];
            downPoints[1] = downPoints[5];
            downPoints[2] = downPoints[6];
            downPoints[3] = downPoints[7];
            downPoints[4] = tPoints[0];
            downPoints[5] = tPoints[1];
            downPoints[6] = tPoints[2];
            downPoints[7] = tPoints[3];
            k3 =
              (downPoints[3] - downPoints[1]) / (downPoints[2] - upPoints[0]);
          }
          //右下斜线
          y = (width - x2) * k3 + y2;
          if (y <= height) resultLines.push(x2, y2, width, y);
          else resultLines.push(x2, y2, (height - y2) / k3 + x2, height);
          //求左下斜线
          var k4 = (downPoints[7] - y2) / (downPoints[6] - x2);
          y = (0 - x2) * k4 + y2;
          if (y <= height) resultLines.push(x2, y2, 0, y);
          else resultLines.push(x2, y2, (height - y2) / k4 + x2, height);
          break;
        }
        if (
          Math.abs(y1 - y2) < height / step &&
          Math.abs(x1 - x2) > width / 3
        ) {
          //是水平相对的两个八字交叉斜线
          var downPoints = new Array(); //这里把upPoints当作左点，downPoints当作右点
          downPoints.push(
            crossPoints[j + 2],
            crossPoints[j + 3],
            crossPoints[j + 4],
            crossPoints[j + 5],
            crossPoints[j + 6],
            crossPoints[j + 7],
            crossPoints[j + 8],
            crossPoints[j + 9]
          );
          flag = true;
          resultLines.push(x1, y1, x2, y2); //记录水平线
          if (x1 > x2) {
            //需要倒一下个
            var tPoints = new Array();
            tPoints.push(
              upPoints[0],
              upPoints[1],
              upPoints[2],
              upPoints[3],
              upPoints[4],
              upPoints[5],
              upPoints[6],
              upPoints[7]
            );
            for (var m = upPoints.length; m--; ) upPoints[m] = downPoints[m];
            for (var m = downPoints.length; m--; ) downPoints[m] = tPoints[m];
            var tx = x1,
              ty = y1;
            x1 = x2;
            y1 = y2;
            x2 = tx;
            y2 = ty;
          }
          var k1 = (upPoints[3] - upPoints[1]) / (upPoints[2] - upPoints[0]); //(l1y2 - l1y1) / (l1x2 - l1x1);
          //var b1 = l1x1 * (l1y2 - l1y1) / (l1x2 - l1x1) + l1y1;
          if (k1 < 0) {
            //需要倒一下个
            var tPoints = new Array();
            tPoints.push(upPoints[0], upPoints[1], upPoints[2], upPoints[3]);
            upPoints[0] = upPoints[4];
            upPoints[1] = upPoints[5];
            upPoints[2] = upPoints[6];
            upPoints[3] = upPoints[7];
            upPoints[4] = tPoints[0];
            upPoints[5] = tPoints[1];
            upPoints[6] = tPoints[2];
            upPoints[7] = tPoints[3];
            k1 = (upPoints[3] - upPoints[1]) / (upPoints[2] - upPoints[0]);
          }
          //左上斜线
          //斜线的一个点就是交点，根据斜率求斜线的另一个点
          var y = (0 - x1) * k1 + y1; //y=(x-1x)*(2y-1y)/(2x-1x)+1y
          if (y >= 0) resultLines.push(x1, y1, 0, y);
          else resultLines.push(x1, y1, -y1 / k1 + x1, 0); //x=(y-1y)/k1+1x
          //k1>0,k2必然<0，求左下斜线
          var k2 = (upPoints[7] - y1) / (upPoints[6] - x1);
          y = (0 - x1) * k2 + y1;
          if (y <= height) resultLines.push(x1, y1, 0, y);
          else resultLines.push(x1, y1, (height - y1) / k2 + x1, height);

          var k3 =
            (downPoints[3] - downPoints[1]) / (downPoints[2] - downPoints[0]); //(l3y2 - y2) / (l3x2 - x2);
          if (k3 < 0) {
            //需要倒一下个
            var tPoints = new Array();
            tPoints.push(
              downPoints[0],
              downPoints[1],
              downPoints[2],
              downPoints[3]
            );
            downPoints[0] = downPoints[4];
            downPoints[1] = downPoints[5];
            downPoints[2] = downPoints[6];
            downPoints[3] = downPoints[7];
            downPoints[4] = tPoints[0];
            downPoints[5] = tPoints[1];
            downPoints[6] = tPoints[2];
            downPoints[7] = tPoints[3];
            k3 =
              (downPoints[3] - downPoints[1]) / (downPoints[2] - upPoints[0]);
          }
          //右下斜线
          y = (width - x2) * k3 + y2;
          if (y <= height) resultLines.push(x2, y2, width, y);
          else resultLines.push(x2, y2, (height - y2) / k3 + x2, height);
          //求右上斜线
          var k4 = (downPoints[7] - y2) / (downPoints[6] - x2);
          y = (width - x2) * k4 + y2;
          if (y >= 0) resultLines.push(x2, y2, width, y);
          else resultLines.push(x2, y2, (0 - y2) / k4 + x2, 0);
          break;
        }
      }
    }
    if (flag) {
      //匹配上了
      return resultLines;
    }
    //////////////////////////////////////////////////////////////////////////

    //////////////////////////////////////////////////////////////////////////
    // 搜索垂直线和水平线，找出最左最右的垂直和最上最下的水平线
    var leftX = 99999,
      leftIdx = -1,
      rightX = 0,
      rightIdx = -1; //找出最左和最右的垂直线,及其在verticalLines里的位置
    for (var i = 0; i < verticalLines.length; i = i + 5) {
      if (leftX > verticalLines[i] && verticalLines[i] <= width / 2) {
        leftX = verticalLines[i];
        leftIdx = i;
      }
      if (rightX < verticalLines[i] && verticalLines[i] > width / 2) {
        rightX = verticalLines[i];
        rightIdx = i;
      }
    }
    var topX = 99999,
      topIdx = -1,
      bottomX = 0,
      bottomIdx = -1; //找出最上和最下的垂直线，及其在horizontalLine里的位置
    for (var i = 0; i < horizontalLine.length; i = i + 5) {
      if (topX > horizontalLine[i + 1] && horizontalLine[i + 1] <= height / 2) {
        topX = horizontalLine[i + 1];
        topIdx = i;
      }
      if (
        bottomX < horizontalLine[i + 1] &&
        horizontalLine[i + 1] > height / 2
      ) {
        bottomX = horizontalLine[i + 1];
        bottomIdx = i;
      }
    }
    //////////////////////////////////////////////////////////////////////

    //////////////////////////////////////////////////////////////////////
    // 如果两垂直线，或两水平线距离不超过图片尺寸的1/4，极有可能是干扰，如窗户。删掉这样的线
    // TODO: 先不做
    //////////////////////////////////////////////////////////////////////

    //////////////////////////////////////////////////////////////////////////
    // #4面墙，或@5面墙，识别时丢了一条线
    // 矩形三边识别出来了，八成是它了。需要补上缺失的一边（如果有相交的斜线，可能是丢线了；没有斜线，也可能就是没有，可以把图片边缘看作是丢掉的线。）
    // 但没考虑如果这个矩形面积很小，可能是干扰
    if (topIdx > -1 && bottomIdx > -1 && leftIdx > -1 && rightIdx == -1) {
      // 缺失右垂直线，寻找与上下水平线相交的斜线，斜线相交位置必须 > width/2
      rightIdx = verticalLines.length;
      verticalLines.push(width - 10, 0, width - 10, height, -7); //先随意补一个直线，位置先放到图片边缘处
      // 再修正补上的直线
      for (var m = 0; m < lines.length; m = m + 4) {
        //因为这里是猜，带有任意成分，所以就以找到的第一个符合条件的相交斜线为准
        if (
          !(
            lines[m] == 0 &&
            lines[m + 1] == 0 &&
            lines[m + 2] == 0 &&
            lines[m + 3] == 0
          )
        ) {
          //不是被删掉的线,那就是斜线了
          var k = (lines[m + 3] - lines[m + 1]) / (lines[m + 2] - lines[m]);
          if (k < 0) {
            var temp = intersection(
              lines[m],
              lines[m + 1],
              lines[m + 2],
              lines[m + 3],
              horizontalLine[topIdx],
              horizontalLine[topIdx + 1],
              horizontalLine[topIdx + 2],
              horizontalLine[topIdx + 3],
              2,
              width,
              height
            );
            if (
              temp.x >= width / 2 &&
              temp.y >= 0 &&
              temp.x <= width &&
              temp.y <= height / 2
            ) {
              verticalLines[rightIdx] = temp.x;
              verticalLines[rightIdx + 1] = 0;
              verticalLines[rightIdx + 2] = temp.x;
              verticalLines[rightIdx + 2] = height;
              break;
            }
          } else {
            var temp = intersection(
              lines[m],
              lines[m + 1],
              lines[m + 2],
              lines[m + 3],
              horizontalLine[bottomIdx],
              horizontalLine[bottomIdx + 1],
              horizontalLine[bottomIdx + 2],
              horizontalLine[bottomIdx + 3],
              2,
              width,
              height
            );
            if (
              temp.x >= width / 2 &&
              temp.y >= height / 2 &&
              temp.x <= width &&
              temp.y <= height
            ) {
              verticalLines[rightIdx] = temp.x;
              verticalLines[rightIdx + 1] = 0;
              verticalLines[rightIdx + 2] = temp.x;
              verticalLines[rightIdx + 2] = height;
              break;
            }
          }
        }
      }
    }
    if (topIdx > -1 && bottomIdx > -1 && leftIdx == -1 && rightIdx > -1) {
      // 缺失左垂直线，寻找与上下水平线相交的斜线，斜线相交位置必须 < width/2
      leftIdx = verticalLines.length;
      verticalLines.push(10, 0, 10, height, -7); //先随意补一个直线，位置先放到图片边缘处
      // 再修正补上的直线
      for (var m = 0; m < lines.length; m = m + 4) {
        if (
          !(
            lines[m] == 0 &&
            lines[m + 1] == 0 &&
            lines[m + 2] == 0 &&
            lines[m + 3] == 0
          )
        ) {
          //不是被删掉的线,那就是斜线了
          var k = (lines[m + 3] - lines[m + 1]) / (lines[m + 2] - lines[m]);
          if (k > 0) {
            var temp = intersection(
              lines[m],
              lines[m + 1],
              lines[m + 2],
              lines[m + 3],
              horizontalLine[topIdx],
              horizontalLine[topIdx + 1],
              horizontalLine[topIdx + 2],
              horizontalLine[topIdx + 3],
              2,
              width,
              height
            );
            if (
              temp.x >= 0 &&
              temp.y >= 0 &&
              temp.x <= width / 2 &&
              temp.y <= height / 2
            ) {
              verticalLines[leftIdx] = temp.x;
              verticalLines[leftIdx + 1] = 0;
              verticalLines[leftIdx + 2] = temp.x;
              verticalLines[leftIdx + 2] = height;
              break;
            }
          } else {
            var temp = intersection(
              lines[m],
              lines[m + 1],
              lines[m + 2],
              lines[m + 3],
              horizontalLine[bottomIdx],
              horizontalLine[bottomIdx + 1],
              horizontalLine[bottomIdx + 2],
              horizontalLine[bottomIdx + 3],
              2,
              width,
              height
            );
            if (
              temp.x >= 0 &&
              temp.y >= height / 2 &&
              temp.x <= width / 2 &&
              temp.y <= height
            ) {
              verticalLines[leftIdx] = temp.x;
              verticalLines[leftIdx + 1] = 0;
              verticalLines[leftIdx + 2] = temp.x;
              verticalLines[leftIdx + 2] = height;
              break;
            }
          }
        }
      }
    }
    if (topIdx > -1 && bottomIdx == -1 && leftIdx > -1 && rightIdx > -1) {
      bottomIdx = horizontalLine.length;
      horizontalLine.push(0, height - 10, width, height - 10, -7); //先随意补一个直线，位置先放到图片边缘处
      // 再修正补上的直线
      for (var m = 0; m < lines.length; m = m + 4) {
        if (
          !(
            lines[m] == 0 &&
            lines[m + 1] == 0 &&
            lines[m + 2] == 0 &&
            lines[m + 3] == 0
          )
        ) {
          //不是被删掉的线,那就是斜线了
          var k = (lines[m + 3] - lines[m + 1]) / (lines[m + 2] - lines[m]);
          if (k < 0) {
            var temp = intersection(
              lines[m],
              lines[m + 1],
              lines[m + 2],
              lines[m + 3],
              verticalLines[leftIdx],
              verticalLines[leftIdx + 1],
              verticalLines[leftIdx + 2],
              verticalLines[leftIdx + 3],
              1,
              width,
              height
            );
            if (
              temp.x >= 0 &&
              temp.y >= height / 2 &&
              temp.x <= width / 2 &&
              temp.y <= height
            ) {
              horizontalLine[bottomIdx] = 0;
              horizontalLine[bottomIdx + 1] = temp.y;
              horizontalLine[bottomIdx + 2] = width;
              horizontalLine[bottomIdx + 2] = temp.y;
              break;
            }
          } else {
            var temp = intersection(
              lines[m],
              lines[m + 1],
              lines[m + 2],
              lines[m + 3],
              verticalLines[rightIdx],
              verticalLines[rightIdx + 1],
              verticalLines[rightIdx + 2],
              verticalLines[rightIdx + 3],
              1,
              width,
              height
            );
            if (
              temp.x >= width / 2 &&
              temp.y >= height / 2 &&
              temp.x <= width &&
              temp.y <= height
            ) {
              horizontalLine[bottomIdx] = 0;
              horizontalLine[bottomIdx + 1] = temp.y;
              horizontalLine[bottomIdx + 2] = width;
              horizontalLine[bottomIdx + 2] = temp.y;
              break;
            }
          }
        }
      }
    }
    if (topIdx == -1 && bottomIdx > -1 && leftIdx > -1 && rightIdx > -1) {
      topIdx = horizontalLine.length;
      horizontalLine.push(0, 10, width, 10, -7); //先随意补一个直线，位置先放到图片边缘处
      // 再修正补上的直线
      for (var m = 0; m < lines.length; m = m + 4) {
        if (
          !(
            lines[m] == 0 &&
            lines[m + 1] == 0 &&
            lines[m + 2] == 0 &&
            lines[m + 3] == 0
          )
        ) {
          //不是被删掉的线,那就是斜线了
          var k = (lines[m + 3] - lines[m + 1]) / (lines[m + 2] - lines[m]);
          if (k > 0) {
            var temp = intersection(
              lines[m],
              lines[m + 1],
              lines[m + 2],
              lines[m + 3],
              verticalLines[leftIdx],
              verticalLines[leftIdx + 1],
              verticalLines[leftIdx + 2],
              verticalLines[leftIdx + 3],
              1,
              width,
              height
            );
            if (
              temp.x >= 0 &&
              temp.y >= 0 &&
              temp.x <= width / 2 &&
              temp.y <= height / 2
            ) {
              horizontalLine[topIdx] = 0;
              horizontalLine[topIdx + 1] = temp.y;
              horizontalLine[topIdx + 2] = width;
              horizontalLine[topIdx + 2] = temp.y;
              break;
            }
          } else {
            var temp = intersection(
              lines[m],
              lines[m + 1],
              lines[m + 2],
              lines[m + 3],
              verticalLines[rightIdx],
              verticalLines[rightIdx + 1],
              verticalLines[rightIdx + 2],
              verticalLines[rightIdx + 3],
              1,
              width,
              height
            );
            if (
              temp.x >= width / 2 &&
              temp.y >= 0 &&
              temp.x <= width &&
              temp.y <= height / 2
            ) {
              horizontalLine[topIdx] = 0;
              horizontalLine[topIdx + 1] = temp.y;
              horizontalLine[topIdx + 2] = width;
              horizontalLine[topIdx + 2] = temp.y;
              break;
            }
          }
        }
      }
    }
    //////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////
    // 矩形四边识别出来了，十拿九稳就是它了。
    // 但没考虑如果这个矩形面积很小，可能是干扰
    if (topIdx > -1 && bottomIdx > -1 && leftIdx > -1 && rightIdx > -1) {
      flag = true;
      // 主墙壁线是个矩形
      var leftTopX = (verticalLines[leftIdx] + verticalLines[leftIdx + 2]) / 2,
        leftTopY =
          (horizontalLine[topIdx + 1] + horizontalLine[topIdx + 3]) / 2,
        leftBottomX = leftTopX,
        leftBottomY =
          (horizontalLine[bottomIdx + 1] + horizontalLine[bottomIdx + 3]) / 2,
        rightTopX = (verticalLines[rightIdx] + verticalLines[rightIdx + 2]) / 2,
        rightTopY = leftTopY,
        rightBottomX = rightTopX,
        rightBottomY = leftBottomY;
      resultLines.push(leftTopX, leftTopY, leftBottomX, leftBottomY);
      resultLines.push(rightTopX, rightTopY, rightBottomX, rightBottomY);
      resultLines.push(leftTopX, leftTopY, rightTopX, rightTopY);
      resultLines.push(leftBottomX, leftBottomY, rightBottomX, rightBottomY);
      // 遍历所有的斜线，在交点附近找主墙壁之外的线，没有则补齐
      var leftTop = (leftBottom = rightTop = rightBottom = true); //是否找到斜线，true是没有找到
      for (var m = 0; m < lines.length; m = m + 4) {
        if (
          !(
            lines[m] == 0 &&
            lines[m + 1] == 0 &&
            lines[m + 2] == 0 &&
            lines[m + 3] == 0
          )
        ) {
          //不是被删掉的线,那就是斜线了
          var k = (lines[m + 3] - lines[m + 1]) / (lines[m + 2] - lines[m]);
          var b = -lines[m] * k + lines[m + 1];
          if (k > 0) {
            // 计算与左垂直线的交点
            var temp = intersection(
              lines[m],
              lines[m + 1],
              lines[m + 2],
              lines[m + 3],
              leftTopX,
              leftTopY,
              leftBottomX,
              leftBottomY,
              1,
              width,
              height
            );
            if (
              leftTop &&
              temp.y >= 0 &&
              temp.y <= height &&
              Math.abs(temp.y - leftTopY) < 50
            ) {
              // 找到了左上角相交的斜线
              leftTop = false; //如果有多条斜线经过交点，以第一次找到的斜线为准
              if (b > 0) resultLines.push(leftTopX, leftTopY, 0, b);
              else resultLines.push(leftTopX, leftTopY, -b / k, 0);
            }
            // 计算与右垂直线的交点
            var temp = intersection(
              lines[m],
              lines[m + 1],
              lines[m + 2],
              lines[m + 3],
              rightTopX,
              rightTopY,
              rightBottomX,
              rightBottomY,
              1,
              width,
              height
            );
            if (
              rightBottom &&
              temp.y >= 0 &&
              temp.y <= height &&
              Math.abs(temp.y - rightBottomY) < 50
            ) {
              // 找到了右下角相交的斜线
              rightBottom = false;
              var y = k * width + b;
              if (y >= height)
                resultLines.push(
                  rightBottomX,
                  rightBottomY,
                  (height - b) / k,
                  height
                );
              else resultLines.push(rightBottomX, rightBottomY, width, y);
            }
          } else {
            // 计算与左垂直线的交点
            var temp = intersection(
              lines[m],
              lines[m + 1],
              lines[m + 2],
              lines[m + 3],
              leftTopX,
              leftTopY,
              leftBottomX,
              leftBottomY,
              1,
              width,
              height
            );
            if (
              leftBottom &&
              temp.y >= 0 &&
              temp.y <= height &&
              Math.abs(temp.y - leftBottomY) < 50
            ) {
              // 找到了左下角相交的斜线
              leftBottom = false;
              if (b < height) resultLines.push(leftBottomX, leftBottomY, 0, b);
              else
                resultLines.push(
                  leftBottomX,
                  leftBottomY,
                  (height - b) / k,
                  height
                );
            }
            // 计算与右垂直线的交点
            var temp = intersection(
              lines[m],
              lines[m + 1],
              lines[m + 2],
              lines[m + 3],
              rightTopX,
              rightTopY,
              rightBottomX,
              rightBottomY,
              1,
              width,
              height
            );
            if (
              rightTop &&
              temp.y >= 0 &&
              temp.y <= height &&
              Math.abs(temp.y - rightTopY) < 50
            ) {
              // 找到了右上角相交的斜线
              rightTop = false;
              var y = k * width + b;
              if (y > 0) resultLines.push(rightTopX, rightTopY, width, y);
              else resultLines.push(rightTopX, rightTopY, (0 - b) / k, 0);
            }
          }
        }
      }
      // 补上缺失的斜线
      if (leftTop) resultLines.push(leftTopX, leftTopY, 0, 0);
      if (rightTop) resultLines.push(rightTopX, rightTopY, width, 0);
      if (leftBottom) resultLines.push(leftBottomX, leftBottomY, 0, height);
      if (rightBottom)
        resultLines.push(rightBottomX, rightBottomY, width, height);
    }
    if (flag) {
      //匹配上了
      return resultLines;
    }
    /////////////////////////////////////////////////////////////////////////

    /////////////////////////////////////////////////////////////////////////
    // 垂直线或水平线与八字线三线相交
    /////////////////////////////////////////////////////////////////////////
    for (var i = 0; i < verticalLines.length; i = i + 5) {
      for (var j = 0; j < crossPoints.length; j = j + 11) {
        var x = crossPoints[j];
        if (Math.abs(x - (verticalLines[i] + verticalLines[i + 2]) / 2) < 50) {
          // 垂直线过交点
          for (var m = 0; m < lines.length; m = m + 4) {
            //检查是否有与该垂直线相交的斜线
            if (
              !(
                lines[m] == 0 &&
                lines[m + 1] == 0 &&
                lines[m + 2] == 0 &&
                lines[m + 3] == 0
              )
            ) {
              //不是被删掉的线,那就是斜线了
              var k = (lines[m + 3] - lines[m + 1]) / (lines[m + 2] - lines[m]);
              var b = -lines[m] * k + lines[m + 1];
              var y = k * x + b; //x,y是斜线与垂直线的交点
              if (
                Math.abs(y - crossPoints[j + 1]) > height / 3 &&
                y >= 0 &&
                y < height
              ) {
                //找到的斜线必须与三线相交的交点足够远才认为有效
                flag = true;
                resultLines.push(crossPoints[j], crossPoints[j + 1], x, y); //最远的垂直墙角
                if (y > crossPoints[j + 1]) {
                  //斜线在下边，八字线在上边
                  if (k > 0) {
                    //斜线是右下斜线
                    var y1 = k * (width - x) + y;
                    if (y1 < height) resultLines.push(x, y, width, y1);
                    else resultLines.push(x, y, (height - y) / k + x, height);
                    // 补齐丢失的左下斜线
                    resultLines.push(x, y, 0, height);
                  } else {
                    //斜线是左下斜线
                    var y1 = k * (0 - x) + y;
                    if (y1 < height) resultLines.push(x, y, 0, y1);
                    else resultLines.push(x, y, (height - y) / k + x, height);
                    // 补齐丢失的右下斜线
                    resultLines.push(x, y, width, height);
                  }
                  // 计算上边的八字线
                  var upPoints = new Array(); //八个点两条线：l1x1、l1y1、l1x2、l1y2、l2x1、l2y1、l2x2、l2y2
                  upPoints.push(
                    crossPoints[j + 2],
                    crossPoints[j + 3],
                    crossPoints[j + 4],
                    crossPoints[j + 5],
                    crossPoints[j + 6],
                    crossPoints[j + 7],
                    crossPoints[j + 8],
                    crossPoints[j + 9]
                  );
                  var k1 =
                    (upPoints[3] - upPoints[1]) / (upPoints[2] - upPoints[0]);
                  if (k1 < 0) {
                    //需要倒一下个
                    var tPoints = new Array();
                    tPoints.push(
                      upPoints[0],
                      upPoints[1],
                      upPoints[2],
                      upPoints[3]
                    );
                    upPoints[0] = upPoints[4];
                    upPoints[1] = upPoints[5];
                    upPoints[2] = upPoints[6];
                    upPoints[3] = upPoints[7];
                    upPoints[4] = tPoints[0];
                    upPoints[5] = tPoints[1];
                    upPoints[6] = tPoints[2];
                    upPoints[7] = tPoints[3];
                    k1 =
                      (upPoints[3] - upPoints[1]) / (upPoints[2] - upPoints[0]);
                  }
                  //左上斜线
                  //斜线的一个点就是交点，根据斜率求斜线的另一个点
                  y = crossPoints[j + 1]; //x,y是八字线的交点
                  var y1 = (0 - x) * k1 + y;
                  if (y1 >= 0) resultLines.push(x, y, 0, y1);
                  else resultLines.push(x, y, -y / k1 + x, 0); //x=(y-1y)/k1+1x
                  //k1>0,k2必然<0，求右上斜线
                  var k2 =
                    (upPoints[7] - upPoints[5]) / (upPoints[6] - upPoints[4]);
                  y1 = (width - x) * k2 + y;
                  if (y1 >= 0) resultLines.push(x, y, width, y1);
                  else resultLines.push(x, y, -y / k2 + x, 0);
                } else {
                  //斜线在上边，八字线在下边
                  if (k > 0) {
                    //斜线是左上斜线
                    var y1 = k * (0 - x) + y;
                    if (y < 0) resultLines.push(x, y, (0 - y) / k + x, 0);
                    else resultLines.push(x, y, 0, y1);
                    // 补齐丢失的右上斜线
                    resultLines.push(x, y, width, 0);
                  } else {
                    //斜线是右上斜线
                    var y1 = k * (width - x) + y;
                    if (y1 < 0) resultLines.push(x, y, (0 - y) / k + x, 0);
                    else resultLines.push(x, y, width, y1);
                    // 补齐丢失的左上斜线
                    resultLines.push(x, y, 0, 0);
                  }
                  // 计算下边的八字线
                  var upPoints = new Array(); //八个点两条线：l1x1、l1y1、l1x2、l1y2、l2x1、l2y1、l2x2、l2y2
                  upPoints.push(
                    crossPoints[j + 2],
                    crossPoints[j + 3],
                    crossPoints[j + 4],
                    crossPoints[j + 5],
                    crossPoints[j + 6],
                    crossPoints[j + 7],
                    crossPoints[j + 8],
                    crossPoints[j + 9]
                  );
                  var k1 =
                    (upPoints[3] - upPoints[1]) / (upPoints[2] - upPoints[0]);
                  if (k1 < 0) {
                    //需要倒一下个
                    var tPoints = new Array();
                    tPoints.push(
                      upPoints[0],
                      upPoints[1],
                      upPoints[2],
                      upPoints[3]
                    );
                    upPoints[0] = upPoints[4];
                    upPoints[1] = upPoints[5];
                    upPoints[2] = upPoints[6];
                    upPoints[3] = upPoints[7];
                    upPoints[4] = tPoints[0];
                    upPoints[5] = tPoints[1];
                    upPoints[6] = tPoints[2];
                    upPoints[7] = tPoints[3];
                    k1 =
                      (upPoints[3] - upPoints[1]) / (upPoints[2] - upPoints[0]);
                  }
                  //右下斜线
                  //斜线的一个点就是交点，根据斜率求斜线的另一个点
                  y = crossPoints[j + 1];
                  var y1 = (width - x) * k1 + y;
                  if (y1 <= height) resultLines.push(x, y, width, y1);
                  else resultLines.push(x, y, (height - y) / k1 + x, height); //x=(y-1y)/k1+1x
                  //k1>0,k2必然<0，求左下斜线
                  var k2 =
                    (upPoints[7] - upPoints[5]) / (upPoints[6] - upPoints[4]);
                  y1 = (0 - x) * k2 + y;
                  if (y1 <= height) resultLines.push(x, y, 0, y1);
                  else resultLines.push(x, y, (height - y1) / k2 + x1, height);
                }
                if (flag) return resultLines;
              }
            }
          }
          if (!flag) {
            //斜线遍历完，但没有找到，则没有另一个交点
            flag = true;
            //只有八字线，没有斜线
            var y = crossPoints[j + 1];
            if (crossPoints[j + 1] < height / 2) {
              resultLines.push(
                crossPoints[j],
                crossPoints[j + 1],
                crossPoints[j],
                height - 50
              );
              resultLines.push(crossPoints[j], height - 50, 0, height);
              resultLines.push(crossPoints[j], height - 50, width, height);
              // 计算上边的八字线
              var upPoints = new Array(); //八个点两条线：l1x1、l1y1、l1x2、l1y2、l2x1、l2y1、l2x2、l2y2
              upPoints.push(
                crossPoints[j + 2],
                crossPoints[j + 3],
                crossPoints[j + 4],
                crossPoints[j + 5],
                crossPoints[j + 6],
                crossPoints[j + 7],
                crossPoints[j + 8],
                crossPoints[j + 9]
              );
              var k1 =
                (upPoints[3] - upPoints[1]) / (upPoints[2] - upPoints[0]);
              if (k1 < 0) {
                //需要倒一下个
                var tPoints = new Array();
                tPoints.push(
                  upPoints[0],
                  upPoints[1],
                  upPoints[2],
                  upPoints[3]
                );
                upPoints[0] = upPoints[4];
                upPoints[1] = upPoints[5];
                upPoints[2] = upPoints[6];
                upPoints[3] = upPoints[7];
                upPoints[4] = tPoints[0];
                upPoints[5] = tPoints[1];
                upPoints[6] = tPoints[2];
                upPoints[7] = tPoints[3];
                k1 = (upPoints[3] - upPoints[1]) / (upPoints[2] - upPoints[0]);
              }
              //左上斜线
              //斜线的一个点就是交点，根据斜率求斜线的另一个点
              var y1 = (0 - x) * k1 + y;
              if (y1 >= 0) resultLines.push(x, y, 0, y1);
              else resultLines.push(x, y, -y / k1 + x, 0); //x=(y-1y)/k1+1x
              //k1>0,k2必然<0，求右上斜线
              var k2 =
                (upPoints[7] - upPoints[5]) / (upPoints[6] - upPoints[4]);
              y1 = (width - x) * k2 + y;
              if (y1 >= 0) resultLines.push(x, y, width, y1);
              else resultLines.push(x, y, -y1 / k2 + x, 0);
            } else {
              resultLines.push(
                crossPoints[j],
                crossPoints[j + 1],
                crossPoints[j],
                50
              );
              resultLines.push(crossPoints[j], 50, 0, 0);
              resultLines.push(crossPoints[j], 50, width, 0);
              // 计算下边的八字线
              var upPoints = new Array(); //八个点两条线：l1x1、l1y1、l1x2、l1y2、l2x1、l2y1、l2x2、l2y2
              upPoints.push(
                crossPoints[j + 2],
                crossPoints[j + 3],
                crossPoints[j + 4],
                crossPoints[j + 5],
                crossPoints[j + 6],
                crossPoints[j + 7],
                crossPoints[j + 8],
                crossPoints[j + 9]
              );
              var k1 =
                (upPoints[3] - upPoints[1]) / (upPoints[2] - upPoints[0]);
              if (k1 < 0) {
                //需要倒一下个
                var tPoints = new Array();
                tPoints.push(
                  upPoints[0],
                  upPoints[1],
                  upPoints[2],
                  upPoints[3]
                );
                upPoints[0] = upPoints[4];
                upPoints[1] = upPoints[5];
                upPoints[2] = upPoints[6];
                upPoints[3] = upPoints[7];
                upPoints[4] = tPoints[0];
                upPoints[5] = tPoints[1];
                upPoints[6] = tPoints[2];
                upPoints[7] = tPoints[3];
                k1 = (upPoints[3] - upPoints[1]) / (upPoints[2] - upPoints[0]);
              }
              //右下斜线
              //斜线的一个点就是交点，根据斜率求斜线的另一个点
              var y1 = (width - x) * k1 + y;
              if (y1 <= height) resultLines.push(x, y, width, y1);
              else resultLines.push(x, y, (height - y) / k1 + x, height); //x=(y-1y)/k1+1x
              //k1>0,k2必然<0，求左下斜线
              var k2 =
                (upPoints[7] - upPoints[5]) / (upPoints[6] - upPoints[4]);
              y1 = (0 - x) * k2 + y;
              if (y1 <= height) resultLines.push(x, y, 0, y1);
              else resultLines.push(x, y, (height - y) / k2 + x, height);
            }
            if (flag) return resultLines;
          }
        }
      }
    }
    // 水平线与八字线相交
    for (var i = 0; i < horizontalLine.length; i = i + 5) {
      for (var j = 0; j < crossPoints.length; j = j + 11) {
        var y = crossPoints[j + 1];
        if (
          Math.abs(y - (horizontalLine[i + 1] + horizontalLine[i + 3]) / 2) < 50
        ) {
          // 水平线过交点
          for (var m = 0; m < lines.length; m = m + 4) {
            //检查是否有与该水平线相交的斜线
            if (
              !(
                lines[m] == 0 &&
                lines[m + 1] == 0 &&
                lines[m + 2] == 0 &&
                lines[m + 3] == 0
              )
            ) {
              //不是被删掉的线,那就是斜线了
              var k = (lines[m + 3] - lines[m + 1]) / (lines[m + 2] - lines[m]);
              var b = -lines[m] * k + lines[m + 1];
              var x = (y - b) / k; //斜线与水平线的交点
              if (
                Math.abs(x - crossPoints[j]) > width / 3 &&
                x >= 0 &&
                x < width
              ) {
                //找到的斜线必须与三线相交的交点足够远才认为有效
                flag = true;
                resultLines.push(crossPoints[j], crossPoints[j + 1], x, y); //最远的水平墙角
                if (x > crossPoints[j]) {
                  //斜线在右边，八字线在左边
                  var y1 = k * (width - x) + y;
                  if (k > 0) {
                    //斜线是右下斜线
                    if (y1 < height) resultLines.push(x, y, width, y1);
                    else resultLines.push(x, y, (height - y) / k + x, height);
                    // 补齐丢失的右上斜线
                    resultLines.push(x, y, width, 0);
                  } else {
                    //斜线是右上斜线
                    var y1 = k * (width - x) + y;
                    if (y >= 0) resultLines.push(x, y, width, y1);
                    else resultLines.push(x, y, (0 - y) / k + x, 0);
                    // 补齐丢失的右下斜线
                    resultLines.push(x, y, width, 0);
                  }
                  // 计算上边的八字线
                  var upPoints = new Array(); //八个点两条线：l1x1、l1y1、l1x2、l1y2、l2x1、l2y1、l2x2、l2y2
                  upPoints.push(
                    crossPoints[j + 2],
                    crossPoints[j + 3],
                    crossPoints[j + 4],
                    crossPoints[j + 5],
                    crossPoints[j + 6],
                    crossPoints[j + 7],
                    crossPoints[j + 8],
                    crossPoints[j + 9]
                  );
                  var k1 =
                    (upPoints[3] - upPoints[1]) / (upPoints[2] - upPoints[0]);
                  if (k1 < 0) {
                    //需要倒一下个
                    var tPoints = new Array();
                    tPoints.push(
                      upPoints[0],
                      upPoints[1],
                      upPoints[2],
                      upPoints[3]
                    );
                    upPoints[0] = upPoints[4];
                    upPoints[1] = upPoints[5];
                    upPoints[2] = upPoints[6];
                    upPoints[3] = upPoints[7];
                    upPoints[4] = tPoints[0];
                    upPoints[5] = tPoints[1];
                    upPoints[6] = tPoints[2];
                    upPoints[7] = tPoints[3];
                    k1 =
                      (upPoints[3] - upPoints[1]) / (upPoints[2] - upPoints[0]);
                  }
                  //左上斜线
                  //斜线的一个点就是交点，根据斜率求斜线的另一个点
                  x = crossPoints[j];
                  var y1 = (0 - x) * k1 + y;
                  if (y1 >= 0) resultLines.push(x, y, 0, y1);
                  else resultLines.push(x, y, -y / k1 + x, 0); //x=(y-1y)/k1+1x
                  //k1>0,k2必然<0，求左下斜线
                  var k2 =
                    (upPoints[7] - upPoints[5]) / (upPoints[6] - upPoints[4]);
                  y1 = (0 - x) * k2 + y;
                  if (y1 < height) resultLines.push(x, y, 0, y1);
                  else resultLines.push(x, y, (height - y) / k2 + x1, height);
                } else {
                  //斜线在左边，八字线在右边
                  var y1 = k * (0 - x) + y;
                  if (k > 0) {
                    //斜线是左上斜线
                    if (y >= 0) resultLines.push(x, y, 0, y1);
                    else resultLines.push(x, y, (0 - y) / k + x, 0);
                    // 补齐丢失的左下斜线
                    resultLines.push(x, y, 0, height);
                  } else {
                    //斜线是左下斜线
                    if (y < height) resultLines.push(x, y, 0, y1);
                    else resultLines.push(x, y, (height - y) / k + x1, height);
                    // 补齐丢失的左上斜线
                    resultLines.push(x, y, 0, 0);
                  }
                  // 计算下边的八字线
                  var upPoints = new Array(); //八个点两条线：l1x1、l1y1、l1x2、l1y2、l2x1、l2y1、l2x2、l2y2
                  upPoints.push(
                    crossPoints[j + 2],
                    crossPoints[j + 3],
                    crossPoints[j + 4],
                    crossPoints[j + 5],
                    crossPoints[j + 6],
                    crossPoints[j + 7],
                    crossPoints[j + 8],
                    crossPoints[j + 9]
                  );
                  var k1 =
                    (upPoints[3] - upPoints[1]) / (upPoints[2] - upPoints[0]);
                  if (k1 < 0) {
                    //需要倒一下个
                    var tPoints = new Array();
                    tPoints.push(
                      upPoints[0],
                      upPoints[1],
                      upPoints[2],
                      upPoints[3]
                    );
                    upPoints[0] = upPoints[4];
                    upPoints[1] = upPoints[5];
                    upPoints[2] = upPoints[6];
                    upPoints[3] = upPoints[7];
                    upPoints[4] = tPoints[0];
                    upPoints[5] = tPoints[1];
                    upPoints[6] = tPoints[2];
                    upPoints[7] = tPoints[3];
                    k1 =
                      (upPoints[3] - upPoints[1]) / (upPoints[2] - upPoints[0]);
                  }
                  //右下斜线
                  //八字线的交点是一个点，根据斜率求斜线的另一个点
                  x = crossPoints[j];
                  var y1 = (width - x) * k1 + y;
                  if (y1 <= height) resultLines.push(x, y, width, y1);
                  else resultLines.push(x, y, (height - y) / k1 + x, height); //x=(y-1y)/k1+1x
                  //k1>0,k2必然<0，求右上斜线
                  var k2 =
                    (upPoints[7] - upPoints[5]) / (upPoints[6] - upPoints[4]);
                  y1 = (width - x) * k2 + y;
                  if (y1 >= 0) resultLines.push(x, y, width, y1);
                  else resultLines.push(x, y, (0 - y1) / k2 + x1, 0);
                }
                if (flag) return resultLines;
              }
            }
          }
          if (!flag) {
            //斜线遍历完，但没有找到，则没有另一个交点
            flag = true;
            //只有八字线，没有斜线
            var x = crossPoints[j];
            if (crossPoints[j] < width / 2) {
              resultLines.push(
                crossPoints[j],
                crossPoints[j + 1],
                crossPoints[j],
                height - 50
              );
              resultLines.push(crossPoints[j], height - 50, width, 0);
              resultLines.push(crossPoints[j], height - 50, width, height);
              // 八字线在左边
              var upPoints = new Array(); //八个点两条线：l1x1、l1y1、l1x2、l1y2、l2x1、l2y1、l2x2、l2y2
              upPoints.push(
                crossPoints[j + 2],
                crossPoints[j + 3],
                crossPoints[j + 4],
                crossPoints[j + 5],
                crossPoints[j + 6],
                crossPoints[j + 7],
                crossPoints[j + 8],
                crossPoints[j + 9]
              );
              var k1 =
                (upPoints[3] - upPoints[1]) / (upPoints[2] - upPoints[0]);
              if (k1 < 0) {
                //需要倒一下个
                var tPoints = new Array();
                tPoints.push(
                  upPoints[0],
                  upPoints[1],
                  upPoints[2],
                  upPoints[3]
                );
                upPoints[0] = upPoints[4];
                upPoints[1] = upPoints[5];
                upPoints[2] = upPoints[6];
                upPoints[3] = upPoints[7];
                upPoints[4] = tPoints[0];
                upPoints[5] = tPoints[1];
                upPoints[6] = tPoints[2];
                upPoints[7] = tPoints[3];
                k1 = (upPoints[3] - upPoints[1]) / (upPoints[2] - upPoints[0]);
              }
              //左上斜线
              var y1 = (0 - x) * k1 + y;
              if (y1 >= 0) resultLines.push(x, y, 0, y1);
              else resultLines.push(x, y, -y / k1 + x, 0); //x=(y-1y)/k1+1x
              //k1>0,k2必然<0，求左下斜线
              var k2 =
                (upPoints[7] - upPoints[5]) / (upPoints[6] - upPoints[4]);
              y1 = (0 - x) * k2 + y;
              if (y1 >= height)
                resultLines.push(x, y, (height - y) / k2 + x1, height);
              else resultLines.push(x, y, 0, y1);
            } else {
              resultLines.push(
                crossPoints[j],
                crossPoints[j + 1],
                50,
                crossPoints[j + 1]
              );
              resultLines.push(50, crossPoints[j + 1], 0, 0);
              resultLines.push(50, crossPoints[j + 1], 0, height);
              // 八字线在右边
              var upPoints = new Array(); //八个点两条线：l1x1、l1y1、l1x2、l1y2、l2x1、l2y1、l2x2、l2y2
              upPoints.push(
                crossPoints[j + 2],
                crossPoints[j + 3],
                crossPoints[j + 4],
                crossPoints[j + 5],
                crossPoints[j + 6],
                crossPoints[j + 7],
                crossPoints[j + 8],
                crossPoints[j + 9]
              );
              var k1 =
                (upPoints[3] - upPoints[1]) / (upPoints[2] - upPoints[0]);
              if (k1 < 0) {
                //需要倒一下个
                var tPoints = new Array();
                tPoints.push(
                  upPoints[0],
                  upPoints[1],
                  upPoints[2],
                  upPoints[3]
                );
                upPoints[0] = upPoints[4];
                upPoints[1] = upPoints[5];
                upPoints[2] = upPoints[6];
                upPoints[3] = upPoints[7];
                upPoints[4] = tPoints[0];
                upPoints[5] = tPoints[1];
                upPoints[6] = tPoints[2];
                upPoints[7] = tPoints[3];
                k1 = (upPoints[3] - upPoints[1]) / (upPoints[2] - upPoints[0]);
              }
              //右下斜线
              //斜线的一个点就是交点，根据斜率求斜线的另一个点
              var y1 = (width - x) * k1 + y;
              if (y1 <= height) resultLines.push(x, y, width, y1);
              else resultLines.push(x, y, (height - y) / k1 + x, height); //x=(y-1y)/k1+1x
              //k1>0,k2必然<0，求右上斜线
              var k2 =
                (upPoints[7] - upPoints[5]) / (upPoints[6] - upPoints[4]);
              y1 = (width - x) * k2 + y;
              if (y1 >= 0) resultLines.push(x, y, width, y1);
              else resultLines.push(x, y, (0 - y1) / k2 + x1, 0);
            }
            if (flag) return resultLines;
          }
        }
      }
    }
    if (flag) {
      //匹配上了
      return resultLines;
    }

    /////////////////////////////////////////////////////////////////////////
    // 矩形只有两条边，需要搜寻斜线，增强证据，也是找出侧面墙体；否则只能猜了
    ///////////////////////////////////////////////////////////////////////////
    var topLeftLine = new Array(),
      topRightLine = new Array(),
      bottomLeftLine = new Array(),
      bottomRightLine = new Array(); //两点式，4个值，前两个是交点的坐标
    if (topIdx > -1 && bottomIdx > -1 && leftIdx == -1 && rightIdx == -1) {
      //缺失左右垂直线，需要寻找与上下水平线相交的斜线
      bottomLeftLine.push(
        99999,
        (horizontalLine[bottomIdx + 1] + horizontalLine[bottomIdx + 3]) / 2
      ); //初始化
      topLeftLine.push(
        99999,
        (horizontalLine[topIdx + 1] + horizontalLine[topIdx + 3]) / 2
      );
      bottomRightLine.push(
        0,
        (horizontalLine[bottomIdx + 1] + horizontalLine[bottomIdx + 3]) / 2
      );
      topRightLine.push(
        0,
        (horizontalLine[topIdx + 1] + horizontalLine[topIdx + 3]) / 2
      );
      for (var m = 0; m < lines.length; m = m + 4) {
        if (
          !(
            lines[m] == 0 &&
            lines[m + 1] == 0 &&
            lines[m + 2] == 0 &&
            lines[m + 3] == 0
          )
        ) {
          //不是被删掉的线,那就是斜线了
          //检查是否有与上水平线相交的斜线
          var temp = intersection(
            lines[m],
            lines[m + 1],
            lines[m + 2],
            lines[m + 3],
            horizontalLine[topIdx],
            horizontalLine[topIdx + 1],
            horizontalLine[topIdx + 2],
            horizontalLine[topIdx + 3],
            2,
            width,
            height
          );
          if (temp.x > -1 && temp.x < width) {
            //存在交点
            var k = (lines[m + 3] - lines[m + 1]) / (lines[m + 2] - lines[m]);
            if (k > 0 && temp.x > topRightLine[0] && temp.x >= width / 2) {
              //右上斜线
              var y = (width - temp.x) * k + temp.y;
              if (y >= 0) topRightLine = new Array(temp.x, temp.y, width, y);
              else
                topRightLine = new Array(
                  temp.x,
                  temp.y,
                  (0 - temp.y) / k + temp.x,
                  0
                );
            }
            if (k < 0 && temp.x < topLeftLine[0] && temp.x < width / 2) {
              //左上斜线
              var y = (0 - temp.x) * k + temp.y;
              if (y >= 0) topLeftLine = new Array(temp.x, temp.y, 0, y);
              else
                topLeftLine = new Array(
                  temp.x,
                  temp.y,
                  (0 - temp.y) / k1 + temp.x,
                  0
                );
            }
          }
          //检查是否有与下水平线相交的斜线
          var temp = intersection(
            lines[m],
            lines[m + 1],
            lines[m + 2],
            lines[m + 3],
            horizontalLine[bottomIdx],
            horizontalLine[bottomIdx + 1],
            horizontalLine[bottomIdx + 2],
            horizontalLine[bottomIdx + 3],
            2,
            width,
            height
          );
          if (temp.x > -1 && temp.x < width) {
            //存在交点
            var k = (lines[m + 3] - lines[m + 1]) / (lines[m + 2] - lines[m]);
            if (k1 > 0 && temp.x < bottomLeftLine[0] && temp.x < width / 2) {
              //左下斜线
              var y = (0 - temp.x) * k + temp.y;
              if (y < height) bottomLeftLine = new Array(temp.x, temp.y, 0, y);
              else
                bottomLeftLine = new Array(
                  temp.x,
                  temp.y,
                  (height - temp.y) / k + temp.x,
                  height
                );
            }
            if (k > 0 && temp.x > bottomRightLine[0] && temp.x >= width / 2) {
              //右下斜线
              var y = (width - temp.x) * k + temp.y;
              if (y < height) bottomRightLine.push(temp.x, temp.y, width, y);
              else
                bottomRightLine.push(
                  temp.x,
                  temp.y,
                  (height - temp.y) / k + temp.x,
                  height
                );
            }
          }
        }
      }
      /////////////// 以下开始完善识别结果 //////////////////////
      // 找到了左上和左下斜线，还有补上的左垂直线，加入结果集
      if (bottomLeftLine[0] < 99999 && topLeftLine[0] < 99999) {
        resultLines.push(
          topLeftLine[0],
          topLeftLine[1],
          bottomLeftLine[0],
          bottomLeftLine[1]
        ); //生成左垂直线
        resultLines.push(
          topLeftLine[0],
          topLeftLine[1],
          topLeftLine[2],
          topLeftLine[3]
        ); //生成左上斜线
        resultLines.push(
          bottomLeftLine[0],
          bottomLeftLine[1],
          bottomLeftLine[2],
          bottomLeftLine[3]
        ); //生成左下斜线
      }
      // 找到了右上和右下斜线，还有补上的右垂直线，加入结果集
      if (bottomRightLine[0] > 0 && topRightLine[0] > 0) {
        resultLines.push(
          topRightLine[0],
          topRightLine[1],
          bottomRightLine[0],
          bottomRightLine[1]
        ); //生成右垂直线
        resultLines.push(
          topRightLine[0],
          topRightLine[1],
          topRightLine[2],
          topRightLine[3]
        );
        resultLines.push(
          bottomRightLine[0],
          bottomRightLine[1],
          bottomRightLine[2],
          bottomRightLine[3]
        );
      }
      // 只有一侧的垂直线找到了，其它的墙线全靠补
      if (resultLines.length == 12) {
        if (bottomLeftLine[0] < 99999 && topLeftLine[0] < 99999) {
          //找到的是左垂直线
          resultLines.push(
            width - 50,
            topLeftLine[1],
            width - 50,
            bottomLeftLine[1]
          ); //生成右垂直线
          resultLines.push(width - 50, topLeftLine[1], width, 0); //生成右上斜线
          resultLines.push(width - 50, bottomLeftLine[1], width, height); //生成右下斜线
        }
        if (bottomRightLine[0] > 0 && topRightLine[0] > 0) {
          //找到的是右垂直线
          resultLines.push(50, topRightLine[1], 50, bottomRightLine[1]); //生成左垂直线
          resultLines.push(50, topRightLine[1], 0, 0); //生成左上斜线
          resultLines.push(50, bottomRightLine[1], 0, height); //生成左下斜线
        }
      }
      // 其它情况就只能瞎猜了
      if (resultLines.length == 0) {
        resultLines.push(
          50,
          horizontalLine[topIdx + 1],
          50,
          horizontalLine[bottomIdx + 1]
        ); //生成左垂直线
        resultLines.push(
          width - 50,
          horizontalLine[topIdx + 3],
          width - 50,
          horizontalLine[bottomIdx + 3]
        ); //生成右垂直线
        resultLines.push(50, horizontalLine[topIdx + 1], 0, 0); //生成左上斜线
        resultLines.push(50, horizontalLine[bottomIdx + 1], 0, height); //生成左下斜线
        resultLines.push(width - 50, horizontalLine[topIdx + 3], width, 0); //生成右上斜线
        resultLines.push(
          width - 50,
          horizontalLine[bottomIdx + 3],
          width,
          height
        ); //生成右下斜线
      }
      // 最后填加上下两条水平线，这是本来就识别出来的
      if (resultLines.length == 24) {
        resultLines.push(
          topLeftLine[0],
          topLeftLine[1],
          topRightLine[0],
          topRightLine[1]
        );
        resultLines.push(
          bottomLeftLine[0],
          bottomLeftLine[1],
          bottomRightLine[0],
          bottomRightLine[1]
        );
      }
      return resultLines;
    }

    if (topIdx == -1 && bottomIdx == -1 && leftIdx > -1 && rightIdx > -1) {
      //缺失上下水平线，需要寻找与左右垂直线相交的斜线
      topLeftLine.push(
        (verticalLines[leftIdx] + verticalLines[leftIdx + 3]) / 2,
        99999
      );
      bottomLeftLine.push(
        (verticalLines[leftIdx] + verticalLines[leftIdx + 3]) / 2,
        0
      ); //初始化
      topRightLine.push(
        (verticalLines[rightIdx] + verticalLines[rightIdx + 3]) / 2,
        99999
      );
      bottomRightLine.push(
        (verticalLines[rightIdx] + verticalLines[rightIdx + 3]) / 2,
        0
      );
      for (var m = 0; m < lines.length; m = m + 4) {
        //检查是否有与左垂直线相交的斜线
        if (
          !(
            lines[m] == 0 &&
            lines[m + 1] == 0 &&
            lines[m + 2] == 0 &&
            lines[m + 3] == 0
          )
        ) {
          //不是被删掉的线,那就是斜线了
          //检查是否有与左垂直线相交的斜线
          var temp = intersection(
            lines[m],
            lines[m + 1],
            lines[m + 2],
            lines[m + 3],
            verticalLines[leftIdx],
            verticalLines[leftIdx + 1],
            verticalLines[leftIdx + 2],
            verticalLines[leftIdx + 3],
            1,
            width,
            height
          );
          if (temp.y > -1 && temp.y < height) {
            //存在交点
            var k = (lines[m + 3] - lines[m + 1]) / (lines[m + 2] - lines[m]);
            if (k > 0 && temp.y > bottomLeftLine[1] && temp.y >= height / 2) {
              //左下斜线
              var y = (0 - temp.x) * k + temp.y;
              if (y < height)
                bottomLeftLine = new Array(temp.x, temp.y, width, y);
              else
                bottomLeftLine = new Array(
                  temp.x,
                  temp.y,
                  (0 - temp.y) / k + temp.x,
                  0
                );
            }
            if (k < 0 && temp.y < topLeftLine[1] && temp.y < height / 2) {
              //左上斜线
              var y = (0 - temp.x) * k + temp.y;
              if (y >= 0) topLeftLine = new Array(temp.x, temp.y, 0, y);
              else
                topLeftLine = new Array(
                  temp.x,
                  temp.y,
                  (0 - temp.y) / k + temp.x,
                  0
                );
            }
          }
          //检查是否有与右垂直线相交的斜线
          var temp = intersection(
            lines[m],
            lines[m + 1],
            lines[m + 2],
            lines[m + 3],
            verticalLines[rightIdx],
            verticalLines[rightIdx + 1],
            verticalLines[rightIdx + 2],
            verticalLines[rightIdx + 3],
            1,
            width,
            height
          );
          if (temp.y > -1 && temp.y < height) {
            //存在交点
            var k = (lines[m + 3] - lines[m + 1]) / (lines[m + 2] - lines[m]);
            if (k > 0 && temp.y < topRightLine[1] && temp.y < height / 2) {
              //右上斜线
              var y = (width - temp.x) * k + temp.y;
              if (y >= 0) topRightLine = new Array(temp.x, temp.y, width, y);
              else
                topRightLine = new Array(
                  temp.x,
                  temp.y,
                  (0 - temp.y) / k + temp.x,
                  0
                );
            }
            if (k > 0 && temp.y > bottomRightLine[1] && temp.y >= height / 2) {
              //右下斜线
              var y = (width - temp.x) * k + temp.y;
              if (y < height)
                bottomRightLine = new Array(temp.x, temp.y, width, y);
              else
                bottomRightLine = new Array(
                  temp.x,
                  temp.y,
                  (height - temp.y) / k + temp.x,
                  height
                );
            }
          }
        }
      }
      /////////////// 以下开始完善识别结果 //////////////////////
      // 找到了左上和右上斜线，还有补上的上水平线，加入结果集
      if (topRightLine[0] < 99999 && topLeftLine[0] < 99999) {
        resultLines.push(
          topLeftLine[0],
          topLeftLine[1],
          topRightLine[0],
          topRightLine[1]
        ); //生成上水平线
        resultLines.push(
          topLeftLine[0],
          topLeftLine[1],
          topLeftLine[2],
          topLeftLine[3]
        ); //生成上左斜线
        resultLines.push(
          topRightLine[0],
          topRightLine[1],
          topRightLine[2],
          topRightLine[3]
        ); //生成上右斜线
      }
      // 找到了左下和右下斜线，还有补上的下水平线，加入结果集
      if (bottomRightLine[0] > 0 && bottomLeftLine[0] > 0) {
        resultLines.push(
          bottomLeftLine[0],
          bottomLeftLine[1],
          bottomRightLine[0],
          bottomRightLine[1]
        ); //生成下水平线
        resultLines.push(
          bottomLeftLine[0],
          bottomLeftLine[1],
          bottomLeftLine[2],
          bottomLeftLine[3]
        ); //生成下左斜线
        resultLines.push(
          bottomRightLine[0],
          bottomRightLine[1],
          bottomRightLine[2],
          bottomRightLine[3]
        ); //生成下右斜线
      }
      // 只有一侧的水平线找到了，其它的墙线全靠补
      if (resultLines.length == 12) {
        if (bottomLeftLine[0] > 0 && bottomRightLine[0] > 0) {
          //找到的是下水平线
          resultLines.push(bottomLeftLine[0], 50, 0, 0); //生成左上斜线
          resultLines.push(bottomRightLine[0], 50, width, 0); //生成右上斜线
          resultLines.push(bottomLeftLine[0], 50, bottomRightLine[0], 50); //生成上水平线
        }
        if (topLeftLine[0] < 99999 && topRightLine[0] < 99999) {
          //找到的是上水平线
          resultLines.push(topLeftLine[0], height - 50, 0, height); //生成左下斜线
          resultLines.push(topRightLine[0], height - 50, width, height); //生成右下斜线
          resultLines.push(
            topLeftLine[0],
            height - 50,
            topRightLine[0],
            height - 50
          ); //生成下水平线
        }
      }
      // 其它情况就只能瞎猜了
      if (resultLines.length == 0) {
        resultLines.push(
          verticalLines[leftIdx],
          50,
          verticalLines[rightIdx],
          50
        ); //生成上水平线
        resultLines.push(
          verticalLines[leftIdx + 2],
          height - 50,
          verticalLines[rightIdx + 2],
          height - 50
        ); //生成下水平线
        resultLines.push(verticalLines[leftIdx], 50, 0, 0); //生成左上斜线
        resultLines.push(verticalLines[leftIdx + 2], height - 50, 0, height); //生成左下斜线
        resultLines.push(verticalLines[rightIdx], 50, width, 0); //生成右上斜线
        resultLines.push(
          verticalLines[rightIdx + 2],
          height - 50,
          width,
          height
        ); //生成右下斜线
      }
      // 最后填加上下两条垂直线，这是本来就识别出来的
      if (resultLines.length == 24) {
        resultLines.push(
          topLeftLine[0],
          topLeftLine[1],
          bottomLeftLine[0],
          bottomLeftLine[1]
        );
        resultLines.push(
          topRightLine[0],
          topRightLine[1],
          bottomRightLine[0],
          bottomRightLine[1]
        );
      }
      return resultLines;
    }

    if (topIdx == -1 && bottomIdx > -1 && leftIdx > -1 && rightIdx == -1) {
      //缺失上和右线
      verticalLines[leftIdx + 4] = 5;
      //verticalLines[rightIdx + 4] = 5;
      horizontalLine[bottomIdx + 4] = 5;
      ////////// 补上缺失的直线，位置先放到图片边缘处
      rightIdx = verticalLines.length;
      verticalLines.push(width - 50, 0, width - 50, height, -5); //负数代表该线是推断出来的，不是识别出来的
      topIdx = horizontalLine.length;
      horizontalLine.push(0, 50, width, 50, -5); //负数代表该线是推断出来的，不是识别出来的
      //////////
      //horizontalLine[topIdx + 4] = 5;
    }
    if (topIdx == -1 && bottomIdx > -1 && leftIdx == -1 && rightIdx > -1) {
      //缺失上和左线
      //verticalLines[leftIdx + 4] = 5;
      verticalLines[rightIdx + 4] = 5;
      horizontalLine[bottomIdx + 4] = 5;
      ////////// 补上缺失的直线，位置先放到图片边缘处
      leftIdx = verticalLines.length;
      verticalLines.push(50, 0, 50, height, -5); //负数代表该线是推断出来的，不是识别出来的
      //////////
      //horizontalLine[topIdx + 4] = 5;
      topIdx = horizontalLine.length;
      horizontalLine.push(0, 50, width, 50, -5); //负数代表该线是推断出来的，不是识别出来的
    }
    if (topIdx > -1 && bottomIdx == -1 && leftIdx > -1 && rightIdx == -1) {
      //缺失下和右线
      verticalLines[leftIdx + 4] = 5;
      //verticalLines[rightIdx + 4] = 5;
      //horizontalLine[bottomIdx + 4] = 5;
      ////////// 补上缺失的直线，位置先放到图片边缘处
      rightIdx = verticalLines.length;
      verticalLines.push(width - 50, 0, width - 50, height, -5); //负数代表该线是推断出来的，不是识别出来的
      bottomIdx = horizontalLine.length;
      horizontalLine.push(0, height - 50, width, height - 50, -5); //负数代表该线是推断出来的，不是识别出来的
      //////////
      horizontalLine[topIdx + 4] = 5;
    }
    if (topIdx > -1 && bottomIdx == -1 && leftIdx == -1 && rightIdx > -1) {
      //缺失下和左线
      //verticalLines[leftIdx + 4] = 5;
      verticalLines[rightIdx + 4] = 5;
      //horizontalLine[bottomIdx + 4] = 5;
      ////////// 补上缺失的直线，位置先放到图片边缘处
      leftIdx = verticalLines.length;
      verticalLines.push(50, 0, 50, height, -5); //负数代表该线是推断出来的，不是识别出来的
      bottomIdx = horizontalLine.length;
      horizontalLine.push(0, height - 50, width, height - 50, -5); //负数代表该线是推断出来的，不是识别出来的
      //////////
      horizontalLine[topIdx + 4] = 5;
    }
    /////////////////////////////////////////////////////////////////////////

    ////////////////////////////////////////////////////////////////////////////////
    // 只有唯一一条水平线，可能是地面的最远墙线，匹配上两边的地面斜线则识别出地面
    ////////////////////////////////////////////////////////////////////////////////
    if (horizontalLine.length == 5) {
      // 只有唯一的条水平线
      var leftSlopeLine = new Array(99999),
        rightSlopeLine = new Array(0); // 4元组，前两个值是交点的坐标
      for (var m = 0; m < lines.length; m = m + 4) {
        if (
          !(
            lines[m] == 0 &&
            lines[m + 1] == 0 &&
            lines[m + 2] == 0 &&
            lines[m + 3] == 0
          )
        ) {
          //不是被删掉的线,那就是斜线了
          var temp = intersection(
            lines[m],
            lines[m + 1],
            lines[m + 2],
            lines[m + 3],
            horizontalLine[0],
            horizontalLine[1],
            horizontalLine[2],
            horizontalLine[3],
            2,
            width,
            height
          );
          var k = (lines[m + 3] - lines[m + 1]) / (lines[m + 2] - lines[m]);
          if (k > 0 && temp.x < width / 2 && temp.x < leftSlopeLine[0]) {
            //找最左的左下斜线
            var y = (0 - temp.x) * k + temp.y;
            if (y < height) leftSlopeLine = new Array(temp.x, temp.y, 0, y);
            else
              leftSlopeLine = new Array(
                temp.x,
                temp.y,
                (height - temp.y) / k + temp.x,
                height
              );
          }
          if (k < 0 && temp.x >= width / 2 && temp.x > rightSlopeLine[0]) {
            //找最右的右下斜线
            var y = (width - temp.x) * k + temp.y;
            if (y < height)
              rightSlopeLine = new Array(temp.x, temp.y, width, y);
            else
              rightSlopeLine = new Array(
                temp.x,
                temp.y,
                (height - temp.y) / k + temp.x,
                height
              );
          }
        }
      }
      if (leftSlopeLine[0] < 99999 && rightSlopeLine[0] > 0) {
        //整个地面都识别出来了，补上交点处两条竖线
        resultLines.push(
          horizontalLine[0],
          horizontalLine[1],
          horizontalLine[2],
          horizontalLine[3]
        ); //生成水平线
        resultLines.push(
          leftSlopeLine[0],
          leftSlopeLine[1],
          leftSlopeLine[2],
          leftSlopeLine[3]
        ); //生成左下斜线
        resultLines.push(
          leftSlopeLine[0],
          leftSlopeLine[1],
          leftSlopeLine[0],
          50
        ); //生成左垂直线
        resultLines.push(
          rightSlopeLine[0],
          rightSlopeLine[1],
          rightSlopeLine[2],
          rightSlopeLine[3]
        ); //生成右下斜线
        resultLines.push(
          rightSlopeLine[0],
          rightSlopeLine[1],
          rightSlopeLine[0],
          50
        ); //生成右垂直线
        resultLines.push(leftSlopeLine[0], 50, rightSlopeLine[0], 50); //生成上水平线
        resultLines.push(leftSlopeLine[0], 50, 0, 0); //生成上左斜线
        resultLines.push(rightSlopeLine[0], 50, width, 0); //生成上右斜线
        return resultLines;
      }
    }
    ////////////////////////////////////////////////////////////////////////////////

    return resultLines;
  };
  cv.recognizingWall = recognizingWall;

  ///////////////////////////////////////////////////////////////////////////
  // 遍历所有斜线，找斜线与斜线的交点
  var findCrossPoint = function (lines, width, height) {
    var crossPoint = new Array(); //斜线与斜线的交点
    for (var m = 0; m < lines.length; m = m + 4) {
      if (
        !(
          lines[m] == 0 &&
          lines[m + 1] == 0 &&
          lines[m + 2] == 0 &&
          lines[m + 3] == 0
        )
      ) {
        //不是被删掉的线,那就是斜线了
        var k1 = (lines[m + 3] - lines[m + 1]) / (lines[m + 2] - lines[m]);
        for (var n = m + 4; n < lines.length; n = n + 4) {
          if (
            !(
              lines[n] == 0 &&
              lines[n + 1] == 0 &&
              lines[n + 2] == 0 &&
              lines[n + 3] == 0
            )
          ) {
            //不是被删掉的线,那就是斜线了
            var k2 = (lines[n + 3] - lines[n + 1]) / (lines[n + 2] - lines[n]);
            if ((k1 > 0 && k2 < 0) || (k1 < 0 && k2 > 0)) {
              //相交斜线必须是相对相交，不能是同象限相交
              var temp = intersection(
                lines[m],
                lines[m + 1],
                lines[m + 2],
                lines[m + 3],
                lines[n],
                lines[n + 1],
                lines[n + 2],
                lines[n + 3],
                3,
                width,
                height
              );
              if (
                temp.x > -1 &&
                temp.y > -1 &&
                temp.x <= width &&
                temp.y <= height
              )
                // 图像内有交点
                crossPoint.push(
                  temp.x,
                  temp.y /*交点坐标*/,
                  lines[m],
                  lines[m + 1],
                  lines[m + 2],
                  lines[m + 3],
                  lines[n],
                  lines[n + 1],
                  lines[n + 2],
                  lines[n + 3],
                  0 /*分数*/
                );
            }
          }
        }
      }
    }
    return crossPoint;
  };

  // 计算两直线（两点式方程）的交点
  // LineType：第二条线的直线类型：1、垂直线；2、水平线；3、斜线
  //           第一条线一定是斜线
  // width：图片宽度（单位像素）
  // height：图片高度（单位像素）
  var intersection = function (
    point1X,
    point1Y,
    point2X,
    point2Y,
    point3X,
    point3Y,
    point4X,
    point4Y,
    LineType,
    width,
    height
  ) {
    // line1：    y=(x-1x)*(2y-1y)/(2x-1x)+1y
    // line2：斜线y=(x-3x)*(4y-3y)/(4x-3x)+3y    垂直线x=3x    水平线y=3y
    var x = -1,
      y = -1; //交点
    var a = point2Y - point1Y,
      b = point2X - point1X,
      c = point4Y - point3Y,
      d = point4X - point3X;
    switch (LineType) {
      case 1:
        x = point3X;
        y = ((x - point1X) * a) / b + point1Y;
        break;
      case 2:
        y = point3Y;
        x = ((y - point1Y) * b) / a - point1X;
        break;
      default:
        for (var w = width; w--; ) {
          var yy = ((w - point3X) * c) / d + point3Y;
          if (Math.abs(yy - (((w - point1X) * a) / b + point1Y)) < 3) {
            //因为计算有误差，所以这里阈值取3
            x = w;
            y = yy;
            break; // 两直线顶多有一个交点
            // 遍历完width都没找到交点就是(-1,-1)，说明在图像内这两条直线没有相交
          }
        }
        break;
    }
    return { x: x, y: y };
  };

  // 任意四角拉伸图片
  // originalPicWidth, originalPicHeight：原图的宽和高
  // upleft, upright, downright, downleft：图片四角的像素坐标
  var getTransformedBitmap = function (
    __src,
    originalPicWidth,
    originalPicHeight,
    upleft,
    upright,
    downright,
    downleft,
    __dst
  ) {
    __src || error(arguments.callee, IS_UNDEFINED_OR_NULL /* {line} */);
    var srcData = __src.data;
    var vertex = [4]; //目标图片的四个顶点
    vertex[0] = upleft;
    vertex[1] = upright;
    vertex[2] = downright;
    vertex[3] = downleft;
    var xmin = Number.MAX_VALUE,
      ymin = Number.MAX_VALUE,
      xmax = Number.MIN_VALUE,
      ymax = Number.MIN_VALUE;

    for (var i = 0; i < 4; i++) {
      //因为目标图片被伸拉变形了，不再是矩形了，所以需要找出最小的外接矩形
      xmax = Math.max(xmax, vertex[i].X);
      ymax = Math.max(ymax, vertex[i].Y);
      xmin = Math.min(xmin, vertex[i].X);
      ymin = Math.min(ymin, vertex[i].Y);
    }
    var width = xmax - xmin + 1, //目标图片的宽和高，
      height = ymax - ymin + 1;
    //if (width < originalPicWidth) width = originalPicWidth;//如果目标图片小于画布，则按画布尺寸处理
    //if (height < originalPicHeight) height = originalPicHeight;

    var AB, BC, CD, DA, dab, dbc, dcd, dda;
    var xfloat,
      yfloat,
      x1,
      y1,
      x2,
      y2,
      dx1,
      dx2,
      dy1,
      dy2,
      dx1y1,
      dx1y2,
      dx2y1,
      dx2y2;
    var y1offset, y2offset, x14, x24;
    var predy1, predy2, predy3, predy4;
    var sum, sum1, sum2, sum3, sum4;

    AB = new cvv.Vector(vertex[0], vertex[1]); //目标图片的四边向量
    BC = new cvv.Vector(vertex[1], vertex[2]);
    CD = new cvv.Vector(vertex[2], vertex[3]);
    DA = new cvv.Vector(vertex[3], vertex[0]);
    AB.division(AB.Magnitude());
    BC.division(BC.Magnitude());
    CD.division(CD.Magnitude());
    DA.division(DA.Magnitude());

    var dst = __dst || new Mat(height, width, CV_RGBA),
      dstData = dst.data;

    if (__src.type && __src.type == "CV_RGBA") {
      var offsetX, offsetY, srcPt;
      var leftBorder, rightBorder; //穿越一行像素的四边形的右左边界位置

      for (y = height; y--; ) {
        //逐行扫描目标图片
        offsetY = y * width * 4;
        (rightBorder = -1), (leftBorder = Number.MAX_VALUE);
        //找出当前行的左右边界位置
        for (var i = 0; i < 4; i++) {
          var j = i < 3 ? i + 1 : 0;
          //右边的边界线段在当前点的下方或上方，跳过
          if (
            (vertex[i].Y < y && vertex[j].Y < y) ||
            (vertex[i].Y > y && vertex[j].Y > y)
          ) {
          }
          // 是当前点右边的边界线段,但是可能右边的边界线段平行于当前点的线段
          else {
            if (vertex[i].Y == y && vertex[j].Y == y) {
              //右边的边界线段平行于当前点的线段
              rightBorder = Math.max(vertex[i].X, vertex[j].X);
              leftBorder = Math.min(vertex[i].X, vertex[j].X);
              //不会再有其它边界线段了
              break;
            }
            var a = vertex[j].Y - vertex[i].Y,
              b = vertex[j].X - vertex[i].X;
            var temp = ((y - vertex[i].Y) * b) / a + vertex[i].X; //求出交点，即是边界
            if (temp == rightBorder || temp == leftBorder) {
            } else {
              if (temp > rightBorder) rightBorder = temp;
              if (temp < leftBorder) leftBorder = temp;
            }
          }
        }

        predy1 = y - vertex[0].Y;
        predy2 = y - vertex[1].Y;
        predy3 = y - vertex[2].Y;
        predy4 = y - vertex[3].Y;

        for (x = width; x--; ) {
          //如果该像素在目标图片像素的ABCD四边形之内，则计算目标图片像素的值，否则目标图片像素为透明的黑点，无需计算
          if (x <= rightBorder && x >= leftBorder) {
            offsetX = x * 4;
            dab = Math.abs((x - vertex[0].X) * AB.Y - AB.X * predy1);
            dbc = Math.abs((x - vertex[1].X) * BC.Y - BC.X * predy2);
            dcd = Math.abs((x - vertex[2].X) * CD.Y - CD.X * predy3);
            dda = Math.abs((x - vertex[3].X) * DA.Y - DA.X * predy4);
            xfloat = __src.col * (dda / (dda + dbc));
            yfloat = __src.row * (dab / (dab + dcd));
            x1 = Math.round(xfloat); //逆推回原始图片的像素坐标
            y1 = Math.round(yfloat);

            if (x1 >= 0 && x1 < __src.col && y1 >= 0 && y1 < __src.row) {
              ///////////// 最近邻插值 ////////////////
              //dstData[offsetY + offsetX] = srcData[(y1 * __src.col + x1) * 4];
              //dstData[offsetY + offsetX + 1] = srcData[(y1 * __src.col + x1) * 4 + 1];
              //dstData[offsetY + offsetX + 2] = srcData[(y1 * __src.col + x1) * 4 + 2];
              //dstData[offsetY + offsetX + 3] = srcData[(y1 * __src.col + x1) * 4 + 3];
              //////////////////////////////////////

              //////////////// 双线性插值 ////////////
              x2 = x1 == width - 1 ? x1 : x1 + 1;
              y2 = y1 == height - 1 ? y1 : y1 + 1;

              dx1 = xfloat - x1; //小数部分
              if (dx1 < 0) dx1 = 0;
              dx1 = 1 - dx1;
              dx2 = 1 - dx1;
              dy1 = yfloat - y1;
              if (dy1 < 0) dy1 = 0;
              dy1 = 1 - dy1;
              dy2 = 1 - dy1;

              dx1y1 = dx1 * dy1;
              dx1y2 = dx1 * dy2;
              dx2y1 = dx2 * dy1;
              dx2y2 = dx2 * dy2;

              y1offset = y1 * __src.col * 4;
              y2offset = y2 * __src.col * 4;
              x14 = x1 * 4;
              x24 = x2 * 4;
              sum = offsetY + offsetX;
              sum1 = y1offset + x14;
              sum2 = y1offset + x24;
              sum3 = y2offset + x14;
              sum4 = y2offset + x14;

              dstData[sum] =
                srcData[sum1] * dx1y1 +
                srcData[sum2] * dx2y1 +
                srcData[sum3] * dx1y2 +
                srcData[sum4] * dx2y2;
              dstData[sum + 1] =
                srcData[sum1 + 1] * dx1y1 +
                srcData[sum2 + 1] * dx2y1 +
                srcData[sum3 + 1] * dx1y2 +
                srcData[sum4 + 1] * dx2y2;
              dstData[sum + 2] =
                srcData[sum1 + 2] * dx1y1 +
                srcData[sum2 + 2] * dx2y1 +
                srcData[sum3 + 2] * dx1y2 +
                srcData[sum4 + 2] * dx2y2;
              dstData[sum + 3] =
                srcData[sum1 + 3] * dx1y1 +
                srcData[sum2 + 3] * dx2y1 +
                srcData[sum3 + 3] * dx1y2 +
                srcData[sum4 + 3] * dx2y2;
              ////////////////////////////////////
            }
          }
        }
      }
    } else {
      error(arguments.callee, UNSPPORT_DATA_TYPE /* {line} */);
    }
    return dst;
  };
  cv.getTransformedBitmap = getTransformedBitmap;

  host.cv = cv;
  this.__cv20121221 = cv;
})(this);
