this.MyFurnitureAssistant = this.MyFurnitureAssistant || {};
//定义别名(快捷名)：
if (typeof this.MyFA === 'undefined') {
    this.MyFA = this.MyFurnitureAssistant;
}
//墙体线Model
(function () {
    function WallLineModel(wallsResult, w, h) { //wallsResult:墙体识别结果 w:照片宽度 h:照片高度
        if (typeof (wallsResult) != "undefined") {

            this.arr = this.TagWall(wallsResult, w, h);
        }
    }
    var p = WallLineModel.prototype;
    // 对墙体识别结果进行处理（点、线进行定位和编序），
    p.TagWall = function (wallsResult, w, h) {
        if (wallsResult.length == 32) {
            arr = this.move1(wallsResult, w, h);
        }
        else if (wallsResult.length == 20) {
            arr = this.move2(wallsResult, w, h);
        }
        else {
            arr = this.move3(w, h);
        }
        return arr;
    }

    //线条移动后重新设置WallLineModel.arr
    p.SetArr = function (newArr) {
        this.arr = newArr;
    }

    //墙体识别错误时重置标识线。type：0、正对矩形墙面；1、正对竖墙角；2、正对横墙角；3、斜对墙面
    p.SetWallType = function (wallType, w, h) {
        var arr;
        switch (wallType)
        {
            case 0:
                arr = this.move3(w, h);
                break;
            case 1:
                arr = this.move4(w, h);
                break;
            case 2:
                arr = this.move5(w, h);
                break;
        }

        //if (wallType == 0) {
        //    arr = this.move3(w, h);
        //}
        //else if (wallType == 1) {
        //    arr = this.move4(w, h);
        //}
        //else if (wallType == 2) {
        //    arr = this.move5(w, h);
        //}
        return arr;
    }

    //墙体识别结果为8条线时，处理识别结果
    p.move1=function (walls, w, h) {//walls:未经过处理的识别结果数组 w:房间照片宽度 h:房间照片高度
        this.walls = walls;
        var ar = [];
        var p0, p1, p2, p3, p4, p5, p6, p7;
        var l0, l1, l2, l3, l4, l5, l6, l7;
        var bool1, bool2, bool3, bool4;
        bool1 = bool2 = bool3 = bool4 = false;
        for (var i = 0; i < walls.length; i = i + 4) {
            if (Math.abs(walls[i + 2] - walls[i]) <= 50) {
                if (!bool1) {
                    l3 = { X1: walls[i], Y1: walls[i + 1], X2: walls[i + 2], Y2: walls[i + 3] };
                    bool1 = true;
                }
                else {
                    l4 = { X1: walls[i], Y1: walls[i + 1], X2: walls[i + 2], Y2: walls[i + 3] };
                }
            }
            if (Math.abs(walls[i + 3] - walls[i + 1]) <= 50) {
                if (!bool2) {
                    l1 = { X1: walls[i], Y1: walls[i + 1], X2: walls[i + 2], Y2: walls[i + 3] };
                    bool2 = true;
                }
                else {
                    l6 = { X1: walls[i], Y1: walls[i + 1], X2: walls[i + 2], Y2: walls[i + 3] };
                }
            }
            if ((walls[i] < walls[i + 2] && walls[i + 1] < walls[i + 3]) || (walls[i] > walls[i + 2] && walls[i + 1] > walls[i + 3])) {
                if (!bool3) {
                    l0 = { X1: walls[i], Y1: walls[i + 1], X2: walls[i + 2], Y2: walls[i + 3] };
                    bool3 = true;
                }
                else {
                    l7 = { X1: walls[i], Y1: walls[i + 1], X2: walls[i + 2], Y2: walls[i + 3] };
                }
            }
            if ((walls[i] > walls[i + 2] && walls[i + 1] < walls[i + 3]) || (walls[i] < walls[i + 2] && walls[i + 1] > walls[i + 3])) {
                if (!bool4) {
                    l2 = { X1: walls[i], Y1: walls[i + 1], X2: walls[i + 2], Y2: walls[i + 3] };
                    bool4 = true;
                }
                else {
                    l5 = { X1: walls[i], Y1: walls[i + 1], X2: walls[i + 2], Y2: walls[i + 3] };
                }
            }
        }
        if (typeof (l0) == "undefined" || typeof (l1) == "undefined" || typeof (l2) == "undefined" || typeof (l3) == "undefined" || typeof (l4) == "undefined" || typeof (l5) == "undefined" || typeof (l6) == "undefined" || typeof (l7) == "undefined") {
            ar = this.move3(w, h);
        }
        else {
            if (l3.X1 > l4.X1) {
                var c = l4;
                l4 = l3;
                l3 = c;
            }
            if (l1.Y1 > l6.Y1) {
                var c = l6;
                l6 = l1;
                l1 = c;
            }
            if (l0.X1 > l7.X1 && l0.X1 > l7.X2) {
                var c = l7;
                l7 = l0;
                l0 = c;
            }
            if (l2.X1 < l5.X1 && l2.X1 < l5.X2) {
                var c = l5;
                l5 = l2;
                l2 = c;
            }
            if (l0.X1 > l0.X2) {
                p0 = { Px: l0.X2 + 0, Py: l0.Y2 + 0 };
                p1 = { Px: l0.X1, Py: l0.Y1 };
            }
            else {
                p1 = { Px: l0.X2, Py: l0.Y2 };
                p0 = { Px: l0.X1 + 0, Py: l0.Y1 + 0 };
            }
            if (l2.X1 > l2.X2) {
                p2 = { Px: l2.X2, Py: l2.Y2 };
                p3 = { Px: l2.X1 - 0, Py: l2.Y1 + 0 };
            }
            else {
                p3 = { Px: l2.X2 - 0, Py: l2.Y2 + 0 };
                p2 = { Px: l2.X1, Py: l2.Y1 };
            }
            if (l5.X1 > l5.X2) {
                p4 = { Px: l5.X2 + 0, Py: l5.Y2 - 0 };
                p5 = { Px: l5.X1, Py: l5.Y1 };
            }
            else {
                p5 = { Px: l5.X2, Py: l5.Y2 };
                p4 = { Px: l5.X1 + 0, Py: l5.Y1 - 0 };
            }
            if (l7.X1 > l7.X2) {
                p6 = { Px: l7.X2, Py: l7.Y2 };
                p7 = { Px: l7.X1 - 0, Py: l7.Y1 - 0 };
            }
            else {
                p7 = { Px: l7.X2 - 0, Py: l7.Y2 - 0 };
                p6 = { Px: l7.X1, Py: l7.Y1 };
            }
            ar.push(p0);
            ar.push(p1);
            ar.push(p2);
            ar.push(p3);
            ar.push(p4);
            ar.push(p5);
            ar.push(p6);
            ar.push(p7);
        }
        this.arr = ar;
        return ar;
    }

    //墙体识别结果为5条线时(正对竖墙角)，处理识别结果
    p.move2=function (walls, w, h) {//walls:未经过处理的识别结果数组 w:房间照片宽度 h:房间照片高度
        this.walls = walls;
        var p0, p1, p2, p3, p4, p5;
        var l0, l1, l2, l3, l4;
        var bool1, bool2, bool3, bool4;
        bool1 = bool2 = bool3 = bool4 = false;
        var ar = [];
        for (var i = 0; i < walls.length; i = i + 4) {
            if (Math.abs(walls[i + 2] - walls[i]) <= 50) {
                l2 = { X1: walls[i], Y1: walls[i + 1], X2: walls[i + 2], Y2: walls[i + 3] };
                bool1 = true;
            }
            if ((walls[i] < walls[i + 2] && walls[i + 1] < walls[i + 3]) || (walls[i] > walls[i + 2] && walls[i + 1] > walls[i + 3])) {
                if (!bool3) {
                    l0 = { X1: walls[i], Y1: walls[i + 1], X2: walls[i + 2], Y2: walls[i + 3] };
                    bool3 = true;
                }
                else {
                    l4 = { X1: walls[i], Y1: walls[i + 1], X2: walls[i + 2], Y2: walls[i + 3] };
                }
            }
            if ((walls[i] > walls[i + 2] && walls[i + 1] < walls[i + 3]) || (walls[i] < walls[i + 2] && walls[i + 1] > walls[i + 3])) {
                if (!bool4) {
                    l1 = { X1: walls[i], Y1: walls[i + 1], X2: walls[i + 2], Y2: walls[i + 3] };
                    bool4 = true;
                }
                else {
                    l3 = { X1: walls[i], Y1: walls[i + 1], X2: walls[i + 2], Y2: walls[i + 3] };
                }
            }
        }
        if (typeof (l0) == "undefined" || typeof (l1) == "undefined" || typeof (l2) == "undefined" || typeof (l3) == "undefined" || typeof (l4) == "undefined") {
            ar = this.move4(w, h);
        }
        else {
            if (l0.X1 >= l4.X1 && l0.X1 > l4.X2) {
                var c = l4;
                l4 = l0;
                l0 = c;
            }
            if (l1.X1 <= l3.X1 && l1.X1 < l3.X2) {
                var c = l3;
                l3 = l1;
                l1 = c;
            }
            if (l2.Y1 > l2.Y2) {
                p1 = { Px: l2.X2, Py: l2.Y2 };
                p4 = { Px: l2.X1, Py: l2.Y1 };
            }
            else {
                p4 = { Px: l2.X2, Py: l2.Y2 };
                p1 = { Px: l2.X1, Py: l2.Y1 };
            }
            if (l1.X1 < l1.X2) {
                p2 = { Px: l1.X2 - 0, Py: l1.Y2 + 0 };
            }
            else {
                p2 = { Px: l1.X1 - 0, Py: l1.Y1 + 0 };
            }
            if (l3.X1 > l3.X2) {
                p3 = { Px: l3.X2 + 0, Py: l3.Y2 - 0 };
            }
            else {
                p3 = { Px: l3.X1 + 0, Py: l3.Y1 - 0 };
            }
            if (l4.X1 < l4.X2) {
                p5 = { Px: l4.X2 - 0, Py: l4.Y2 - 0 };
            }
            else {
                p5 = { Px: l4.X1 - 0, Py: l4.Y1 - 0 };
            }
            if (l0.X1 > l0.X2) {
                p0 = { Px: l0.X2 + 0, Py: l0.Y2 + 0 };
            }
            else {
                p0 = { Px: l0.X1 + 0, Py: l0.Y1 + 0 };
            }
            ar.push(p0);
            ar.push(p1);
            ar.push(p2);
            ar.push(p3);
            ar.push(p4);
            ar.push(p5);
        }
        this.arr = ar;
        return ar;
    }

    //无法正常识别墙体时，默认的识别结果1：正对矩形墙面
     p.move3=function (w, h) { // w:房间照片宽度 h:房间照片高度
        //alert("默认处理");
         this.wallType = 0;
        this.walls = [0.25 * w, 0.25 * h, 0.25 * w, 0.75 * h];
        var arr = [0.1 * w, 0.1 * h, 0.25 * w, 0.25 * h, 0.75 * w, 0.25 * h, 0.9 * w, 0.1 * h, 0.1 * w, 0.9 * h, 0.25 * w, 0.75 * h, 0.75 * w, 0.75 * h, 0.9 * w, 0.9 * h];

        var ar = [];
        for (var i = 0; i < arr.length - 1 ; i += 2) {
            ar.push({ Px: arr[i], Py: arr[i + 1] });
        }
        this.arr = ar;
        return ar;
    }

    //无法正常识别墙体时，默认的识别结果2：正对竖墙角
     p.move4=function (w, h) { //w:房间照片宽度 h:房间照片高度
        //alert("默认处理");
         this.wallType = 1;
        this.walls = [0.5 * w, 0.3 * h, 0.5 * w, 0.7 * h];
        var arr = [0.1 * w, 0.1 * h, 0.5 * w, 0.3 * h, 0.9 * w, 0.1 * h, 0.1 * w, 0.9 * h, 0.5 * w, 0.7 * h, 0.9 * w, 0.9 * h];
        var ar = [];
        for (var i = 0; i < arr.length - 1 ; i += 2) {
            ar.push({ Px: arr[i], Py: arr[i + 1] });
        }
        this.arr = ar;
        return ar;
    }

    //墙体识别结果只有一面墙时(正对水平墙角)，处理识别结果
    p.move5=function (w, h) { //walls:未经过处理的识别结果数组 w:房间照片宽度 h:房间照片高度
        this.wallType = 2;
        this.walls = [0.0 * w, 0.3 * h, 0.0 * w, 0.7 * h];

        var arr = [0.0 * w, 0.0 * h, 0.0 * w, 0.3 * h,
                  1.0 * w, 0.3 * h, 1.0 * w, 0.0 * h,
                    0.0 * w, 1.0 * h, 0.0 * w, 0.7 * h,
                   1.0 * w, 0.7 * h, 1.0 * w, 1.0 * h];


        var ar = [];
        for (var i = 0; i < arr.length - 1 ; i += 2) {
            ar.push({ Px: arr[i], Py: arr[i + 1] });
        }
        this.arr = ar;
        return ar;
    }
    MyFA.WallLineModel = WallLineModel;
})();