﻿this.MyFurnitureAssistant = this.MyFurnitureAssistant || {};
// 定义别名(快捷名)：
if (typeof this.MyFA === 'undefined') {
    this.MyFA = this.MyFurnitureAssistant;
}
(function () {
    //用于初始化单位
    numberM = 2;
    numberDM = 70;

    var DrawTextM;
    var DrawTextMsmall;
    var DrawTextMbig;
    var DrawTextMsmall1;
    var DrawTextMbig1;

    var DrawTextDM;
    var DrawTextDMsmall;
    var DrawTextDMbig;
    var DrawTextDMsmall1;
    var DrawTextDMbig1;

    function Ruler(stage, walls, w, scale) {

        numberMsmall = numberM - 1;
        numberMbig = numberM + 1;
        numberMsmall1 = numberM - 2;
        numberMbig1 = numberM + 2;


        numberDMsmall = numberDM - 1;
        numberDMbig = numberDM + 1;
        numberDMsmall1 = numberDM - 2;
        numberDMbig1 = numberDM + 2;

        var ruleContainer = new createjs.Container();
        stage.addChild(ruleContainer);
        ruleContainer.name = "ruler";


        //画线
        var line = new createjs.Shape();
        line.graphics.beginStroke("#000000");
        line.graphics.setStrokeStyle(1);
        line.graphics.moveTo(0, 40);
        line.graphics.lineTo(210, 40);
        ruleContainer.addChild(line);
        //stage.update();


        //画线
        var line = new createjs.Shape();
        line.graphics.beginStroke("#000000");
        line.graphics.setStrokeStyle(1);
        line.graphics.moveTo(0, 80);
        line.graphics.lineTo(210, 80);
        ruleContainer.addChild(line);
        //stage.update();


        //画数字
        var numM = drawNumber(stage, ruleContainer, new createjs.Text(numberM.toString(), "36px Arial", "#000000"), 30, 40, '');
        //画数字
        var numMsmall = drawNumber(stage, ruleContainer, new createjs.Text(numberMsmall.toString(), "30px Arial", "#292929"), 30, 0, '');
        //画数字
        var numMbig = drawNumber(stage, ruleContainer, new createjs.Text(numberMbig.toString(), "30px Arial", "#292929"), 30, 80, '');
        var numMsmall1 = drawNumber(stage, ruleContainer, new createjs.Text(numberMsmall1.toString(), "24px Arial", "#6E6E6E"), 30, -40, '');
        //画数字
        var numMbig1 = drawNumber(stage, ruleContainer, new createjs.Text(numberMbig1.toString(), "24px Arial", "#6E6E6E"), 30, 120, '');

        //画小数点
        var point = drawNumber(stage, ruleContainer, new createjs.Text(".", "36px Arial", "#000000"), 80, 40, '');


        //画数字
        var numDM = drawNumber(stage, ruleContainer, new createjs.Text(numberDM.toString(), "36px Arial", "#000000"), 120, 40, '');
        var numDMsmall = drawNumber(stage, ruleContainer, new createjs.Text(numberDMsmall.toString(), "30px Arial", "#292929"), 120, 0, '');
        var numDMbig = drawNumber(stage, ruleContainer, new createjs.Text(numberDMbig.toString(), "30px Arial", "#292929"), 120, 80, '');
        var numDMsmall1 = drawNumber(stage, ruleContainer, new createjs.Text(numberDMsmall1.toString(), "24px Arial", "#6E6E6E"), 120, -40, '');
        //画数字
        var numDMbig1 = drawNumber(stage, ruleContainer, new createjs.Text(numberDMbig1.toString(), "24px Arial", "#6E6E6E"), 120, 120, '');

        //画单位
        var Unit = drawNumber(stage, ruleContainer, new createjs.Text("m", "36px Arial", "#000000"), 180, 40, '');

        //创建矩形对象  用于点击事件的容器 
        var Rect_M = drawRect(stage, ruleContainer, new createjs.Shape(), "#ffffff", 30, -40, 50, 200);


        var Rect_DM = drawRect(stage, ruleContainer, new createjs.Shape(), "#ffffff", 120, -40, 50, 200);


        //将 数字 numM设置为要被移除的对象,因为第一次点击要移除初始值
        DrawTextM = numM;
        DrawTextMsmall = numMsmall;
        DrawTextMbig = numMbig;
        DrawTextMsmall1 = numMsmall1;
        DrawTextMbig1 = numMbig1;

        var fm;
        Rect_M.addEventListener("mousedown", function (event) {
            fm = event.stageY;
        }, false);

        Rect_M.addEventListener("pressup", function (event) {
            if (event.stageY > fm) {
                clickSubtractM(stage, ruleContainer);
            }
            else {
                clickAddM(stage, ruleContainer);
            }
        }, false);


        //将 数字 numCM设置为要被移除的对象,因为第一次点击要移除初始值
        DrawTextDM = numDM;
        DrawTextDMsmall = numDMsmall;
        DrawTextDMbig = numDMbig;
        DrawTextDMsmall1 = numDMsmall1;
        DrawTextDMbig1 = numDMbig1;

        Rect_DM.addEventListener("mousedown", function (event) {
            fm = event.stageY;
        }, false);

        Rect_DM.addEventListener("pressup", function (event) {
            if (event.stageY > fm) {
                clickSubtractDM(stage, ruleContainer);

            }
            else {
                clickAddDM(stage, ruleContainer);
            }
        }, false);

        this.rulerPostion(stage, walls, w, scale);
    }
    var p = Ruler.prototype;
    p.rulerPostion = function (stage, walls, w, scale) {
        //尺子宽210，高120
        var ruleContainer = stage.getChildByName("ruler");

        var halfX = (walls[0] + walls[2]) * 0.5 * scale;
        var halfY = (walls[1] + walls[3]) * 0.5 * scale;

        if (halfX < 115) {
            ruleContainer.x = 0;
        }
        else if (halfX + 115 > w * scale) {
            ruleContainer.x = w * scale - 210;
        }
        else {
            ruleContainer.x = halfX - 115;
        }

        if (walls[1] <= walls[3]) {
            if (halfY - 60 < walls[1] * scale) {
                ruleContainer.y = walls[1] * scale;
            }
            else if (halfY + 60 > walls[3] * scale) {
                ruleContainer.y = walls[3] * scale - 120;
            }
            else {
                ruleContainer.y = halfY - 60;
            }
        }
        else {
            if (halfY - 60 < walls[3] * scale) {
                ruleContainer.y = walls[3] * scale;
            }
            else if (halfY + 60 > walls[1] * scale) {
                ruleContainer.y = walls[1] * scale - 120;
            }
            else {
                ruleContainer.y = halfY - 60;
            }
        }
        stage.update();
    }

    //增加米的方法
    function clickAddM(stage, container) {
        //米单位不能超过9.
        if (numberM == 9) {
            numberM = 0;
        }
        else {
            //单位米的值自增
            numberM++;
        }
        if (numberMsmall == 9) {
            numberMsmall = 0;
        }
        else {
            //单位米的值自增
            numberMsmall++;
        }
        if (numberMbig == 9) {
            numberMbig = 0;
        }
        else {
            //单位米的值自增
            numberMbig++;
        }
        if (numberMsmall1 == 9) {
            numberMsmall1 = 0;
        }
        else {
            //单位米的值自增
            numberMsmall1++;
        }
        if (numberMbig1 == 9) {
            numberMbig1 = 0;
        }
        else {
            //单位米的值自增
            numberMbig1++;
        }

        //使单位米 的值 被移除 到 舞台之外

        container.removeChild(DrawTextM);
        //重新画数字, 将自增的值画入,使得单位米 更新   并将对象赋值给要 移除的变量  使得下次点击改变值时  移除旧的值
        DrawTextM = drawNumber(stage, container, new createjs.Text(numberM.toString(), "36px Arial", "#000000"), 30, 40, '');

        container.removeChild(DrawTextMsmall);
        DrawTextMsmall = drawNumber(stage, container, new createjs.Text(numberMsmall.toString(), "30px Arial", "#292929"), 30, 0, '');

        container.removeChild(DrawTextMbig);
        DrawTextMbig = drawNumber(stage, container, new createjs.Text(numberMbig.toString(), "30px Arial", "#292929"), 30, 80, '');

        container.removeChild(DrawTextMsmall1);
        DrawTextMsmall1 = drawNumber(stage, container, new createjs.Text(numberMsmall1.toString(), "24px Arial", "#6E6E6E"), 30, -40, '');

        container.removeChild(DrawTextMbig1);
        DrawTextMbig1 = drawNumber(stage, container, new createjs.Text(numberMbig1.toString(), "24px Arial", "#6E6E6E"), 30, 120, '');

        stage.update();
    }


    //减少米的方法
    function clickSubtractM(stage, container) {
        //米单位不能超过9.
        if (numberM == 0) {
            numberM = 9;
        }
        else {
            //单位米的值自增
            numberM--;
        }
        if (numberMsmall == 0) {
            numberMsmall = 9;
        }
        else {
            //单位米的值自增
            numberMsmall--;
        }
        if (numberMbig == 0) {
            numberMbig = 9;
        }
        else {
            //单位米的值自增
            numberMbig--;
        }
        if (numberMsmall1 == 0) {
            numberMsmall1 = 9;
        }
        else {
            //单位米的值自增
            numberMsmall1--;
        }
        if (numberMbig1 == 0) {
            numberMbig1 = 9;
        }
        else {
            //单位米的值自增
            numberMbig1--;
        }
        container.removeChild(DrawTextM);
        //重新画数字, 将自增的值画入,使得单位米 更新   并将对象赋值给要 移除的变量  使得下次点击改变值时  移除旧的值
        DrawTextM = drawNumber(stage, container, new createjs.Text(numberM.toString(), "36px Arial", "#000000"), 30, 40, '');

        container.removeChild(DrawTextMsmall);
        DrawTextMsmall = drawNumber(stage, container, new createjs.Text(numberMsmall.toString(), "30px Arial", "#6E6E6E"), 30, 0, '');

        container.removeChild(DrawTextMbig);
        DrawTextMbig = drawNumber(stage, container, new createjs.Text(numberMbig.toString(), "30px Arial", "#6E6E6E"), 30, 80, '');

        container.removeChild(DrawTextMsmall1);
        DrawTextMsmall1 = drawNumber(stage, container, new createjs.Text(numberMsmall1.toString(), "24px Arial", "#6E6E6E"), 30, -40, '');

        container.removeChild(DrawTextMbig1);
        DrawTextMbig1 = drawNumber(stage, container, new createjs.Text(numberMbig1.toString(), "24px Arial", "#6E6E6E"), 30, 120, '');
        stage.update();
    }

    //增加分米的方法
    function clickAddDM(stage, container) {
        if (numberDM == 99) {
            numberDM = 0;
            //numberM++;
        }
        else {
            //单位米的值自增
            numberDM++;
        }
        if (numberDMsmall == 99) {
            numberDMsmall = 0;
        }
        else {
            //单位米的值自增
            numberDMsmall++;
        }
        if (numberDMbig == 99) {
            numberDMbig = 0;
        }
        else {
            //单位米的值自增
            numberDMbig++;
        }
        if (numberDMsmall1 == 99) {
            numberDMsmall1 = 0;
        }
        else {
            //单位米的值自增
            numberDMsmall1++;
        }
        if (numberDMbig1 == 99) {
            numberDMbig1 = 0;
        }
        else {
            //单位米的值自增
            numberDMbig1++;
        }
        container.removeChild(DrawTextDM);
        //重新画数字, 将自增的值画入,使得单位米 更新   并将对象赋值给要 移除的变量  使得下次点击改变值时  移除旧的值
        DrawTextDM = drawNumber(stage, container, new createjs.Text(numberDM.toString(), "36px Arial", "#000000"), 120, 40, '');

        container.removeChild(DrawTextDMsmall);
        DrawTextDMsmall = drawNumber(stage, container, new createjs.Text(numberDMsmall.toString(), "30px Arial", "#292929"), 120, 0, '');

        container.removeChild(DrawTextDMbig);
        DrawTextDMbig = drawNumber(stage, container, new createjs.Text(numberDMbig.toString(), "30px Arial", "#292929"), 120, 80, '');

        container.removeChild(DrawTextDMsmall1);
        DrawTextDMsmall1 = drawNumber(stage, container, new createjs.Text(numberDMsmall1.toString(), "24px Arial", "#6E6E6E"), 120, -40, '');

        container.removeChild(DrawTextDMbig1);
        DrawTextDMbig1 = drawNumber(stage, container, new createjs.Text(numberDMbig1.toString(), "24px Arial", "#6E6E6E"), 120, 120, '');
        stage.update();
    }


    //减少分米的方法
    function clickSubtractDM(stage, container) {
        if (numberDM == 0) {
            numberDM = 99;
        }
        else {
            //单位米的值自增
            numberDM--;
        }
        if (numberDMsmall == 0) {
            numberDMsmall = 99;
        }
        else {
            //单位米的值自增
            numberDMsmall--;
        }
        if (numberDMbig == 0) {
            numberDMbig = 99;
        }
        else {
            //单位米的值自增
            numberDMbig--;
        }
        if (numberDMsmall1 == 0) {
            numberDMsmall1 = 99;
        }
        else {
            //单位米的值自增
            numberDMsmall1--;
        }
        if (numberDMbig1 == 0) {
            numberDMbig1 = 99;
        }
        else {
            //单位米的值自增
            numberDMbig1--;
        }
        container.removeChild(DrawTextDM);
        //重新画数字, 将自增的值画入,使得单位米 更新   并将对象赋值给要 移除的变量  使得下次点击改变值时  移除旧的值
        DrawTextDM = drawNumber(stage, container, new createjs.Text(numberDM.toString(), "36px Arial", "#000000"), 120, 40, '');

        container.removeChild(DrawTextDMsmall);
        DrawTextDMsmall = drawNumber(stage, container, new createjs.Text(numberDMsmall.toString(), "30px Arial", "#292929"), 120, 0, '');

        container.removeChild(DrawTextDMbig);
        DrawTextDMbig = drawNumber(stage, container, new createjs.Text(numberDMbig.toString(), "30px Arial", "#292929"), 120, 80, '');

        container.removeChild(DrawTextDMsmall1);
        DrawTextDMsmall1 = drawNumber(stage, container, new createjs.Text(numberDMsmall1.toString(), "24px Arial", "#6E6E6E"), 120, -40, '');

        container.removeChild(DrawTextDMbig1);
        DrawTextDMbig1 = drawNumber(stage, container, new createjs.Text(numberDMbig1.toString(), "24px Arial", "#6E6E6E"), 120, 120, '');
        stage.update();
    }

    //写字方法
    function drawNumber(stage, containerObj, textObj, x, y, TextBaseline) {
        var text = textObj;
        text.x = x;
        text.y = y;
        if (TextBaseline != null || TextBaseline != '') {
            text.textBaseline = TextBaseline;
        }
        containerObj.addChild(text);
        //stage.update();
        return text;
    }
    //创建矩形
    function drawRect(stage, containerObj, rectObj, colorStr, x, y, XL, YL) {
        var Rect = rectObj;
        Rect.graphics.beginFill(colorStr);
        Rect.alpha = 0.01;
        Rect.graphics.drawRect(x, y, XL, YL);
        containerObj.addChild(Rect);
        //stage.update();
        return Rect;
    }
    MyFA.Ruler = Ruler;
})();
