this.MyFurnitureAssistant = this.MyFurnitureAssistant || {};
// 定义别名(快捷名)：
if (typeof this.MyFA === "undefined") {
  this.MyFA = this.MyFurnitureAssistant;
}
(function () {
  "use strict";
  function FurnitureModel(furnitureId) {
    _this = this;
    //是否被保存过
    _this.hasBeenSaved;
    //是否进行自动吸附(初始设置为false)
    _this.isAutoAttatch = false;
    //是否进行区域限制(初始设置为true)
    _this.isRegionRestrict = true;

    //设置家具的初始默认亮度
    _this.furnitureBrightness = 50;

    //手指按下家具时在场景中的位置（用以区分家具的前后顺序）
    _this.sy;
    //是否处于被选中状态(初始设置为false)
    _this.isSelected = false;
    //家具图片四角的坐标（未乘场景比例）
    _this.leftUpPointX;
    _this.leftUpPointY;
    _this.rightUpPointX;
    _this.rightUpPointY;
    _this.leftDownPointX;
    _this.leftDownPointY;
    _this.rightDownPointX;
    _this.rightDownPointY;
    //家具的初始缩放比例（未乘场景比例）
    _this.initScaleX;
    _this.initScaleY;
    //家具的实时缩放比例（未乘场景比例）
    _this.scaleX;
    _this.scaleY;
    //该model是否已被实例化
    _this.isInstanced;
    //该家具已被加载的角度图片的个数
    _this.ImgLoaded = 0;

    //家具在数据库中的主键
    _this.furnitureID;
    //家具安装类型
    _this.installedType;
    //家具实际高度
    _this.CustomProductHeight;
    _this.ProductHeight;
    //家具实际宽度
    _this.CustomProductWidth;
    _this.ProductWidth;
    //家具实际厚度
    _this.CustomProductThickness;
    _this.ProductThickness;
    //种类ID
    _this.CategoryID;
    //家具角度图片集合
    _this.Pics;
    _this.picIndex;
    _this.pixWidth;
    //家具照片高度
    _this.pixHeigh;
    //家具图片路径
    _this.imgSrc;
    _this.picAngle;
    //家具外接长方体的八个点
    _this.bblX;
    _this.bblY;
    _this.bbrX;
    _this.bbrY;
    _this.btlX;
    _this.btlY;
    _this.btrX;
    _this.btrY;
    _this.fblX;
    _this.fblY;
    _this.fbrX;
    _this.fbrY;
    _this.ftlX;
    _this.ftlY;
    _this.ftrX;
    _this.ftrY;
    //选中时是否需要添加一层透明阴影
    _this.isNeedShadow;

    //如果不是从已有设计打开的
    if (furnitureId != undefined) {
      //TODO 分离从服务器读还是从文件读，单独写成私有函数
      //将“是否被保存过”这个标志设为false
      _this.hasBeenSaved = false;

      var url =
        window.webUrl +
        "webService/ProductInfo.asmx/GetFurnitureByID?FurnitureID={0}".format(
          furnitureId
        );
      $.ajax({
        url: url,
        type: "GET",
        dataType: "JSONP",
        success: _this.SuccessInstanced,
      });
    }
  }

  //验证角度图片是否成功加载完成
  function validateImages() {
    _this.ImgLoaded++;
    //alert("ImgLoaded:" + _this.ImgLoaded);
    if (_this.ImgLoaded == _this.Pics.length) {
      //设置_this.isInstanced属性，表明已被实例过
      _this.isInstanced = true;
    }
  }

  var _this; //当前实例化的对象
  // 实例方法声明
  /////通过原型往类中添加方法和属性
  var p = FurnitureModel.prototype;

  //从数据库获取数据成功后，对model的重要属性进行赋值
  p.SuccessInstanced = function (data) {
    _this.furnitureID = data.detail[0].pid;
    //家具安装类型
    //0、地面；1、灯具；2、艺术画
    //3：地板  4：壁纸  5 ：花瓶等饰物
    //6:门     7：窗帘
    _this.installedType = data.detail[0].installedtype;

    //家具实际高度
    _this.CustomProductHeight = _this.ProductHeight =
      data.detail[0].productheight;
    //家具实际宽度
    _this.CustomProductWidth = _this.ProductWidth = data.detail[0].productwidth;
    //家具实际厚度
    _this.CustomProductThickness = _this.ProductThickness =
      data.detail[0].productthickness;
    _this.CategoryID = data.detail[0].cateid;
    _this.isNeedShadow = data.detail[0].isneedshadow;

    if (data.detail[0].arrengementpics.length > 0) {
      //家具照片宽度
      _this.Pics = data.detail[0].arrengementpics;
      _this.picIndex = 0;
      _this.pixWidth = data.detail[0].arrengementpics[0].productimgwidth;
      //家具照片高度
      _this.pixHeight = data.detail[0].arrengementpics[0].productimgheight;
      //家具图片路径
      _this.imgSrc =
        window.webUrl + data.detail[0].arrengementpics[0].productimgsrc;
      _this.picAngle = data.detail[0].arrengementpics[0].picangle;

      _this.bblX =
        data.detail[0].arrengementpics[0].bblpx != null
          ? data.detail[0].arrengementpics[0].bblpx
          : 0;
      _this.bblY =
        data.detail[0].arrengementpics[0].bblpy != null
          ? data.detail[0].arrengementpics[0].bblpy
          : 0;
      _this.bbrX =
        data.detail[0].arrengementpics[0].bbrpx != null
          ? data.detail[0].arrengementpics[0].bbrpx
          : 0;
      _this.bbrY =
        data.detail[0].arrengementpics[0].bbrpy != null
          ? data.detail[0].arrengementpics[0].bbrpy
          : 0;
      _this.btlX =
        data.detail[0].arrengementpics[0].btlpx != null
          ? data.detail[0].arrengementpics[0].btlpx
          : 0;
      _this.btlY =
        data.detail[0].arrengementpics[0].btlpy != null
          ? data.detail[0].arrengementpics[0].btlpy
          : 0;
      _this.btrX =
        data.detail[0].arrengementpics[0].btrpx != null
          ? data.detail[0].arrengementpics[0].btrpx
          : 0;
      _this.btrY =
        data.detail[0].arrengementpics[0].btrpy != null
          ? data.detail[0].arrengementpics[0].btrpy
          : 0;
      _this.fblX =
        data.detail[0].arrengementpics[0].fblpx != null
          ? data.detail[0].arrengementpics[0].fblpx
          : 0;
      _this.fblY =
        data.detail[0].arrengementpics[0].fblpy != null
          ? data.detail[0].arrengementpics[0].fblpy
          : 0;
      _this.fbrX =
        data.detail[0].arrengementpics[0].fbrpx != null
          ? data.detail[0].arrengementpics[0].fbrpx
          : 0;
      _this.fbrY =
        data.detail[0].arrengementpics[0].fbrpy != null
          ? data.detail[0].arrengementpics[0].fbrpy
          : 0;
      _this.ftlX =
        data.detail[0].arrengementpics[0].ftlpx != null
          ? data.detail[0].arrengementpics[0].ftlpx
          : 0;
      _this.ftlY =
        data.detail[0].arrengementpics[0].ftlpy != null
          ? data.detail[0].arrengementpics[0].ftlpy
          : 0;
      _this.ftrX =
        data.detail[0].arrengementpics[0].ftrpx != null
          ? data.detail[0].arrengementpics[0].ftrpx
          : 0;
      _this.ftrY =
        data.detail[0].arrengementpics[0].ftrpy != null
          ? data.detail[0].arrengementpics[0].ftrpy
          : 0;

      //预加载所有角度图片
      var Imgs = new Array(_this.Pics.length);
      //alert(_this.Pics.length);
      // alert('图片加载中请稍等......');
      for (var i = 0; i < Imgs.length; i++) {
        //alert("i:" + i);
        Imgs[i] = new Image();
        Imgs[i].crossOrigin = "Anonymous";
        Imgs[i].src = window.webUrl + _this.Pics[i].productimgsrc;
        Imgs[i].onLoad = validateImages();
      }
    } else {
      _this.Pics = [];
      _this.pixWidth = 500;
      //家具照片高度
      _this.pixHeight = 500;
      //家具图片路径
      _this.imgSrc = "";
      _this.picAngle = 0;
      _this.bblX = 0;
      _this.bblY = 0;
      _this.bbrX = 0;
      _this.bbrY = 0;
      _this.btlX = 0;
      _this.btlY = 0;
      _this.btrX = 0;
      _this.btrY = 0;
      _this.fblX = 0;
      _this.fblY = 0;
      _this.fbrX = 0;
      _this.fbrY = 0;
      _this.ftlX = 0;
      _this.ftlY = 0;
      _this.ftrX = 0;
      _this.ftrY = 0;
    }
    ////设置_this.isInstanced属性，表明已被实例过
    //_this.isInstanced = true;
  };

  //家具初始缩放Y比例
  p.InitScalerY = function () {
    var walls = this.parent.WallLineModel.walls;
    //var DisplayScale = this.ProductHeight * Math.abs(walls[3] - walls[1]) / this.parent.WallDenote / this.pixHeight;
    var DisplayScale;
    if (this.picAngle >= 0) {
      DisplayScale =
        (this.ProductHeight * Math.abs(walls[3] - walls[1])) /
        this.parent.WallDenote /
        Math.abs(this.bblY - this.btlY);
    } else {
      DisplayScale =
        (this.ProductHeight * Math.abs(walls[3] - walls[1])) /
        this.parent.WallDenote /
        Math.abs(this.bbrY - this.btrY);
    }
    DisplayScale = 0.4;
    return DisplayScale;
  };

  //家具初始缩放X比例
  p.InitScalerX = function () {
    var walls = this.parent.WallLineModel.walls;
    var DisplayScale =
      (this.ProductWidth * Math.abs(walls[3] - walls[1])) /
      this.parent.WallDenote /
      this.pixWidth;
    DisplayScale = 0.4;
    return DisplayScale;
  };

  //更新家具的初始缩放比例(未乘场景比例)
  p.updateInitScale = function (initScaleX, initScaleY) {
    this.initScaleX = initScaleX;
    this.initScaleY = initScaleY;
  };

  //更新家具的实时缩放比例(未乘场景比例)
  p.updateRealTimeScale = function (scaleX, scaleY) {
    this.scaleX = scaleX;
    this.scaleY = scaleY;
  };

  //用bbl的坐标分别推算出家具图片四角的坐标
  p.setFurLocationBybbl = function (bblX, bblY, scaleX, scaleY) {
    this.leftUpPointX = (0 - this.bblX) * scaleX + bblX;
    this.leftUpPointY = (0 - this.bblY) * scaleY + bblY;
    this.rightUpPointX = (this.pixWidth - this.bblX) * scaleX + bblX;
    this.rightUpPointY = (0 - this.bblY) * scaleY + bblY;
    this.leftDownPointX = (0 - this.bblX) * scaleX + bblX;
    this.leftDownPointY = (this.pixHeight - this.bblY) * scaleY + bblY;
    this.rightDownPointX = (this.pixWidth - this.bblX) * scaleX + bblX;
    this.rightDownPointY = (this.pixHeight - this.bblY) * scaleY + bblY;
  };

  //用bbr的坐标分别推算出家具图片四角的坐标
  p.setFurLocationBybbr = function (bbrX, bbrY, scaleX, scaleY) {
    this.leftUpPointX = (0 - this.bbrX) * scaleX + bbrX;
    this.leftUpPointY = (0 - this.bbrY) * scaleY + bbrY;
    this.rightUpPointX = (this.pixWidth - this.bbrX) * scaleX + bbrX;
    this.rightUpPointY = (0 - this.bbrY) * scaleY + bbrY;
    this.leftDownPointX = (0 - this.bbrX) * scaleX + bbrX;
    this.leftDownPointY = (this.pixHeight - this.bbrY) * scaleY + bbrY;
    this.rightDownPointX = (this.pixWidth - this.bbrX) * scaleX + bbrX;
    this.rightDownPointY = (this.pixHeight - this.bbrY) * scaleY + bbrY;
  };

  //用fbl的坐标分别推算出家具图片四角的坐标
  p.setFurLocationByfbl = function (fblX, fblY, scaleX, scaleY) {
    this.leftUpPointX = (0 - this.fblX) * scaleX + fblX;
    this.leftUpPointY = (0 - this.fblY) * scaleY + fblY;
    this.rightUpPointX = (this.pixWidth - this.fblX) * scaleX + fblX;
    this.rightUpPointY = (0 - this.fblY) * scaleY + fblY;
    this.leftDownPointX = (0 - this.fblX) * scaleX + fblX;
    this.leftDownPointY = (this.pixHeight - this.fblY) * scaleY + fblY;
    this.rightDownPointX = (this.pixWidth - this.fblX) * scaleX + fblX;
    this.rightDownPointY = (this.pixHeight - this.fblY) * scaleY + fblY;
  }; ////无

  //用fbr的坐标分别推算出家具图片四角的坐标
  p.setFurLocationByfbr = function (fbrX, fbrY, scaleX, scaleY) {
    this.leftUpPointX = (0 - this.fbrX) * scaleX + fbrX;
    this.leftUpPointY = (0 - this.fbrY) * scaleY + fbrY;
    this.rightUpPointX = (this.pixWidth - this.fbrX) * scaleX + fbrX;
    this.rightUpPointY = (0 - this.fbrY) * scaleY + fbrY;
    this.leftDownPointX = (0 - this.fbrX) * scaleX + fbrX;
    this.leftDownPointY = (this.pixHeight - this.fbrY) * scaleY + fbrY;
    this.rightDownPointX = (this.pixWidth - this.fbrX) * scaleX + fbrX;
    this.rightDownPointY = (this.pixHeight - this.fbrY) * scaleY + fbrY;
  }; ////无

  //用图片左上角坐标推算出家具图片四角的坐标
  p.setFurLocationByLeftUp = function (leftUpPointX, leftUpPointY) {
    this.leftUpPointX = leftUpPointX;
    this.leftUpPointY = leftUpPointY;
    this.rightUpPointX = this.pixWidth * this.scaleX + leftUpPointX;
    this.rightUpPointY = leftUpPointY;
    this.leftDownPointX = leftUpPointX;
    this.leftDownPointY = this.pixHeight * this.scaleY + leftUpPointY;
    this.rightDownPointX = this.pixWidth * this.scaleX + leftUpPointX;
    this.rightDownPointY = this.pixHeight * this.scaleY + leftUpPointY;
  }; ////无

  //用图片左下角坐标推算出家具图片四角的坐标
  p.setFurLocationByLeftDown = function (leftDownPointX, leftDownPointY) {
    this.leftUpPointX = leftDownPointX;
    this.leftUpPointY = leftDownPointY - this.pixHeight * this.scaleY;

    this.rightUpPointX = this.pixWidth * this.scaleX + leftDownPointX;
    this.rightUpPointY = leftDownPointY - this.pixHeight * this.scaleY;

    this.leftDownPointX = leftDownPointX;
    this.leftDownPointY = leftDownPointY;

    this.rightDownPointX = this.pixWidth * this.scaleX + leftDownPointX;
    this.rightDownPointY = leftDownPointY;
  };

  //计算家具初始放入场景时应该呈现的角度
  p.calInitDisplayAngle = function () {
    var pl, //放置在左墙时应该呈现的角度
      pr; //放置在右墙时应该呈现的角度

    var photoSceneModel = this.parent;

    //如果是正对墙面情况下,则角度=0（放置角度为0的图片）
    if (photoSceneModel.WallLineModel.arr.length == 8) {
      pr = 90;
      pl = 0;
    }
    //如果是正对墙角情况下,则分别计算左右墙与水平线的夹角
    else {
      pr = photoSceneModel.pr;
      pl = photoSceneModel.pl;
    }

    //计算出的角度分别加上场景偏移角度
    pl = Math.floor(pl + photoSceneModel.OffsetAngleX);
    pr = Math.floor(pr + photoSceneModel.OffsetAngleX);

    //在所有角度图片中，找出与pl最接近的一张图片
    var picIndexLeft = this.selectSuitablePictureByAngle(pl);
    // var angleDiffLeft = Math.abs(this.Pics[picIndexLeft].picangle - pl);

    //在所有角度图片中，找出与pr最接近的一张图片
    var picIndexRight = this.selectSuitablePictureByAngle(pr);
    // var angleDiffRight = Math.abs(this.Pics[picIndexRight].picangle - pr);

    var picIndex = 0;
    //左墙和右墙的角度之差进行比较，哪边的角度之差小，就放在哪边
    //判断家具的放置位置（左墙、右墙或水平墙）
    // if (angleDiffLeft <= angleDiffRight) {
    //   picIndex = picIndexLeft;
    // } else {
    //   picIndex = picIndexRight;
    // }

    //记录照片信息
    this.LogSelectedPicInfo(picIndex);
  };

  //根据角度，从角度照片集合中找出角度与其最接近的照片
  //返回值：最合适角度照片的索引
  p.selectSuitablePictureByAngle = function (calAngle) {
    //calAngle:理想角度
    var angleDiff = Math.abs(this.picAngle - calAngle);
    //记录家具目前的角度图片index
    var anglePicIndex = this.picIndex;
    //在所有角度图片中，找出与计算出来的角度最接近的一张图片显示
    // console.log(this.Pics.length);
    // for (var i = 0; i < this.Pics.length; i++) {
    //   //如果Math.abs(this.Pics[i].PicAngle - calAngle) < angleDiff
    //   if (Math.abs(this.Pics[i].picangle - calAngle) < angleDiff) {
    //     angleDiff = Math.abs(this.Pics[i].picangle - calAngle);
    //     anglePicIndex = i;
    //   }
    // }
    //返回角度照片的索引
    return anglePicIndex;
  };

  //根据照片索引，记录当前家具照片的一系列信息
  /////进入
  p.LogSelectedPicInfo = function (anglePicIndex) {
    //anglePicIndex:角度照片索引
    this.picIndex = anglePicIndex;
    // this.imgSrc = window.webUrl + this.Pics[anglePicIndex].productimgsrc;
    // this.picAngle = this.Pics[anglePicIndex].picangle;
    // //家具照片宽度
    // this.pixWidth = this.Pics[anglePicIndex].productimgwidth;
    //家具照片高度
    // this.pixHeight = this.Pics[anglePicIndex].productimgheight;
    // this.imgSrc = this.Pics[0].productimgsrc;
    this.picAngle = 0;
    // this.pixWidth = 500;
    // this.pixHeight = 500;

    // this.bblX =
    //   this.Pics[anglePicIndex].bblpx != null
    //     ? this.Pics[anglePicIndex].bblpx
    //     : 0;
    // this.bblY =
    //   this.Pics[anglePicIndex].bblpy != null
    //     ? this.Pics[anglePicIndex].bblpy
    //     : 0;
    // this.bbrX =
    //   this.Pics[anglePicIndex].bbrpx != null
    //     ? this.Pics[anglePicIndex].bbrpx
    //     : 0;
    // this.bbrY =
    //   this.Pics[anglePicIndex].bbrpy != null
    //     ? this.Pics[anglePicIndex].bbrpy
    //     : 0;
    // this.btlX =
    //   this.Pics[anglePicIndex].btlpx != null
    //     ? this.Pics[anglePicIndex].btlpx
    //     : 0;
    // this.btlY =
    //   this.Pics[anglePicIndex].btlpy != null
    //     ? this.Pics[anglePicIndex].btlpy
    //     : 0;
    // this.btrX =
    //   this.Pics[anglePicIndex].btrpx != null
    //     ? this.Pics[anglePicIndex].btrpx
    //     : 0;
    // this.btrY =
    //   this.Pics[anglePicIndex].btrpy != null
    //     ? this.Pics[anglePicIndex].btrpy
    //     : 0;
    // this.fblX =
    //   this.Pics[anglePicIndex].fblpx != null
    //     ? this.Pics[anglePicIndex].fblpx
    //     : 0;
    // this.fblY =
    //   this.Pics[anglePicIndex].fblpy != null
    //     ? this.Pics[anglePicIndex].fblpy
    //     : 0;
    // this.fbrX =
    //   this.Pics[anglePicIndex].fbrpx != null
    //     ? this.Pics[anglePicIndex].fbrpx
    //     : 0;
    // this.fbrY =
    //   this.Pics[anglePicIndex].fbrpy != null
    //     ? this.Pics[anglePicIndex].fbrpy
    //     : 0;
    // this.ftlX =
    //   this.Pics[anglePicIndex].ftlpx != null
    //     ? this.Pics[anglePicIndex].ftlpx
    //     : 0;
    // this.ftlY =
    //   this.Pics[anglePicIndex].ftlpy != null
    //     ? this.Pics[anglePicIndex].ftlpy
    //     : 0;
    // this.ftrX =
    //   this.Pics[anglePicIndex].ftrpx != null
    //     ? this.Pics[anglePicIndex].ftrpx
    //     : 0;
    // this.ftrY =
    //   this.Pics[anglePicIndex].ftrpy != null
    //     ? this.Pics[anglePicIndex].ftrpy
    //     : 0;
  };

  //手动调整家具长宽高以后更新家具model相关信息
  //newFurnitureWidth:自定义宽度
  //newFurnitureHeight:自定义高度
  //newFurnitureThickness: 自定义厚度
  p.updateFurInfoAfertSizeChange = function (
    newFurnitureWidth,
    newFurnitureHeight,
    newFurnitureThickness
  ) {
    //计算家具各种参数在现有基础上应该乘的比例（新的自定义尺寸/旧的自定义尺寸）
    var customWidthScale = newFurnitureWidth / this.CustomProductWidth;
    var customHeightScale = newFurnitureHeight / this.CustomProductHeight;

    //alert(customWidthScale);
    //alert(customHeightScale);

    //记录用户最新自定义的长宽高
    this.setCustomSize(
      newFurnitureWidth,
      newFurnitureHeight,
      newFurnitureThickness
    );

    //修改家具的缩放比例
    this.updateRealTimeScale(
      this.scaleX * customWidthScale,
      this.scaleY * customHeightScale
    );

    //修改家具图片四角的坐标
    if (
      this.installedType != 2 &&
      this.installedType != 6 &&
      this.installedType != 7
    ) {
      this.setFurLocationByLeftDown(this.leftDownPointX, this.leftDownPointY);
    } else {
      //如果是壁挂类家具
      //分别判断所在墙面的位置
      switch (this.location) {
        case 0:
          this.StretchFurnitureInLeftWall(this.leftUpPointX, this.leftUpPointY);
          break;
        case 1:
          this.StretchFurnitureInMiddleWall(
            this.leftUpPointX,
            this.leftUpPointY
          );
          break;
        case 2:
          this.StretchFurnitureInRightWall(
            this.rightUpPointX,
            this.rightUpPointY
          );
          break;
      }
    }

    //修改家具的初始放置比例
    this.updateInitScale(
      this.initScaleX * customWidthScale,
      this.initScaleY * customHeightScale
    );
  }; ////无

  //设置家具的自定义长宽高
  //newFurnitureWidth:自定义宽度
  //newFurnitureHeight:自定义高度
  //newFurnitureThickness: 自定义厚度
  p.setCustomSize = function (
    newFurnitureWidth,
    newFurnitureHeight,
    newFurnitureThickness
  ) {
    this.CustomProductWidth = newFurnitureWidth;
    this.CustomProductHeight = newFurnitureHeight;
    this.CustomProductThickness = newFurnitureThickness;
  }; ////无

  //水平墙上拉伸家具
  //locationPointX:（悬挂式）家具定位点X坐标
  //locationPointY:（悬挂式）家具定位点Y坐标

  p.StretchFurnitureInMiddleWall = function (locationPointX, locationPointY) {
    //alert(this.parent.OffsetAngleX);
    var arr = this.parent.WallLineModel.arr;
    var dp = MyFA.CommonFunction.segmentsIntr(arr[1], arr[2], arr[5], arr[6]); //求两条线交点坐标

    //如果上下两条墙线没有交点，则不进行校正
    if (!dp) {
      //先确定图片左边两点
      this.leftUpPointX = locationPointX;
      this.leftUpPointY = locationPointY;
      this.leftDownPointX =
        (this.bblX - this.btlX) * this.scaleX + this.leftUpPointX;
      this.leftDownPointY =
        (this.bblY - this.btlY) * this.scaleY + this.leftUpPointY;
      this.rightUpPointX =
        (this.btrX - this.btlX) * this.scaleX + this.leftUpPointX;
      this.rightUpPointY =
        (this.btrY - this.btlY) * this.scaleY + this.leftUpPointY;
      this.rightDownPointX =
        (this.bbrX - this.btlX) * this.scaleX + this.leftUpPointX;
      this.rightDownPointY =
        (this.bbrY - this.btlY) * this.scaleY + this.leftUpPointY;
    }
    //如果上下两条墙线有交点，则进行校正
    else {
      //如果拍摄的照片偏左，则以左上角进行定位
      if (this.parent.OffsetAngleX <= 0) {
        var leftWallPix = MyFA.CommonFunction.getDistanceOfPointToPoint(
          arr[6].Px,
          arr[6].Py,
          arr[5].Px,
          arr[5].Py
        );

        //stretcdScaleX=(arr[5].Px - arr[4].Px/左墙的像素长度)*家具不进行伸拉时的X比例
        var stretcdScaleX =
          ((arr[6].Px - arr[5].Px) / leftWallPix) * this.scaleX;
        //var stretcdScaleX = 1;

        //先确定图片左边两点
        this.leftUpPointX = locationPointX;
        this.leftUpPointY = locationPointY;
        this.leftDownPointX =
          (this.bblX - this.btlX) * this.scaleX + this.leftUpPointX;
        this.leftDownPointY =
          (this.bblY - this.btlY) * 1.2 * this.scaleY + this.leftUpPointY;
        //this.leftDownPointY = leftDownY;

        //右上角点=左上角与右墙灭点的连线，与图片右边两点连线的交点
        //根据stretcdScaleX确定右边两点的X坐标
        this.rightUpPointX =
          (this.btrX - this.btlX) * stretcdScaleX + this.leftUpPointX;
        var poLeftUp = { Px: this.leftUpPointX, Py: this.leftUpPointY };
        var equationLeftUp = MyFA.CommonFunction.calLinearEquationByPoints(
          poLeftUp,
          dp
        );
        this.rightUpPointY =
          (equationLeftUp.c * -1 - equationLeftUp.a * this.rightUpPointX) /
          equationLeftUp.b;

        //右下角点=左下角与右墙灭点的连线，与图片右边两点连线的交点
        this.rightDownPointX =
          (this.bbrX - this.btlX) * stretcdScaleX + this.leftUpPointX;
        var poLeftDown = { Px: this.leftDownPointX, Py: this.leftDownPointY };
        var equationLeftDown = MyFA.CommonFunction.calLinearEquationByPoints(
          poLeftDown,
          dp
        );
        this.rightDownPointY =
          (equationLeftDown.c * -1 -
            equationLeftDown.a * this.rightDownPointX) /
          equationLeftDown.b;
      }
      //如果拍摄的照片偏右，则以右上角进行定位
      else {
        var leftWallPix = MyFA.CommonFunction.getDistanceOfPointToPoint(
          arr[6].Px,
          arr[6].Py,
          arr[5].Px,
          arr[5].Py
        );
        //stretcdScaleX=(arr[5].Px - arr[4].Px/左墙的像素长度)*家具不进行伸拉时的X比例
        var stretcdScaleX =
          ((arr[6].Px - arr[5].Px) / leftWallPix) * this.scaleX;
        //var stretcdScaleX = 1;

        //先确定图片右边两点
        this.rightUpPointX = locationPointX;
        this.rightUpPointY = locationPointY;
        this.rightDownPointX =
          (this.bbrX - this.btrX) * this.scaleX + this.rightUpPointX;
        this.rightDownPointY =
          (this.bbrY - this.btrY) * 1.2 * this.scaleY + this.rightUpPointY;
        //this.rightDownPointY = rightDownY;

        //根据stretcdScaleX确定左边两点的X坐标
        //左上角点=右上角与左墙灭点的连线，与图片左边两点连线的交点
        this.leftUpPointX =
          (this.btlX - this.btrX) * stretcdScaleX + this.rightUpPointX;
        var poRightUp = { Px: this.rightUpPointX, Py: this.rightUpPointY };
        var equationRightUp = MyFA.CommonFunction.calLinearEquationByPoints(
          poRightUp,
          dp
        );
        this.leftUpPointY =
          (equationRightUp.c * -1 - equationRightUp.a * this.leftUpPointX) /
          equationRightUp.b;

        //左下角点=右下角与左墙灭点的连线，与图片左边两点连线的交点
        this.leftDownPointX =
          (this.bblX - this.btrX) * stretcdScaleX + this.rightUpPointX;
        var poRightDown = {
          Px: this.rightDownPointX,
          Py: this.rightDownPointY,
        };
        var equationRightDown = MyFA.CommonFunction.calLinearEquationByPoints(
          poRightDown,
          dp
        );
        this.leftDownPointY =
          (equationRightDown.c * -1 -
            equationRightDown.a * this.leftDownPointX) /
          equationRightDown.b;
      }
    }

    this.location = 1;
  };

  //左墙时伸拉图片
  //locationPointX:（悬挂式）家具定位点X坐标
  //locationPointY:（悬挂式）家具定位点Y坐标
  //该定位点是左上角
  p.StretchFurnitureInLeftWall = function (locationPointX, locationPointY) {
    var arr = this.parent.WallLineModel.arr;
    var dpOfLeftWall, dpOfRightWall;
    var stretcdScaleX, //在左墙时家具应该呈现的X比例
      leftWallPix; //左墙的像素长度（左墙两个像素坐标的距离)

    if (arr.length == 8) {
      //左墙灭点
      dpOfLeftWall = MyFA.CommonFunction.segmentsIntr(
        arr[2],
        arr[3],
        arr[6],
        arr[7]
      );
      //右边墙灭点
      dpOfRightWall = MyFA.CommonFunction.segmentsIntr(
        arr[0],
        arr[1],
        arr[4],
        arr[5]
      );

      leftWallPix = MyFA.CommonFunction.getDistanceOfPointToPoint(
        arr[4].Px,
        arr[4].Py,
        arr[5].Px,
        arr[5].Py
      );
      //stretcdScaleX=(arr[5].Px - arr[4].Px/左墙的像素长度)*家具不进行伸拉时的X比例
      stretcdScaleX = ((arr[5].Px - arr[4].Px) / leftWallPix) * this.scaleX;
    } else {
      //左墙灭点
      dpOfLeftWall = MyFA.CommonFunction.segmentsIntr(
        arr[1],
        arr[2],
        arr[4],
        arr[5]
      );
      //右边墙灭点
      dpOfRightWall = MyFA.CommonFunction.segmentsIntr(
        arr[0],
        arr[1],
        arr[3],
        arr[4]
      );

      leftWallPix = MyFA.CommonFunction.getDistanceOfPointToPoint(
        arr[3].Px,
        arr[3].Py,
        arr[4].Px,
        arr[4].Py
      );
      //stretcdScaleX=(arr[4].Px - arr[3].Px/左墙的像素长度)*家具不进行伸拉时的X比例
      stretcdScaleX = ((arr[4].Px - arr[3].Px) / leftWallPix) * this.scaleX;
    }

    if (!dpOfLeftWall || !dpOfRightWall) {
      return;
    }

    //var d1 = MyFA.CommonFunction.getDistanceOfPointToPoint(dpOfRightWall.Px, dpOfRightWall.Py, locationPointX, locationPointY);
    //var d2 = MyFA.CommonFunction.getDistanceOfPointToPoint(dpOfRightWall.Px, dpOfRightWall.Py, arr[1].Px, arr[1].Py);

    //var leftDownY = (arr[5].Py - arr[1].Py) / (d2 / d1);

    //先确定图片左边两点
    this.leftUpPointX = locationPointX;
    this.leftUpPointY = locationPointY;
    this.leftDownPointX =
      (this.bblX - this.btlX) * this.scaleX + this.leftUpPointX;
    this.leftDownPointY =
      (this.bblY - this.btlY) * 1.2 * this.scaleY + this.leftUpPointY;
    //this.leftDownPointY = leftDownY;

    //右上角点=左上角与右墙灭点的连线，与图片右边两点连线的交点
    //根据stretcdScaleX确定右边两点的X坐标
    this.rightUpPointX =
      (this.btrX - this.btlX) * stretcdScaleX + this.leftUpPointX;
    var poLeftUp = { Px: this.leftUpPointX, Py: this.leftUpPointY };
    var equationLeftUp = MyFA.CommonFunction.calLinearEquationByPoints(
      poLeftUp,
      dpOfRightWall
    );
    this.rightUpPointY =
      (equationLeftUp.c * -1 - equationLeftUp.a * this.rightUpPointX) /
      equationLeftUp.b;

    //右下角点=左下角与右墙灭点的连线，与图片右边两点连线的交点
    this.rightDownPointX =
      (this.bbrX - this.btlX) * stretcdScaleX + this.leftUpPointX;
    var poLeftDown = { Px: this.leftDownPointX, Py: this.leftDownPointY };
    var equationLeftDown = MyFA.CommonFunction.calLinearEquationByPoints(
      poLeftDown,
      dpOfRightWall
    );
    this.rightDownPointY =
      (equationLeftDown.c * -1 - equationLeftDown.a * this.rightDownPointX) /
      equationLeftDown.b;

    //location为家具放置位置 0：左墙 1：水平墙 2：右墙
    this.location = 0;
  };

  //右墙时伸拉图片
  //locationPointX:（悬挂式）家具定位点X坐标
  //locationPointY:（悬挂式）家具定位点Y坐标
  //该定位点是右上角
  p.StretchFurnitureInRightWall = function (locationPointX, locationPointY) {
    var arr = this.parent.WallLineModel.arr;
    var dpOfLeftWall, dpOfRightWall;
    var stretcdScaleX, //在右墙时家具应该呈现的X比例
      rightWallPix; //右墙的像素长度（左墙两个像素坐标的距离)

    if (arr.length == 8) {
      //左墙灭点
      dpOfLeftWall = MyFA.CommonFunction.segmentsIntr(
        arr[2],
        arr[3],
        arr[6],
        arr[7]
      );
      //右边墙灭点
      dpOfRightWall = MyFA.CommonFunction.segmentsIntr(
        arr[0],
        arr[1],
        arr[4],
        arr[5]
      );

      rightWallPix = MyFA.CommonFunction.getDistanceOfPointToPoint(
        arr[6].Px,
        arr[6].Py,
        arr[7].Px,
        arr[7].Py
      );
      //stretcdScaleX=(arr[7].Px - arr[6].Px/右墙的像素长度)*家具不进行伸拉时的X比例
      stretcdScaleX = ((arr[7].Px - arr[6].Px) / rightWallPix) * this.scaleX;

      //rightWallPix = MyFA.CommonFunction.getDistanceOfPointToPoint(dpOfLeftWall.Px, dpOfLeftWall.Py, this.rightDownPointX, this.rightDownPointY);
      ////stretcdScaleX=(arr[7].Px - arr[6].Px/右墙的像素长度)*家具不进行伸拉时的X比例
      //stretcdScaleX = (Math.abs(dpOfLeftWall.Px - this.rightDownPointX)) / rightWallPix * this.scaleX;
    } else {
      //左墙灭点
      dpOfLeftWall = MyFA.CommonFunction.segmentsIntr(
        arr[1],
        arr[2],
        arr[4],
        arr[5]
      );
      //右边墙灭点
      dpOfRightWall = MyFA.CommonFunction.segmentsIntr(
        arr[0],
        arr[1],
        arr[3],
        arr[4]
      );

      rightWallPix = MyFA.CommonFunction.getDistanceOfPointToPoint(
        arr[4].Px,
        arr[4].Py,
        arr[5].Px,
        arr[5].Py
      );
      //stretcdScaleX=(arr[5].Px - arr[4].Px/右墙的像素长度)*家具不进行伸拉时的X比例
      stretcdScaleX = ((arr[5].Px - arr[4].Px) / rightWallPix) * this.scaleX;
    }

    if (!dpOfLeftWall || !dpOfRightWall) {
      return;
    }
    //var d1 = MyFA.CommonFunction.getDistanceOfPointToPoint(dpOfLeftWall.Px, dpOfLeftWall.Py, locationPointX, locationPointY);
    //var d2 = MyFA.CommonFunction.getDistanceOfPointToPoint(dpOfLeftWall.Px, dpOfLeftWall.Py, arr[2].Px, arr[2].Py);

    //var rightDownY = (arr[6].Py - arr[2].Py) / (d2 / d1);
    //var ratio = rightWallPix / (arr[7].Px - arr[6].Px);
    //var txt = document.getElementById("txtResult");
    //txt.textContent = "";
    //txt.textContent += ("\n(d2 / d1)：" + (d2 / d1) + ";");
    //txt.textContent += ("\nrightDownY：" + (rightDownY) + ";");

    //先确定图片右边两点
    this.rightUpPointX = locationPointX;
    this.rightUpPointY = locationPointY;
    this.rightDownPointX =
      (this.bbrX - this.btrX) * this.scaleX + this.rightUpPointX;
    this.rightDownPointY =
      (this.bbrY - this.btrY) * 1.2 * this.scaleY + this.rightUpPointY;
    //this.rightDownPointY = rightDownY;

    //根据stretcdScaleX确定左边两点的X坐标
    //左上角点=右上角与左墙灭点的连线，与图片左边两点连线的交点
    this.leftUpPointX =
      (this.btlX - this.btrX) * stretcdScaleX + this.rightUpPointX;
    var poRightUp = { Px: this.rightUpPointX, Py: this.rightUpPointY };
    var equationRightUp = MyFA.CommonFunction.calLinearEquationByPoints(
      poRightUp,
      dpOfLeftWall
    );
    this.leftUpPointY =
      (equationRightUp.c * -1 - equationRightUp.a * this.leftUpPointX) /
      equationRightUp.b;

    //左下角点=右下角与左墙灭点的连线，与图片左边两点连线的交点
    this.leftDownPointX =
      (this.bblX - this.btrX) * stretcdScaleX + this.rightUpPointX;
    var poRightDown = { Px: this.rightDownPointX, Py: this.rightDownPointY };
    var equationRightDown = MyFA.CommonFunction.calLinearEquationByPoints(
      poRightDown,
      dpOfLeftWall
    );
    this.leftDownPointY =
      (equationRightDown.c * -1 - equationRightDown.a * this.leftDownPointX) /
      equationRightDown.b;

    //location为家具放置位置 0：左墙 1：水平墙 2：右墙
    this.location = 2;
  };

  MyFA.FurnitureModel = FurnitureModel;
})();
