﻿this.MyFurnitureAssistant = this.MyFurnitureAssistant || {};
// 定义别名(快捷名)：
if (typeof this.MyFA === 'undefined') {
    this.MyFA = this.MyFurnitureAssistant;
}
//放大镜功能
(function () {
    "use strict";
    var _stage,//舞台
        _photoSceneModel,//场景model
        w,//房间原始照片像素宽度
        h;//房间原始照片像素高度
    var tempContourCanvas,//canvas
        iCtx,//context
        imagedata1,//原始图像像素
        imagedata2;//放大镜区域像素
    Magnifier.r = 50;//放大镜半径
    function Magnifier(stage, photoSceneModel) {
        _stage = stage;
        _photoSceneModel = photoSceneModel;
        var _image = photoSceneModel.image;
        w = _image.width;//照片的像素宽度
        h = _image.height;//照片的像素高度

        tempContourCanvas = _stage.canvas;
        iCtx = tempContourCanvas.getContext("2d");

        //读取原始图片上的所有ImageData
       
        imagedata1 = cv.RGBA2ImageData(cv.imread(_image));
        //创建一个指定规格的ImageData
        imagedata2 = iCtx.createImageData(Magnifier.r * 2, Magnifier.r * 2);


        //舞台添加监听事件
        stage.addEventListener("mousedown", magnifier);//按下事件
        stage.addEventListener("pressmove", magnifier);//按下移动事件
        stage.addEventListener("pressup", putImageDataWhenPressup);//松开事件

        ////舞台添加canvas监听事件
        //stage.canvas.addEventListener("touchstart", magnifier1);//按下事件
        //stage.canvas.addEventListener("touchmove", magnifier1);//按下移动事件
        //stage.canvas.addEventListener("touchend", putImageDataWhenPressup1);//松开事件

    }

    Magnifier.r = 50;//放大镜半径
    var p = Magnifier.prototype;

    //移除舞台的放大镜功能
    p.RemoveMagnifier = function () {
        _stage.removeEventListener("mousedown", magnifier);
        _stage.removeEventListener("pressmove", magnifier);
        _stage.removeEventListener("pressup", putImageDataWhenPressup);

        
        //_stage.canvas.removeEventListener("touchstart", magnifier1);//按下事件
        //_stage.canvas.removeEventListener("touchmove", magnifier1);//按下移动事件
        //_stage.canvas.removeEventListener("touchend", putImageDataWhenPressup1);//松开事件

    }


    //放大镜功能
    function magnifier(e) {
       // _stage.preventSelection = true; 
        var x = e.stageX;
        var y = e.stageY;
        //如果点击左半边,则保持右上角100*100的像素
        if (x <= _stage.canvas.width * 0.5) {
            _photoSceneModel.imageDataForPut = _photoSceneModel.imageDataRight;
        }
            //如果点击右半边,则保持左上角100*100的像素
        else {
            _photoSceneModel.imageDataForPut = _photoSceneModel.imageDataLeft;
        }

        var x0 = Magnifier.r; var y0 = Magnifier.r;
        for (var j = 0; j < Magnifier.r * 2; j++) {
            for (var i = 0; i < Magnifier.r * 2; i++) {
                var k = 4 * (Magnifier.r * 2 * j + i);
                var k1 = 4 * (w * (Math.floor(y * 2 / _photoSceneModel.scale + j - Magnifier.r)) + Math.floor(x * 2 / _photoSceneModel.scale + i - Magnifier.r));//对应的原始图像上的点
                if (MyFA.CommonFunction.isOn(x0, y0, i, j, 3) || MyFA.CommonFunction.isIn(x0, y0, i, j, 3)) {
                    imagedata2.data[k + 0] = 255;
                    imagedata2.data[k + 1] = 0;
                    imagedata2.data[k + 2] = 0;
                    imagedata2.data[k + 3] = 255;
                }
                else {
                    if (MyFA.CommonFunction.isIn(x0, y0, i, j, MyFA.Magnifier.r)) {//放大区域的点
                        imagedata2.data[k + 0] = imagedata1.data[k1 + 0];
                        imagedata2.data[k + 1] = imagedata1.data[k1 + 1];
                        imagedata2.data[k + 2] = imagedata1.data[k1 + 2];
                        imagedata2.data[k + 3] = 255;
                    }
                    else {//其他内接圆外围的点
                        imagedata2.data[k + 0] = _photoSceneModel.imageDataForPut.data[k + 0];
                        imagedata2.data[k + 1] = _photoSceneModel.imageDataForPut.data[k + 1];
                        imagedata2.data[k + 2] = _photoSceneModel.imageDataForPut.data[k + 2];
                        imagedata2.data[k + 3] = _photoSceneModel.imageDataForPut.data[k + 3];
                    }
                }

            }
        }
        //如果点击左半边，则放大镜放于右上角
        if (x <= _stage.canvas.width * 0.5) {
            if (e.target.name == "image") {
                //重新渲染墙体识别线，填充另一边的图像
                redrawLines();
            }
            iCtx.putImageData(imagedata2, Math.floor(_stage.canvas.width - MyFA.Magnifier.r * 2), 0);
            //canvas显示
        }
            //如果点击右半边，则放大镜放于左上角
        else {
            if (e.target.name == "image") {
                //重新渲染墙体识别线，填充另一边的图像
                redrawLines();
            }
            iCtx.putImageData(imagedata2, 0, 0);
        }
    }

  
  
    //重新渲染墙体识别线（目的：防止填充以后墙体线被覆盖）
    function redrawLines() {
        var lineContainer = _stage.getChildByName("line");
        if (typeof (lineContainer) != "undefined") {
            _stage.removeChild(lineContainer);
            var wallLineView = new MyFA.WallLineView(_stage, _photoSceneModel.WallLineModel, _photoSceneModel.scale, true);
            _stage.update();
        }
    }

    //手指松开时重新用之前取得的像素数据填充放大镜所在区域的数据
    function putImageDataWhenPressup(e) { 
        var x = e.stageX;
        var y = e.stageY;
        //如果点击左半边，则填充右上角
        if (x <= _stage.canvas.width * 0.5) {
            iCtx.putImageData(_photoSceneModel.imageDataForPut, 0, 0);
            //canvas显示
        }
            //如果点击右半边，则填充左上角
        else {
            iCtx.putImageData(_photoSceneModel.imageDataForPut, 0, 0);
        }

        //重新渲染墙体识别线（目的：防止填充以后墙体线被覆盖））
        redrawLines();
    }



    MyFA.Magnifier = Magnifier;

})();
